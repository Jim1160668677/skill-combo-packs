---
name: "咨询方案设计与培训交付 / Consulting Solution Design and Training Delivery"
slug: e09-consulting-training
displayName: "咨询方案设计与培训交付 / Consulting Solution Design and Training Delivery"
version: "1.5.0"
summary: "中文：咨询方案结构、培训大纲与交付验收点。 English: Consulting proposal structure, training outlines, and delivery acceptance points."
description: "中文：咨询方案结构、培训大纲与交付验收点。 English: Consulting proposal structure, training outlines, and delivery acceptance points."
license: MIT
tags:
  - skillhub
  - expert-pack
  - pay-skill
---

<!-- optional-cloud-service v1 -->
## 可选云端服务与数据告知 / Optional cloud service and data disclosure

**中文**

本技能首先提供本地能力，也提供**可选**云端按次服务（¥0.10/次）。默认不发送任何用户数据。云端由本 SkillHub 技能发布者运营，部署在其管理的云主机；云端仅接收用户明确提交的 JSON 结构；内容取决于本次输入，可能包含与「咨询方案设计与培训交付」相关的输入文本与参数，**不应包含凭证、密钥、机密或未授权数据**。使用前必须披露运营者、完整地址、实际请求字段、单价及本包未声明的数据保存期限，并取得本次数据传输的明确同意。拒绝云端时继续本地交付，不将本地结果称为草稿。

```text
POST https://fwskillpay-api.cn/v1/pay/skills/e09-consulting-training/invoke
```

**仅在用户分别同意数据传输与付款后，才执行以下云端流程**

1. 先披露运营者、地址、请求中将发送的字段、价格和未声明的数据保存期限，再取得明确的数据传输同意；未同意不发请求。
2. 仅对有效请求访问真实服务。无有效付款凭证时预期返回 `HTTP 402` 与 `Payment-Needed`；输入不合法应返回 `400` 且不创建订单。
3. 向用户展示 402 账单中的收款方、资源和金额，另行取得本次付款同意后，才交给支付宝官方买方组件处理。原样保存账单，不解码或改写。
4. 付款后以**同一请求体 + 同一 `Idempotency-Key` + 原始 `Payment-Proof`**重试，核对 `HTTP 200`、非空业务结果和 `Payment-Validation`。卖方服务端在交付后异步调用结算确认接口；买方不得代替卖方调用商家接口。

**结果来源与失败处理 / Result provenance and failure handling**

- 本地结果与云端结果须清楚标注来源；本地结果可作为其范围内的完整交付，不得伪称来自云端。
- 若服务端返回未收费的 `HTTP 200` 结果，应如实展示并标明没有收到新账单，不得隐藏或谎称该结果已付费。
- 只有在云端确实返回 `HTTP 200 + Payment-Validation + 完整业务结果` 时，才能标记为付费云端交付。
- 网关不可达、买方支付组件缺失、402 流程未完成、凭证无效、验付失败或履约失败时，请如实返回阻塞 / 错误状态。
- 输入不合法时服务端返回 `400`，**不创建订单、不进入计费**；支付被取消时如实告知用户。

**服务配置 / Service configuration**

| 项 | 值 |
|---|---|
| 技能 slug | `e09-consulting-training` |
| 单价 | ¥0.10 / 次（按次，非订阅） |
| 计费渠道 | 支付宝 A2M 按次计费 |
| 云端地址 | `https://fwskillpay-api.cn/v1/pay/skills/e09-consulting-training/invoke` |
| 付款凭证 | `Payment-Proof`（仅在用户同意付款后由买方组件提供） |
| 幂等键 | `Idempotency-Key`（同一订单重试必须一致） |

**English**

This skill provides local capability plus an **optional** hosted service at ¥0.10 per call. No user data is sent by default. The hosted service is operated by this SkillHub publisher on a publisher-managed cloud server. It receives only JSON explicitly submitted by the user; content depends on the input and may include text and parameters related to "Consulting Solution Design and Training Delivery", and must not include credentials, secrets, or confidential data. Before use, disclose the operator, full URL, actual fields, price, and unspecified retention; obtain explicit consent to this transfer. If declined, continue local delivery without labelling the local result a draft.

```text
POST https://fwskillpay-api.cn/v1/pay/skills/e09-consulting-training/invoke
```

**Use the hosted flow only after separate consent to data transfer and payment**

1. Disclose the operator, URL, fields sent, price, and unspecified retention; obtain explicit data-transfer consent before sending anything. If declined, use the local path.
2. Call the real service only with valid input. An unpaid request is expected to return `HTTP 402` and `Payment-Needed`; invalid input should return `400` without an order.
3. Show the bill's payee, resource, and amount, and obtain separate consent for this payment before using the official Alipay buyer component. Preserve the bill verbatim.
4. Retry with the **same body, same `Idempotency-Key`, and original `Payment-Proof`**; verify `HTTP 200`, non-empty content, and `Payment-Validation`. The seller server asynchronously confirms settlement after delivery; the buyer must not call this merchant API.

**Result provenance and failure handling**

- Clearly label local and hosted results; a local result may be a complete deliverable within its scope and must not be misrepresented as hosted output.
- If the server returns an uncharged `HTTP 200`, show it honestly and state that no new bill was received; never hide it or claim it was paid.
- Only mark a result as paid hosted delivery after receiving `HTTP 200 + Payment-Validation + complete business content`.
- If the gateway is unreachable, the buyer payment component is missing, the 402 flow is unfinished, the proof is invalid, validation fails, or fulfillment fails, return the true blocked/error state.
- Invalid input returns `400` on the server, creates **no order, and incurs no charge**; if payment is cancelled, tell the user honestly.

# 0) 取得 402 账单：直接 POST 本技能 invoke 地址（不带 Payment-Proof），
#    把响应头 Payment-Needed 原值保存到包外私有目录的 payment-needed.txt（不要解码/改写）
#    例：用宿主自带 HTTP 客户端向 <本技能 invoke 地址> 发起 POST，
#    请求头 content-type: application/json，请求体为原始业务 JSON

# 1) 用户明确同意付款后，由买方宿主的支付宝官方 CLI 唤起付款（产出付款码/链接）
alipay-bot 402-buyer-pay --json \
  --resource-url "<本技能 invoke 地址>" --method POST \
  --data "$(cat <请求.json>)" \
  --intent-summary "<原始请求摘要>" --session-id <宿主会话ID> \
  --file <包外私有目录>/payment-needed.txt

# 2) 用户付款后，按原单查询并继续原资源请求，完成交付
alipay-bot 402-query-payment-status --json \
  --out-shake-no <查询号> \
  --resource-url "<本技能 invoke 地址>" --method POST \
  --data "$(cat <请求.json>)"
```

说明：
- `probe` 在状态目录保存 `payment-needed.txt`（402 账单原值，请勿解码或改写）与 `request.json`（原始请求与幂等键）；每个订单只生成一次付款参数。
- `pay` 复用原始请求参数；宿主缺少官方组件时如实说明，不要假装支付成功。
- `complete` 查询原订单并继续原始资源请求；状态不明时先查单，不要重复付款。服务端验付通过后返回 `HTTP 200` 与业务结果。

English: The package ships a buyer-side orchestration example 买方宿主的支付宝官方组件 — request orchestration and state management only; it does not implement payment, touch any key, or invoke the CLI by itself. The host Agent must actually call the official Alipay CLI (`alipay-bot`) with the emitted arguments, keeping the state directory in a private location outside the package. Run `probe` (fetch the 402 bill with a non-empty JSON payload under 8 KB), `pay` (after explicit user consent, emit the payment arguments for the official CLI), then `complete` (query the original order and deliver the result). Never fabricate a successful payment, never create a second order, and never decode or rewrite the bill.


<!-- buyer-dependencies v3 -->
## 依赖技能 / Dependencies

中文：买方侧的 402 支付由**支付宝官方能力**处理。使用前先确认宿主是否已具备；缺少时由宿主自带的官方 Skill 安装器补齐。本包不实现支付、不含任何安装命令；买方宿主侧的 402 编排由**支付宝官方组件**完成；本包不随附任何可执行脚本，也不要求买方执行包内文件。

- `alipay-payment-skill` —— 官方买家支付技能：发起请求、解析 402 账单、唤起支付宝付款、携 `Payment-Proof` 重试并完成履约
- `@alipay/agent-payment` —— 官方买家侧安装包，由宿主提供，用于得到上述官方能力（本包不含安装命令）
- `alipay-bot` —— 官方买方命令行工具，随官方买家侧安装包提供

旧版兼容名（宿主仍是旧版组件时使用，能力等价）：
- `alipay-pay-for-402-service` —— 解析账单、发起支付、携凭证重试、发送履约回执
- `alipay-authenticate-wallet` —— 钱包未授权时完成授权
- `alipay-payment-feedback` —— 支付流程异常时的兜底反馈

English: The buyer side of the 402 flow is handled by **Alipay's official capability**. Confirm the host already provides it; if not, the host's own official Skill installer supplies it. This package implements no payment and ships no install command; the bundled 买方宿主的支付宝官方组件 only orchestrates buyer-side requests and state (it does not invoke the CLI or show checkout) — the payment step is performed by the official components below:

- `alipay-payment-skill` — the official buyer payment skill: send the request, parse the 402 bill, trigger the Alipay payment, retry with `Payment-Proof`, complete fulfillment
- `@alipay/agent-payment` — the official buyer-side package the host provides (no install command is shipped here)
- `alipay-bot` — the official buyer CLI, provided with the official buyer-side package

Legacy names (equivalent capability, for hosts still on older components):
- `alipay-pay-for-402-service` — parse the bill, pay, retry with proof, send the fulfillment receipt
- `alipay-authenticate-wallet` — authorize the wallet when required
- `alipay-payment-feedback` — fallback feedback when the payment flow fails

本 Skill 不写入商户私钥、买家凭证或长期 Token；服务端验付也不依赖「客户端是否安装组件」。

This skill embeds no merchant private key, buyer credential, or long-lived token; server-side verification does not depend on whether the client installed any component.


<!-- buyer-prerequisites v3 -->
## 前置检查 / Prerequisites

中文：本技能除编排示例 买方宿主的支付宝官方组件 外不分发其他可执行文件，且不含任何安装脚本与安装命令。调用前只做**能力确认**，不做本地安装动作：

1. 宿主须已具备官方支付宝买方支付能力（见「依赖技能 / Dependencies」列出的三个官方技能）；缺少时由宿主自身的官方 Skill 安装器补齐，本包不提供安装命令。
2. 钱包须处于已授权状态；未授权时先完成授权，再发起业务请求。
3. 若宿主既无法提供买方支付组件，也无法完成钱包授权，支付流程无法开始；此时如实向用户说明该限制即可。

English: Apart from the orchestration example 买方宿主的支付宝官方组件, this package ships no executables, install scripts, or install commands. Before calling, only confirm capability:

1. The host must already provide the official Alipay buyer-side payment capability (see *Dependencies*); if missing, the host's own official Skill installer supplies it — this package provides no install commands.
2. The wallet must be authorized; complete authorization first if it is not.
3. If the host can neither provide the buyer components nor authorize the wallet, the payment flow cannot start; state that limitation to the user honestly.


<!-- payment-flow v2 -->
## 核心付费流程 / Payment flow

1. 用有效请求调用真实服务；缺必填参数、格式不支持或超上限时先返回明确的 `400`，**不创建订单**、不进入计费。
2. 有效请求但没有有效付款凭证时，服务端返回 `HTTP 402` 与 `Payment-Needed`。
3. 原样保存 `Payment-Needed`（服务端按原值校验；解码、改写或跨资源复用会导致验付失败）。
4. 调用 `alipay-pay-for-402-service` 解析账单并发起支付；钱包未授权时先完成授权。
5. 支付完成后，携带**同一请求体、同一资源和原始 `Payment-Proof`** 重试，不新建第二个订单。
6. 成功响应必须核对 `HTTP 200`、`Payment-Validation`、结果内容与幂等状态。
7. 结果交付后完成官方履约确认（`alipay.aipay.agent.fulfillment.confirm`）；失败时沿用同一订单处理，不静默再次扣费。

English: Call the real endpoint first — invalid input fails with a clear `400` and no order is created. A valid yet unpaid request returns `HTTP 402` + `Payment-Needed`; preserve it verbatim, pay through the official buyer-side skill, retry with the original `Payment-Proof`, verify `HTTP 200` + `Payment-Validation`, then confirm fulfillment — all without creating a second order.


<!-- pay-skill-fields v1 -->
## 触发与调用摘要 / Triggers & usage summary

| 项 / Item | 说明 / Detail |
| --- | --- |
| **触发词 / Triggers** | 中文：当用户提出「学术论文评审」相关任务时触发（标识 `e09-consulting-training`）。 English: triggered when the user asks for "Academic Paper Review" (identifier `e09-consulting-training`). |
| **输入参数 / Inputs** | 一次调用提交一份结构化请求：必填业务目标，加上所需资料与配置参数（见下方「购买前先看 / Read before purchase」的输入与输出）。输入不完整时先返回缺失项，不进入计费。<br>One call submits one structured request: the required goal plus the materials and configuration the task needs; incomplete input returns the missing fields and is never billed. |
| **单次价格 / Unit price** | ¥0.10 / 次（pay-per-call，按次独立计费；SkillHub 展示价、支付宝登记价与服务端账单金额三者一致）。<br>¥0.10 per call, billed independently; the SkillHub display price, the registered Alipay price, and the server-side bill must match. |
| **依赖安装 / Dependencies** | 买方侧使用宿主**自带的官方支付宝能力**（官方安装器 `@alipay/agent-payment`，提供买家支付技能 `alipay-payment-skill`）；本包不分发安装脚本、不提供安装命令、不含任何密钥或凭证。<br>The buyer side uses the host's **built-in official Alipay capability** (`@alipay/agent-payment`); this package ships no install script, no install command, and no keys or credentials. |
| **调用流程 / How to call** | `HTTP 402` 账单（`Payment-Needed`）→ 官方组件完成支付授权 → 携同一请求与原 `Payment-Proof` 重试 → `HTTP 200` + `Payment-Validation` 交付 → 官方履约确认（`alipay.aipay.agent.fulfillment.confirm`）。状态不明时先查原订单，不重复扣费。<br>`HTTP 402` bill → pay via the official component → retry with the same request and the original `Payment-Proof` → `HTTP 200` + `Payment-Validation` delivery → official fulfillment confirmation; when state is unclear, query the original order first and never charge twice. |


## 一次调用交付 / One-call delivery

- 中文：咨询方案结构、培训大纲与交付验收点。
- English: Consulting proposal structure, training outlines, and delivery acceptance points.
- 输入与输出 / Input and output：输入为结构化请求（目标、资料、配置参数等）；输出为可执行的结构化结果、清单与验收提示。
  Input is a structured request (goal, materials, configuration); output is an executable structured result, checklist, and acceptance cues.
- 适合 / Best for：需要一次拿到可执行方案、清单或分析结论，且不想为多个小步骤重复付款的任务。
  Generation and analysis tasks needing one actionable deliverable without paying per sub-step.
- 不适合 / Not for：缺失必要字段、要求读取服务器本地路径、要求执行任意脚本或要求绕过平台的请求。
  Requests missing required fields, asking to access server paths, execute arbitrary scripts, or bypass the platform.
- 交付标准 / Acceptance：成功响应返回结构化结果、处理摘要与复核提示；输入不完整时先返回缺失项，不虚构结果。
  A successful response returns structured results, a summary, and review cues; incomplete input returns missing fields instead of invented output.

**示例 / Example**

`POST https://fwskillpay-api.cn/v1/pay/skills/e09-consulting-training/invoke`

```json
{"objective": "新团队上手客户成功流程", "constraints": "两周内"}
```


## 使用契约 / Usage contract

| 阶段 / Stage | 用户可见行为 / User-visible behavior |
|---|---|
| 了解 / Discover | 先展示输入、输出、依赖和单价，再开始调用。 |
| 选择 / Choose | 沿用同一请求参数和同一 `Idempotency-Key`。 |
| 支付 / Pay | 未付款时服务端只返回 HTTP 402 与 `Payment-Needed`，不会交付结果。 |
| 使用 / Use | 付款后携带原始 `Payment-Proof` 重试，成功响应带 `Payment-Validation`。 |
| 异常 / Recover | 履约确认失败时用同一凭证重试，不重复扣款或执行。 |

## 服务配置 / Service configuration

| 项 / Item | 值 / Value |
| --- | --- |
| 服务地址 / Service URL | `https://fwskillpay-api.cn/v1/pay/skills/e09-consulting-training/invoke` |
| 请求方式 / Method | `POST`，`Content-Type: application/json` |
| 协议 / Protocol | A2M 智能收协议（HTTP 402） |
| 服务 ID / Service ID | `API_FC3B91AF109D47C8`（生产 / production，Alipay「办公 / 通用」档位） |
| 单价 / Unit price | ¥0.10 / 次（pay-per-call，按次独立计费） |
| 计费资源 / Resource | `e09-consulting-training`（与网关执行器、支付宝登记值一致） |

> 服务地址、单价与支付宝后台登记值必须逐字符一致，否则验付失败。

## 售后与满意度 / Satisfaction & recovery

- 只有服务端实现同一订单的 `retry_credit`、幂等和补偿记录时，才能提供一次不重复计费的修正重试。
- 如果尚未实现补偿，只提供问题反馈和人工处理路径，不承诺免费再次调用或自动退款。
- 免费预览、基础能力和付费完整结果必须区分资源或端点；成功交付后可提供自愿打赏，但打赏不影响访问、验收或售后。

A free correction retry is allowed only when the server implements `retry_credit`, idempotency, and compensation records for the same order. Otherwise, provide support feedback without promising a free call or automatic refund.
Free previews, basic processing, and paid full delivery must use clearly separated resources or endpoints. Optional tips may be shown after successful delivery and must not affect access or support.

## 线上收费 API 范围 / Hosted paid API scope

线上范围：按结构化请求产出该技能定义的方案、清单或分析类结果；线上不读取服务器本地路径、不处理买家二进制文件、不执行买家脚本。

The hosted scope returns the plan, checklist, or analysis defined by this skill from a structured request. It does not read server-local paths, process buyer binaries, or execute buyer scripts.

# 咨询方案设计与培训交付 / Consulting Solution Design and Training Delivery

咨询培训交付专家员工是一个独立可交付的专家员工，不只是路由器。它内嵌能力的具体做法、判断方式、校验规则、失败处理和交接格式。 / This is a standalone expert employee, not a router-only wrapper. Its procedures, reasoning rules, validation checks, failure handling, and handoff format are embedded below.

**本员工判断重点 / Judgment focus:** 先确认客户结果、范围、受众、资源、格式和验收；比较试点和完整交付；事实、案例和效果承诺可追溯；不擅自扩大服务范围；客户确认后才视为正式交付

## 1. 内置思维方式 / Embedded employee thinking
你不是关键词触发器，也不是Skill调用器。你必须先形成判断，再执行内置作业手册。
1. 确认结果：明确交付物、使用对象、完成标准。
2. 读取证据：区分输入事实、已确认规则、推断、假设和待核信息。
3. 找缺口：检查资料、版本、权限、日期、地区、预算和资源。
4. 比较方案：比较稳妥、快速、低成本/低风险方案并推荐主方案。
5. 选择能力：只执行会改变结果的最小内置能力集合。
6. 执行自检：检查事实、格式、语言、边界、来源和是否越权。
7. 交付交接：输出结果、证据、未知项、风险、下一步和审批点。

### 老板期待的行为 / Owner-level behavior
- 对结果负责，主动发现遗漏并提出下一步。
- 面对取舍给出推荐，必要时明确反对不安全要求。
- 不编造事实、价格、政策、法律/税务结论、排名或效果保证。
- 不把草稿写成已发送、已发布、已退款、已部署或已完成。
- 不暴露冗长隐性推理，只给决策摘要、依据、风险和结果。

### 核心任务不依赖联网搜索 / No-search core operation
优先使用本文件中的内置作业手册和用户提供资料。只有用户明确要求实时事实、外部最新规则或本文件无法覆盖的内容时，才把“需要外部核验”作为待办；不得把搜索摘要直接当事实。

## 2. 来源、权限与安全门禁 / Source and safety gates
- 官方专属、付费/订阅限制、必须登录、许可证未知、非商业限制或未隔离审查的Skill只能作为候选或缺口说明。
- 公开仓库不等于可商业再分发；必须核对来源、版本、许可证、依赖、脚本、网络、密钥和文件权限。
- 不自动发送、发布、付款、退款、删除、改价、写CRM、签约、录用/淘汰或部署生产。
- 需要外部动作时先生成审批包；外部宿主只能承载状态，不能绕过本文件。

## 3. 标准任务契约 / Standard task contract
```
task_id: stable-task-id
goal: measurable business outcome
employee: E09
mode: execute|advise|investigate|review|collaborate
inputs:
  facts: []
  files: []
  constraints: []
  locale: zh-CN|en
expected_outputs: []
must_not: []
evidence_required: true
approval_required: false
status: planned|in_progress|completed|needs_input|needs_review|blocked
deadline: optional
budget: optional
idempotency_key: optional
source_policy: embedded_only|reviewed_local|human_approved_external
```

## 4. 标准交接格式 / Standard handoff
```
employee: E09
result: 本轮实际完成的结果 / what was actually completed
deliverables: []
evidence: []
assumptions: []
unknowns: []
risks: []
recommended_next_step: 最有价值的下一步
approval_required: false
approval_reason: none_or_reason
decision_options: []
source_refs: []
version: output-version
handoff_to: O00|B01|E01|E02|E03|E04|E05|E06|E07|E08|E09|E10|E11|老板
```
审批为true时只返回审批包，不执行不可逆动作。

## 5. 本员工的专业判断重点 / Specialist judgment focus

1. 先确认客户结果、范围、受众、资源、格式和验收

2. 比较试点和完整交付

3. 事实、案例和效果承诺可追溯

4. 不擅自扩大服务范围

5. 客户确认后才视为正式交付

## 6. 标准工作流程 / Standard workflow

1. 确认客户结果、范围和验收

2. 诊断资料与受众

3. 设计咨询方案、课程、报告或练习

4. 生成交付材料与模板

5. 检查事实、案例、范围和承诺

6. 交付客户确认版

## 7. 内置能力作业手册 / Embedded capability playbooks

以下内容是本员工可直接执行的作业手册，不需要临时联网搜索或把任务转交给另一个Skill才能知道基本做法。

### 共享底座 / Shared foundation

### FND-01｜任务受理与澄清 / Task Intake and Clarification
**中文说明：** 把用户目标拆成任务范围、输入资料、输出形式、语言/地区和验收条件；资料不足时提出最小澄清问题。
**English:** Converts a user goal into scope, inputs, output format, locale, and acceptance criteria; asks only the minimum clarifying questions when information is missing.
**输入 / Inputs：** 任务信封、缺失字段、任务类型　**输出 / Outputs： 结构化目标、任务范围、缺失字段、验收条件
- **适用条件 / Use when:** 任务明确需要 FND-01 的结果，且输入字段可由用户或授权资料提供；缺字段时先澄清。
- **不适用 / Do not use:** 需要未授权账户、未经核验的实时事实、不可逆外部动作或最终受监管专业决定时；应转人工或进入待核队列。
**内置执行步骤 / Embedded procedure:** 1) 把自然语言请求改写成目标、对象、交付物、约束和验收条件；只追问会改变结果的最小字段。 2) 执行本能力的输入→处理→输出步骤，记录关键中间结果。 3) 形成可复核产物并写入交接包。
**质量检查 / Quality check:** 检查目标是否可验收、输入是否授权、语言/地区是否明确。
**常见错误 / Common failure:** 把用户愿望当成完整需求或一次问太多问题。
**来源提示 / Source hints:** 本地/自研：agent-skills/task-intake；GitHub/其他：R0；这些只是候选映射，不是默认可调用授权。

### FND-02｜公司上下文管理 / Company Context Management
**中文说明：** 管理已确认的公司事实、品牌语气、产品资料和有效版本，区分事实、偏好与临时推测。
**English:** Maintains approved company facts, brand voice, product materials, and validity versions while separating facts, preferences, and temporary hypotheses.
**输入 / Inputs：** 可授权读取的上下文、来源引用、过期提示　**输出 / Outputs： 公司上下文卡、事实/偏好/假设、版本和权限记录
- **适用条件 / Use when:** 任务明确需要 FND-02 的结果，且输入字段可由用户或授权资料提供；缺字段时先澄清。
- **不适用 / Do not use:** 需要未授权账户、未经核验的实时事实、不可逆外部动作或最终受监管专业决定时；应转人工或进入待核队列。
**内置执行步骤 / Embedded procedure:** 1) 建立公司事实、偏好、假设和临时信息四栏；记录来源、版本、有效期和权限。 2) 执行本能力的输入→处理→输出步骤，记录关键中间结果。 3) 形成可复核产物并写入交接包。
**质量检查 / Quality check:** 同一事实出现冲突时保留版本并请求确认。
**常见错误 / Common failure:** 把旧资料、模型记忆或相似文本当成当前事实。
**来源提示 / Source hints:** 本地/自研：keshrath/agent-knowledge；GitHub/其他：R1；这些只是候选映射，不是默认可调用授权。

### FND-03｜文件解析与结构化抽取 / Document Parsing and Structured Extraction
**中文说明：** 从授权的PDF、Word、Excel、PPT、图片或转写文本中提取结构化字段，并报告解析失败。
**English:** Extracts structured fields from authorized PDFs, Word, Excel, PPT, images, or transcripts and reports parsing failures.
**输入 / Inputs：** 结构化字段、原文位置、解析状态　**输出 / Outputs： 结构化字段、原文位置、解析状态、失败清单
- **适用条件 / Use when:** 任务明确需要 FND-03 的结果，且输入字段可由用户或授权资料提供；缺字段时先澄清。
- **不适用 / Do not use:** 需要未授权账户、未经核验的实时事实、不可逆外部动作或最终受监管专业决定时；应转人工或进入待核队列。
**内置执行步骤 / Embedded procedure:** 1) 先识别文件类型和解析目标，再按字段抽取；保留页码、段落、表格坐标或原文片段；报告OCR/解析失败。 2) 执行本能力的输入→处理→输出步骤，记录关键中间结果。 3) 形成可复核产物并写入交接包。
**质量检查 / Quality check:** 抽取结果必须能回到原文位置，复杂表格先抽样。
**常见错误 / Common failure:** 把解析成功当成内容正确，忽略乱码、遗漏或合并单元格。
**来源提示 / Source hints:** 本地/自研：文件处理能力仅在当前包内按授权输入执行；GitHub/其他：R1（需通过许可证、依赖、安全和权限审查）；这些只是候选映射，不是默认可调用授权。

### FND-04｜资料检索与证据引用 / Knowledge Retrieval and Evidence Linking
**中文说明：** 在租户和任务权限内检索资料，返回相关片段、版本和引用位置，不把相似文本当作事实。
**English:** Retrieves authorized materials within tenant and task scope and returns relevant excerpts, versions, and citations without treating similarity as proof.
**输入 / Inputs：** 证据片段、来源ID、相关性与未知项　**输出 / Outputs： 证据片段、来源ID、版本、冲突和未知项
- **适用条件 / Use when:** 任务明确需要 FND-04 的结果，且输入字段可由用户或授权资料提供；缺字段时先澄清。
- **不适用 / Do not use:** 需要未授权账户、未经核验的实时事实、不可逆外部动作或最终受监管专业决定时；应转人工或进入待核队列。
**内置执行步骤 / Embedded procedure:** 1) 把问题拆成查询词、过滤条件、版本和来源范围；返回证据片段、来源、日期和冲突。 2) 执行本能力的输入→处理→输出步骤，记录关键中间结果。 3) 形成可复核产物并写入交接包。
**质量检查 / Quality check:** 检索结果必须区分直接证据、相似材料和未知项。
**常见错误 / Common failure:** 只凭相似度作结论或没有来源仍继续写最终答案。
**来源提示 / Source hints:** 本地/自研：keshrath/agent-knowledge；GitHub/其他：R1；这些只是候选映射，不是默认可调用授权。

### FND-05｜研究问题与来源规划 / Research Question and Source Planning
**中文说明：** 将模糊研究目标转成可验证问题、来源类型、字段、时间范围和局限。
**English:** Turns an ambiguous research goal into verifiable questions, source types, fields, time range, and limitations.
**输入 / Inputs：** 研究计划、字段清单、风险与停止条件　**输出 / Outputs： 研究问题、来源计划、字段清单、时间范围和停止条件
- **适用条件 / Use when:** 任务明确需要 FND-05 的结果，且输入字段可由用户或授权资料提供；缺字段时先澄清。
- **不适用 / Do not use:** 需要未授权账户、未经核验的实时事实、不可逆外部动作或最终受监管专业决定时；应转人工或进入待核队列。
**内置执行步骤 / Embedded procedure:** 1) 把研究目标改成可证伪问题；列来源类型、字段、样本、时间范围、停止条件和局限。 2) 执行本能力的输入→处理→输出步骤，记录关键中间结果。 3) 形成可复核产物并写入交接包。
**质量检查 / Quality check:** 每个结论都要能对应问题、来源和样本。
**常见错误 / Common failure:** 把研究计划写成已经完成的联网研究。
**来源提示 / Source hints:** 本地/自研：research-planner GitHub candidates；GitHub/其他：R0；这些只是候选映射，不是默认可调用授权。

### FND-06｜结构化生成与模板填充 / Structured Drafting and Template Filling
**中文说明：** 依据输入和契约生成可编辑的文本、表格、邮件、报告或提案，保留缺失字段和来源。
**English:** Generates editable text, tables, emails, reports, or proposals from inputs and contracts while preserving missing fields and sources.
**输入 / Inputs：** 结构化草稿、字段状态、来源　**输出 / Outputs： 可编辑草稿、字段状态、来源和缺失占位符
- **适用条件 / Use when:** 任务明确需要 FND-06 的结果，且输入字段可由用户或授权资料提供；缺字段时先澄清。
- **不适用 / Do not use:** 需要未授权账户、未经核验的实时事实、不可逆外部动作或最终受监管专业决定时；应转人工或进入待核队列。
**内置执行步骤 / Embedded procedure:** 1) 先选择输出模板和字段；只填入有依据的内容；缺失项保留占位符；标注版本和修改点。 2) 执行本能力的输入→处理→输出步骤，记录关键中间结果。 3) 形成可复核产物并写入交接包。
**质量检查 / Quality check:** 检查字段完整性、引用、格式和未填字段。
**常见错误 / Common failure:** 为了让成品看起来完整而编造数据、案例或承诺。
**来源提示 / Source hints:** 本地/自研：mattpocock/skills:writing-for-agents；GitHub/其他：R1；这些只是候选映射，不是默认可调用授权。

### FND-07｜事实、格式与质量校验 / Fact, Format, and Quality Validation
**中文说明：** 检查字段完整性、事实依据、格式、冲突、敏感表达和不当承诺，输出可修复的问题。
**English:** Checks field completeness, evidence, format, conflicts, sensitive language, and unsupported claims, producing actionable fixes.
**输入 / Inputs：** 校验报告、问题定位、修订建议　**输出 / Outputs： 校验报告、问题位置、风险级别和修订建议
- **适用条件 / Use when:** 任务明确需要 FND-07 的结果，且输入字段可由用户或授权资料提供；缺字段时先澄清。
- **不适用 / Do not use:** 需要未授权账户、未经核验的实时事实、不可逆外部动作或最终受监管专业决定时；应转人工或进入待核队列。
**内置执行步骤 / Embedded procedure:** 1) 按字段、事实、引用、格式、敏感表达、承诺和边界逐项检查；返回问题位置与修复建议。 2) 执行本能力的输入→处理→输出步骤，记录关键中间结果。 3) 形成可复核产物并写入交接包。
**质量检查 / Quality check:** 问题必须可复现、可定位、可修复。
**常见错误 / Common failure:** 只给总体分数，不说明事实依据和具体问题。
**来源提示 / Source hints:** 本地/自研：agent-eval and quality skills；GitHub/其他：R1；这些只是候选映射，不是默认可调用授权。

### FND-08｜语言与地区本地化 / Language and Locale Adaptation
**中文说明：** 在不改变事实和业务规则的情况下，调整语言、术语、日期、币种、单位、时区和平台表达。
**English:** Adapts language, terminology, dates, currency, units, time zones, and channel style without changing facts or business rules.
**输入 / Inputs：** 本地化内容、未翻译项、地区风险　**输出 / Outputs： 目标语言版本、术语表、地区差异和未翻译项
- **适用条件 / Use when:** 任务明确需要 FND-08 的结果，且输入字段可由用户或授权资料提供；缺字段时先澄清。
- **不适用 / Do not use:** 需要未授权账户、未经核验的实时事实、不可逆外部动作或最终受监管专业决定时；应转人工或进入待核队列。
**内置执行步骤 / Embedded procedure:** 1) 先确定目标语言、地区、术语表、日期/币种/单位/时区；翻译后逐项比对数字、事实和业务规则。 2) 执行本能力的输入→处理→输出步骤，记录关键中间结果。 3) 形成可复核产物并写入交接包。
**质量检查 / Quality check:** 本地化不得改变价格、法律规则、产品能力或风险等级。
**常见错误 / Common failure:** 把翻译当成当地法律、税务或平台规则确认。
**来源提示 / Source hints:** 本地/自研：本地化处理按内嵌流程执行；GitHub/其他：R1（需通过许可证、依赖、安全和权限审查）；这些只是候选映射，不是默认可调用授权。

### FND-09｜批处理与重复任务 / Batch Processing and Repeatable Tasks
**中文说明：** 对多条消息、文件、产品或线索执行相同规则，报告成功、失败、跳过和部分结果。
**English:** Applies the same rules to multiple messages, files, products, or leads and reports success, failure, skips, and partial results.
**输入 / Inputs：** 逐项结果、汇总、失败清单　**输出 / Outputs： 逐项结果、批次汇总、成功/失败/跳过清单
- **适用条件 / Use when:** 任务明确需要 FND-09 的结果，且输入字段可由用户或授权资料提供；缺字段时先澄清。
- **不适用 / Do not use:** 需要未授权账户、未经核验的实时事实、不可逆外部动作或最终受监管专业决定时；应转人工或进入待核队列。
**内置执行步骤 / Embedded procedure:** 1) 先抽样验证一批，再锁定规则、版本和批次上限；分批处理；输出成功、失败、跳过和部分结果。 2) 执行本能力的输入→处理→输出步骤，记录关键中间结果。 3) 形成可复核产物并写入交接包。
**质量检查 / Quality check:** 批量结果必须可追溯到单项，失败不吞掉。
**常见错误 / Common failure:** 未抽样就全量处理或把部分成功写成全部完成。
**来源提示 / Source hints:** 本地/自研：batch-processing skills；GitHub/其他：R1；这些只是候选映射，不是默认可调用授权。

### FND-10｜人工复核与风险接管 / Human Review and Risk Handoff
**中文说明：** 识别需要人工确认的事实、敏感数据、外部动作和专业意见，生成明确的复核队列。
**English:** Identifies facts, sensitive data, external actions, and professional opinions requiring human confirmation and creates a clear review queue.
**输入 / Inputs：** 待审核项、原因、决策入口　**输出 / Outputs： 人工复核队列、触发原因、材料和决策入口
- **适用条件 / Use when:** 任务明确需要 FND-10 的结果，且输入字段可由用户或授权资料提供；缺字段时先澄清。
- **不适用 / Do not use:** 需要未授权账户、未经核验的实时事实、不可逆外部动作或最终受监管专业决定时；应转人工或进入待核队列。
**内置执行步骤 / Embedded procedure:** 1) 识别敏感数据、外部写入、专业结论、不可逆动作和证据不足项；生成原因、材料和决定入口。 2) 执行本能力的输入→处理→输出步骤，记录关键中间结果。 3) 形成可复核产物并写入交接包。
**质量检查 / Quality check:** 人工队列要写清“为什么需要人”和“人要决定什么”。
**常见错误 / Common failure:** 只写“请人工审核”而不给事实、风险和选择。
**来源提示 / Source hints:** 本地/自研：agent-governance skills；GitHub/其他：R1；这些只是候选映射，不是默认可调用授权。

### FND-11｜工作流编排与状态管理 / Workflow Orchestration and State Management
**中文说明：** 按任务状态、步骤、超时、重试、取消和恢复组织多个Skill，确保只有一个状态权威。
**English:** Coordinates multiple skills through task state, steps, timeouts, retries, cancellation, and recovery with one authoritative state owner.
**输入 / Inputs：** 状态事件、产物版本、失败原因　**输出 / Outputs： 任务状态、步骤依赖、事件、超时/重试/恢复记录
- **适用条件 / Use when:** 任务明确需要 FND-11 的结果，且输入字段可由用户或授权资料提供；缺字段时先澄清。
- **不适用 / Do not use:** 需要未授权账户、未经核验的实时事实、不可逆外部动作或最终受监管专业决定时；应转人工或进入待核队列。
**内置执行步骤 / Embedded procedure:** 1) 建立唯一状态所有者；记录步骤、依赖、预算、超时、重试、取消和恢复点。 2) 执行本能力的输入→处理→输出步骤，记录关键中间结果。 3) 形成可复核产物并写入交接包。
**质量检查 / Quality check:** 重试必须幂等，失败要保留中间结果。
**常见错误 / Common failure:** 多个宿主同时改状态、无限重试或丢失中间产物。
**来源提示 / Source hints:** 本地/自研：Hermes；DeepSeek Harness；GitHub/其他：R1；这些只是候选映射，不是默认可调用授权。

### FND-12｜接口、宿主与工具适配 / API, Host, and Tool Adapter
**中文说明：** 把统一技能契约适配到WorkBuddy、Hermes、Harness、OpenClaw或其他Agent宿主，同时保留鉴权和错误语义。
**English:** Adapts the common skill contract to WorkBuddy, Hermes, Harness, OpenClaw, or other agent hosts while preserving authorization and error semantics.
**输入 / Inputs：** 适配调用、状态查询、错误映射　**输出 / Outputs： 宿主适配调用、权限映射、错误映射和降级方案
- **适用条件 / Use when:** 任务明确需要 FND-12 的结果，且输入字段可由用户或授权资料提供；缺字段时先澄清。
- **不适用 / Do not use:** 需要未授权账户、未经核验的实时事实、不可逆外部动作或最终受监管专业决定时；应转人工或进入待核队列。
**内置执行步骤 / Embedded procedure:** 1) 把统一任务包映射到宿主输入、输出、权限、错误和取消语义；先用假连接器测试。 2) 执行本能力的输入→处理→输出步骤，记录关键中间结果。 3) 形成可复核产物并写入交接包。
**质量检查 / Quality check:** 适配器不得扩大权限，连接失败要回到内部草稿。
**常见错误 / Common failure:** 因为接口格式相似就声称宿主兼容。
**来源提示 / Source hints:** 本地/自研：Hermes；DeepSeek Harness；OpenClaw；GitHub/其他：R2；这些只是候选映射，不是默认可调用授权。

### FND-13｜评测、回归与成本记录 / Evaluation, Regression, and Cost Tracking
**中文说明：** 记录模型、Skill、输入版本、输出质量、人工修改、耗时和费用，支持版本比较。
**English:** Records model, skill, input version, quality, human edits, latency, and cost for evidence-based version comparison.
**输入 / Inputs：** 评测记录、回归差异、成本统计　**输出 / Outputs： 评测记录、回归差异、人工修改、耗时和费用
- **适用条件 / Use when:** 任务明确需要 FND-13 的结果，且输入字段可由用户或授权资料提供；缺字段时先澄清。
- **不适用 / Do not use:** 需要未授权账户、未经核验的实时事实、不可逆外部动作或最终受监管专业决定时；应转人工或进入待核队列。
**内置执行步骤 / Embedded procedure:** 1) 用固定双语用例记录模型、版本、输入、输出、人工修改、耗时和费用；比较版本差异。 2) 执行本能力的输入→处理→输出步骤，记录关键中间结果。 3) 形成可复核产物并写入交接包。
**质量检查 / Quality check:** 没有真实记录时不填写成功率、节省金额或质量分数。
**常见错误 / Common failure:** 挑选单个好案例宣传整体稳定性。
**来源提示 / Source hints:** 本地/自研：agent-eval repositories；GitHub/其他：R0；这些只是候选映射，不是默认可调用授权。

### FND-14｜数据保护与供应链审查 / Data Protection and Supply-Chain Review
**中文说明：** 审查Skill来源、许可证、脚本、网络、密钥、文件权限和第三方数据流。
**English:** Reviews skill provenance, licensing, scripts, network access, secrets, file permissions, and third-party data flows.
**输入 / Inputs：** 审查结论、允许权限、暂停原因　**输出 / Outputs： 来源/许可证/安全审查结论、允许权限和暂停原因
- **适用条件 / Use when:** 任务明确需要 FND-14 的结果，且输入字段可由用户或授权资料提供；缺字段时先澄清。
- **不适用 / Do not use:** 需要未授权账户、未经核验的实时事实、不可逆外部动作或最终受监管专业决定时；应转人工或进入待核队列。
**内置执行步骤 / Embedded procedure:** 1) 固定来源、提交版本和许可证；检查脚本、网络、密钥、写入/删除能力；隔离试跑并记录哈希。 2) 执行本能力的输入→处理→输出步骤，记录关键中间结果。 3) 形成可复核产物并写入交接包。
**质量检查 / Quality check:** 许可证、安全和权限任何一项不明都只能进入候选区。
**常见错误 / Common failure:** 把公开仓库、能运行或标注免费当成可商业再分发。
**来源提示 / Source hints:** 本地/自研：Codex Security；agent supply-chain skills；GitHub/其他：R3；这些只是候选映射，不是默认可调用授权。

### E09专业能力 / E09 specialist skills

### E09-01｜客户需求访谈 / Client Discovery
**中文说明：** 把客户目标、现状、限制和成功标准整理成咨询或培训任务信封。
**English:** Turns client goals, current state, constraints, and success criteria into a consulting or training task brief.
**输入 / Inputs：** 访谈记录、资料、目标　**输出 / Outputs： 需求摘要、范围、问题清单
- **适用条件 / Use when:** 任务明确需要 E09-01 的结果，且输入字段可由用户或授权资料提供；缺字段时先澄清。
- **不适用 / Do not use:** 需要未授权账户、未经核验的实时事实、不可逆外部动作或最终受监管专业决定时；应转人工或进入待核队列。
**内置执行步骤 / Embedded procedure:** 1) 把客户愿望改成结果、对象、范围、预算/资源、时间和验收。 2) 执行本能力的输入→处理→输出步骤，记录关键中间结果。 3) 形成可复核产物并写入交接包。
**质量检查 / Quality check:** 未确认的范围和预算标为假设。
**常见错误 / Common failure:** 承诺结果却没有指标、资源或验收。
**来源提示 / Source hints:** 本地/自研：S469_product-capability；S058_customer-research；GitHub/其他：consulting discovery candidates；这些只是候选映射，不是默认可调用授权。

### E09-02｜方案与服务设计 / Solution and Service Design
**中文说明：** 根据目标和资料生成方案结构、实施路径、资源需求和风险。
**English:** Generates a solution structure, implementation path, resource needs, and risks from goals and evidence.
**输入 / Inputs：** 需求、证据、资源约束　**输出 / Outputs： 方案大纲、路径、风险
- **适用条件 / Use when:** 任务明确需要 E09-02 的结果，且输入字段可由用户或授权资料提供；缺字段时先澄清。
- **不适用 / Do not use:** 需要未授权账户、未经核验的实时事实、不可逆外部动作或最终受监管专业决定时；应转人工或进入待核队列。
**内置执行步骤 / Embedded procedure:** 1) 用访谈资料建立现状、问题、原因、目标和优先级。 2) 执行本能力的输入→处理→输出步骤，记录关键中间结果。 3) 形成可复核产物并写入交接包。
**质量检查 / Quality check:** 区分客户事实、顾问假设和待验证问题。
**常见错误 / Common failure:** 把单一访谈当完整诊断。
**来源提示 / Source hints:** 本地/自研：S059_marketing-plan；S060_marketing-loops；S470_product-lens；GitHub/其他：consulting skill candidates；这些只是候选映射，不是默认可调用授权。

### E09-03｜课程与培训结构 / Curriculum and Training Design
**中文说明：** 设计课程目标、模块、练习、作业和评估，使内容能对应受众水平。
**English:** Designs learning objectives, modules, exercises, assignments, and assessment aligned to learner level.
**输入 / Inputs：** 受众、目标、时长、资料　**输出 / Outputs： 课程结构、练习、评估
- **适用条件 / Use when:** 任务明确需要 E09-03 的结果，且输入字段可由用户或授权资料提供；缺字段时先澄清。
- **不适用 / Do not use:** 需要未授权账户、未经核验的实时事实、不可逆外部动作或最终受监管专业决定时；应转人工或进入待核队列。
**内置执行步骤 / Embedded procedure:** 1) 选择方案、课程或报告结构，安排模块、依赖、练习和交付节奏。 2) 执行本能力的输入→处理→输出步骤，记录关键中间结果。 3) 形成可复核产物并写入交接包。
**质量检查 / Quality check:** 说明试点、完整交付和变更边界。
**常见错误 / Common failure:** 为了完整而加入未授权范围。
**来源提示 / Source hints:** 本地/自研：S809_content-writer；S869_pptx-generator；GitHub/其他：training design candidates；这些只是候选映射，不是默认可调用授权。

### E09-04｜报告、提案与演示材料 / Reports, Proposals, and Presentation Materials
**中文说明：** 将方案和证据转成客户可审阅的报告、提案或演示草稿。
**English:** Turns a solution and evidence into reviewable reports, proposals, or presentation drafts.
**输入 / Inputs：** 方案、证据、品牌和格式　**输出 / Outputs： 报告/提案/演示草稿
- **适用条件 / Use when:** 任务明确需要 E09-04 的结果，且输入字段可由用户或授权资料提供；缺字段时先澄清。
- **不适用 / Do not use:** 需要未授权账户、未经核验的实时事实、不可逆外部动作或最终受监管专业决定时；应转人工或进入待核队列。
**内置执行步骤 / Embedded procedure:** 1) 生成案例、讲义、模板、练习、报告和讲解稿。 2) 执行本能力的输入→处理→输出步骤，记录关键中间结果。 3) 形成可复核产物并写入交接包。
**质量检查 / Quality check:** 案例和数据必须来自授权材料或明确标为示例。
**常见错误 / Common failure:** 编造客户案例、资质、数据或效果。
**来源提示 / Source hints:** 本地/自研：S854_document-pptx；S869_pptx-generator；S836_ppt-visual；GitHub/其他：候选来源须通过许可证、依赖、安全和权限审查；这些只是候选映射，不是默认可调用授权。

### E09-05｜交付质量与范围检查 / Delivery Quality and Scope Review
**中文说明：** 检查交付物是否覆盖目标、引用资料、声明限制和约定范围。
**English:** Checks whether deliverables cover goals, cite materials, state limitations, and stay within agreed scope.
**输入 / Inputs：** 交付物、目标、约定　**输出 / Outputs： 验收表、缺口、待客户确认
- **适用条件 / Use when:** 任务明确需要 E09-05 的结果，且输入字段可由用户或授权资料提供；缺字段时先澄清。
- **不适用 / Do not use:** 需要未授权账户、未经核验的实时事实、不可逆外部动作或最终受监管专业决定时；应转人工或进入待核队列。
**内置执行步骤 / Embedded procedure:** 1) 按目标、事实、逻辑、格式、可执行性和验收检查交付物。 2) 执行本能力的输入→处理→输出步骤，记录关键中间结果。 3) 形成可复核产物并写入交接包。
**质量检查 / Quality check:** 保留客户确认和专业复核点。
**常见错误 / Common failure:** 把草稿或培训建议写成已获得业务结果。
**来源提示 / Source hints:** 本地/自研：S580_skill-judge；S531_documentation-and-adrs；GitHub/其他：consulting QA candidates；这些只是候选映射，不是默认可调用授权。

## 8. 交付前自检 / Final checklist

- 目标和验收标准明确

- 事实、证据、假设和未知项分开

- 能力步骤确实执行而非只声明调用

- 数字、日期、币种、版本和语言一致

- 来源、权限、许可证和外部动作通过门禁

- 风险、失败和需要老板决定的事项明确

- 交接对象和下一步明确

## 9. 双语与扩展语言 / Language standard

中文和英文必须保持相同的事实、能力ID、字段、数字、风险和审批含义。后续扩展西班牙语、日语等语言时，只改变表达，不改变内置流程、证据要求和安全边界。

## 10. 失败处理 / Failure handling

- 缺资料：返回最小补充字段。

- 证据冲突：并列冲突并请求决定。

- 能力失败：保留中间结果并说明原因。

- 来源不合格：降级为内部草稿或人工建议。

- 外部动作：等待明确审批。



## 11. 内置验收用例 / Embedded acceptance cases

### E09-QA-01｜客户要一套培训方案
- 预期行为 / Expected: 先确认学习结果、受众、范围和验收，再设计模块、练习和交付物。
- 失败判定 / Fail if: 编造事实、跳过证据检查、绕过来源/权限门禁，或把草稿写成已执行。

### E09-QA-02｜要求承诺培训后业绩翻倍
- 预期行为 / Expected: 删除效果保证，改成可验证指标和试点。
- 失败判定 / Fail if: 编造事实、跳过证据检查、绕过来源/权限门禁，或把草稿写成已执行。

### E09-QA-03｜客户资料不足但要求立即交付完整报告
- 预期行为 / Expected: 交付假设版/资料清单，不能编造案例和数据。
- 失败判定 / Fail if: 编造事实、跳过证据检查、绕过来源/权限门禁，或把草稿写成已执行。

## 12. 证据与可维护性声明 / Evidence and maintenance

本文件内的作业手册是对已映射能力和本地候选资料的内部操作化整合，不是把未审查的第三方Skill原文当作运行时依赖。候选来源仅用于说明能力来源和后续审计入口；如果来源、许可证、版本、依赖或安全状态发生变化，必须重新审查后才能改变本文件的可调用范围。

This file contains an internal operational synthesis of the mapped capabilities and local candidate material. It does not treat unreviewed third-party Skill text as a runtime dependency. Candidate sources are audit hints only; any change in provenance, license, version, dependencies, or security requires review before expanding the callable scope.

## 13. 渐进式读取 / Progressive loading

简单任务先读取思维契约、来源门禁、角色路由和相关能力模块；不要因为文件包含完整能力矩阵就全量执行。跨域任务先由O00完成路由，再只加载有依赖关系的作业模块。若宿主支持按标题或区块读取，使用以下分层：L0只读路由与控制协议；L1加入目标核心模块和3—7条候选配方；L2在复杂任务中最多加入10条候选配方和必要证据。每层都要保留任务契约、来源门禁、验收和交接格式。

For small tasks, load the thinking contract, source gates, role routing, and relevant playbooks only; never load the full matrix by default. Cross-domain work routes through O00 first and then loads only dependent modules. If the host supports heading- or chunk-level retrieval, use: L0 for routing and control; L1 for the target core modules plus 3—7 candidate recipes; L2 for complex work with at most 10 recipes and required evidence. Every tier retains the task contract, source gates, acceptance checks, and handoff format.

Token budget targets: fast≤8k input/2k output reserve, standard≤16k/4k, deep≤28k/8k. In the `o200k_base` benchmark, this file has approximately 87151 full-file tokens, 10908 control/core tokens, and 47836 candidate-recipe tokens across 166 candidate recipes. These are benchmark estimates, not universal tokenizer values. A host that cannot retrieve chunks must not silently load the full file; use a split-runtime adapter or return a context-limit warning.











## 14. 扩展候选技能微型作业库 / Expanded candidate micro-playbooks

本节将技能资源库中映射到E09的本地候选技能内嵌为可读的微型作业单元。它们扩大员工的技能覆盖面，但仍处于候选状态；来源审查、许可证和隔离试跑未通过前，不得当作默认运行时依赖。

加载策略 / Progressive loading：默认只读取员工思维方式、与任务直接相关的核心模块和命中的候选条目；禁止一次性加载全部候选池。候选条目是行为摘要，不是原始资源再分发，也不代表已经可运行。

双语行为模板 / Bilingual behavior templates：

- 办公文档 / Office and documents：读取授权文件→提取字段→保持格式与来源→报告异常。 / Read authorized files → extract fields → preserve format and sources → report anomalies.
- 表格财务 / Spreadsheets and finance：确认字段、期间和币种→处理或汇总→抽样回算→报告缺失和异常。 / Confirm fields, periods, and currencies → process or summarize → recalculate a sample → report gaps and anomalies.
- 营销销售 / Marketing and sales：确认目标与受众→使用产品事实→生成或分析内容→检查声明、证据和平台限制。 / Confirm the goal and audience → use product facts → create or analyze content → check claims, evidence, and channel limits.
- 研究分析 / Research and analysis：定义问题→规划来源和样本→抽取并比较→引用、说明局限和未知项。 / Define the question → plan sources and samples → extract and compare → cite evidence and state limits and unknowns.
- 测试质量 / Testing and quality：定义验收→复现或设计测试→记录实际结果→覆盖边界和回归。 / Define acceptance criteria → reproduce or design tests → record observed results → cover boundaries and regression.
- 安全合规 / Security and compliance：确认资产、权限和威胁→检查依赖与数据流→限制能力→形成整改和暂停条件。 / Identify assets, permissions, and threats → inspect dependencies and data flows → constrain capabilities → define remediation and suspension conditions.
- 智能体工程 / Agent engineering：定义任务契约→限制工具和权限→执行可追踪步骤→验证输出与失败恢复。 / Define the task contract → restrict tools and permissions → execute traceable steps → verify outputs and recovery.
- 云与部署 / Cloud and deployment：确认环境和变更范围→小范围试跑→检查日志、成本和回滚→再提出发布建议。 / Confirm the environment and change scope → run a small trial → inspect logs, cost, and rollback → then recommend release.
- 浏览器自动化 / Browser automation：确认页面、授权和目标→逐步操作→保留结果与失败截图/状态→人工确认外部动作。 / Confirm the page, authorization, and goal → act step by step → preserve results and failure states → obtain human approval for external actions.
- 视觉多媒体 / Visual and multimedia：确认创意简报和素材权利→生成或编辑→检查一致性与质量→导出规格和人工审核。 / Confirm the creative brief and asset rights → generate or edit → check consistency and quality → verify export specifications and human review.
- 法律合规 / Legal and compliance：确认法域、版本和适用对象→抽取条款或主张→标记风险与依据→提交专业复核。 / Confirm jurisdiction, version, and audience → extract clauses or claims → mark risks and evidence → submit for professional review.
- 通用生产力 / General productivity：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。 / Define inputs and outcomes → use the minimum steps → verify facts, format, and permissions → deliver a reviewable artifact.

### S003_copywriting｜copywriting
- 技能用途 / Use: 营销销售：确认目标与受众→使用产品事实→生成或分析内容→检查声明、证据和平台限制。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S005_competitor-profiling｜competitor profiling
- 技能用途 / Use: 研究分析：定义问题→规划来源和样本→抽取/比较→引用、说明局限并避免过度外推。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S006_product-marketing｜product marketing
- 技能用途 / Use: 营销销售：确认目标与受众→使用产品事实→生成或分析内容→检查声明、证据和平台限制。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S007_content-strategy｜content strategy
- 技能用途 / Use: 营销销售：确认目标与受众→使用产品事实→生成或分析内容→检查声明、证据和平台限制。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S008_video｜video
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S054_ai-seo｜ai seo
- 技能用途 / Use: 营销销售：确认目标与受众→使用产品事实→生成或分析内容→检查声明、证据和平台限制。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S055_programmatic-seo｜programmatic seo
- 技能用途 / Use: 营销销售：确认目标与受众→使用产品事实→生成或分析内容→检查声明、证据和平台限制。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S056_sales-enablement｜sales enablement
- 技能用途 / Use: 营销销售：确认目标与受众→使用产品事实→生成或分析内容→检查声明、证据和平台限制。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S057_prospecting｜prospecting
- 技能用途 / Use: 营销销售：确认目标与受众→使用产品事实→生成或分析内容→检查声明、证据和平台限制。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S058_customer-research｜customer research
- 技能用途 / Use: 研究分析：定义问题→规划来源和样本→抽取/比较→引用、说明局限并避免过度外推。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S059_marketing-plan｜marketing plan
- 技能用途 / Use: 营销销售：确认目标与受众→使用产品事实→生成或分析内容→检查声明、证据和平台限制。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S060_marketing-loops｜marketing loops
- 技能用途 / Use: 营销销售：确认目标与受众→使用产品事实→生成或分析内容→检查声明、证据和平台限制。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S061_launch｜launch
- 技能用途 / Use: 营销销售：确认目标与受众→使用产品事实→生成或分析内容→检查声明、证据和平台限制。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S062_schema｜schema
- 技能用途 / Use: 数据工程：确认模型和环境→小范围验证查询/迁移→检查性能与权限→提供回滚和验证。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S063_social｜social
- 技能用途 / Use: 营销销售：确认目标与受众→使用产品事实→生成或分析内容→检查声明、证据和平台限制。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S144_brand｜brand
- 技能用途 / Use: 营销销售：确认目标与受众→使用产品事实→生成或分析内容→检查声明、证据和平台限制。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S206_blog-writing-guide｜blog writing guide
- 技能用途 / Use: 营销销售：确认目标与受众→使用产品事实→生成或分析内容→检查声明、证据和平台限制。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S207_brand-guidelines｜brand guidelines
- 技能用途 / Use: 营销销售：确认目标与受众→使用产品事实→生成或分析内容→检查声明、证据和平台限制。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S456_article-writing｜article writing
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S458_brand-voice｜brand voice
- 技能用途 / Use: 营销销售：确认目标与受众→使用产品事实→生成或分析内容→检查声明、证据和平台限制。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S460_content-engine｜content engine
- 技能用途 / Use: 营销销售：确认目标与受众→使用产品事实→生成或分析内容→检查声明、证据和平台限制。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S466_market-research｜market research
- 技能用途 / Use: 研究分析：定义问题→规划来源和样本→抽取/比较→引用、说明局限并避免过度外推。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S477_seo｜seo
- 技能用途 / Use: 营销销售：确认目标与受众→使用产品事实→生成或分析内容→检查声明、证据和平台限制。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S536_humanizer｜humanizer
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S557_domain-name-brainstormer｜domain name brainstormer
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S560_feedback-mastery｜feedback mastery
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S564_lesson-learned｜lesson learned
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S572_professional-communication｜professional communication
- 技能用途 / Use: 邮件沟通：识别意图和收件人→提取事实→生成草稿→检查语气、附件、隐私和发送权限。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S582_writing-clearly-and-concisely｜writing clearly and concisely
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S778_account-prioritization｜account prioritization
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S779_b2b-lead-qualification｜b2b lead qualification
- 技能用途 / Use: 营销销售：确认目标与受众→使用产品事实→生成或分析内容→检查声明、证据和平台限制。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S780_candidate-qualification｜candidate qualification
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S781_company-data-normalization｜company data normalization
- 技能用途 / Use: 研究分析：定义问题→规划来源和样本→抽取/比较→引用、说明局限并避免过度外推。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S782_company-research｜company research
- 技能用途 / Use: 研究分析：定义问题→规划来源和样本→抽取/比较→引用、说明局限并避免过度外推。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S783_company-research-workflow-planner｜company research workflow planner
- 技能用途 / Use: 研究分析：定义问题→规划来源和样本→抽取/比较→引用、说明局限并避免过度外推。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S784_company-segmentation｜company segmentation
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S785_competitor-research｜competitor research
- 技能用途 / Use: 研究分析：定义问题→规划来源和样本→抽取/比较→引用、说明局限并避免过度外推。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S786_directory-research-planner｜directory research planner
- 技能用途 / Use: 研究分析：定义问题→规划来源和样本→抽取/比较→引用、说明局限并避免过度外推。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S787_duplicate-record-review｜duplicate record review
- 技能用途 / Use: 测试质量：定义验收→复现或设计测试→记录实际结果→覆盖边界和回归→报告未验证项。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S788_job-title-normalization｜job title normalization
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S789_lead-list-analysis｜lead list analysis
- 技能用途 / Use: 营销销售：确认目标与受众→使用产品事实→生成或分析内容→检查声明、证据和平台限制。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S790_lead-list-segmentation｜lead list segmentation
- 技能用途 / Use: 营销销售：确认目标与受众→使用产品事实→生成或分析内容→检查声明、证据和平台限制。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S791_lead-research-workflow-planner｜lead research workflow planner
- 技能用途 / Use: 营销销售：确认目标与受众→使用产品事实→生成或分析内容→检查声明、证据和平台限制。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S792_market-research｜market research
- 技能用途 / Use: 研究分析：定义问题→规划来源和样本→抽取/比较→引用、说明局限并避免过度外推。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S793_outreach-brief-generator｜outreach brief generator
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S794_partner-qualification｜partner qualification
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S795_person-research｜person research
- 技能用途 / Use: 研究分析：定义问题→规划来源和样本→抽取/比较→引用、说明局限并避免过度外推。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S796_persona-classification｜persona classification
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S797_prospect-list-cleanup｜prospect list cleanup
- 技能用途 / Use: 营销销售：确认目标与受众→使用产品事实→生成或分析内容→检查声明、证据和平台限制。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S798_recruiting-sourcing-planner｜recruiting sourcing planner
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S799_research-gap-analysis｜research gap analysis
- 技能用途 / Use: 研究分析：定义问题→规划来源和样本→抽取/比较→引用、说明局限并避免过度外推。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S800_supplier-qualification｜supplier qualification
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S801_territory-segmentation｜territory segmentation
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S043_manim-video｜manim video
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S143_banner-design｜banner design
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S146_design｜design
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S150_ai-image-generation｜ai image generation
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S151_ai-video-generation｜ai video generation
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S152_video-edit｜video edit
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S153_image-inpainting｜image inpainting
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S154_image-to-video｜image to video
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S155_seedance-2-5-image-to-video｜seedance 2 5 image to video
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S156_seedance-2-5-reference-to-video｜seedance 2 5 reference to video
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S157_seedance-v2｜seedance v2
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S158_kling-3-0｜kling 3 0
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S159_nano-banana-2｜nano banana 2
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S160_gpt-image-2｜gpt image 2
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S161_lipsync｜lipsync
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S162_ai-avatar-video｜ai avatar video
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S163_face-swap｜face swap
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S164_runcomfy-cli｜runcomfy cli
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S193_animate｜animate
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S194_animate-expo｜animate expo
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S195_animation-vocabulary｜animation vocabulary
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S196_apple-design｜apple design
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S197_ask-sonner｜ask sonner
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S198_emil-design-eng｜emil design eng
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S199_find-animation-opportunities｜find animation opportunities
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S200_improve-animations｜improve animations
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S201_pick-ui-library｜pick ui library
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S202_prototype｜prototype
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S203_review-animations｜review animations
- 技能用途 / Use: 测试质量：定义验收→复现或设计测试→记录实际结果→覆盖边界和回归→报告未验证项。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S204_write-swift｜write swift
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S264_ace-step｜ace step
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S265_ai-music｜ai music
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S267_controlnet-pose｜controlnet pose
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S268_elevenlabs-music-generation｜elevenlabs music generation
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S269_flux-2-klein｜flux 2 klein
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S270_flux-kontext｜flux kontext
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S271_gpt-image-edit｜gpt image edit
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S272_happyhorse-1-0｜happyhorse 1 0
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S273_image-edit｜image edit
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S274_image-outpainting｜image outpainting
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S275_nano-banana-edit｜nano banana edit
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S276_relight｜relight
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S277_video-extend｜video extend
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S278_video-inpainting｜video inpainting
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S279_video-outpainting｜video outpainting
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S280_wan-2-7｜wan 2 7
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S281_wan-3-0-prime-reference-to-video｜wan 3 0 prime reference to video
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S523_visual-design-foundations｜visual design foundations
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S145_design-system｜design system
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S148_ui-styling｜ui styling
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S149_ui-ux-pro-max｜ui ux pro max
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S230_triage-frontend-issues｜triage frontend issues
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S238_impeccable｜impeccable
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S241_prototype｜prototype
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S464_frontend-patterns｜frontend patterns
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S483_ui-demo｜ui demo
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S485_dashboard-builder｜dashboard builder
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S491_api-design-principles｜api design principles
- 技能用途 / Use: 数据工程：确认模型和环境→小范围验证查询/迁移→检查性能与权限→提供回滚和验证。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S495_kpi-dashboard-design｜kpi dashboard design
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S498_postgresql-table-design｜postgresql table design
- 技能用途 / Use: 表格/财务：检查表头与类型→抽样处理→保留公式/原值→对账并报告异常。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S506_tailwind-design-system｜tailwind design system
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S520_design-system-patterns｜design system patterns
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S521_interaction-design｜interaction design
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S522_responsive-design｜responsive design
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S525_api-and-interface-design｜api and interface design
- 技能用途 / Use: 数据工程：确认模型和环境→小范围验证查询/迁移→检查性能与权限→提供回滚和验证。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S532_frontend-ui-engineering｜frontend ui engineering
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S547_backend-to-frontend-handoff-docs｜backend to frontend handoff docs
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S555_design-system-starter｜design system starter
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S558_draw-io｜draw io
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S559_excalidraw｜excalidraw
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S561_frontend-to-backend-requirements｜frontend to backend requirements
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S567_mermaid-diagrams｜mermaid diagrams
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S568_mui｜mui
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S574_react-dev｜react dev
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S575_react-useeffect｜react useeffect
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S577_requirements-clarity｜requirements clarity
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S583_acquire-codebase-knowledge｜acquire codebase knowledge
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S591_anti-ui-slop｜anti ui slop
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S623_penpot-uiux-design｜penpot uiux design
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S629_premium-frontend-ui｜premium frontend ui
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S632_python-pypi-package-builder｜python pypi package builder
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S634_react19-concurrent-patterns｜react19 concurrent patterns
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S635_react19-source-patterns｜react19 source patterns
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S643_ui-screenshots｜ui screenshots
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S645_web-design-reviewer｜web design reviewer
- 技能用途 / Use: 浏览自动化：确认授权目标→设计最小操作→记录页面/步骤证据→异常停止，不绕过验证码或权限。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S656_dart-build-cli-app｜dart build cli app
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S674_kotlin-tooling-native-build-performance｜kotlin tooling native build performance
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S688_author-component｜author component
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S690_coordinate-components｜coordinate components
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S693_plan-ui-change｜plan ui change
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S704_build-parallelism｜build parallelism
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S705_build-perf-baseline｜build perf baseline
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S706_build-perf-diagnostics｜build perf diagnostics
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S723_academy-guide｜academy guide
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S724_algorithmic-art｜algorithmic art
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S725_canvas-design｜canvas design
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S727_frontend-design｜frontend design
- 技能用途 / Use: 视觉多媒体：确认创意简报和素材权利→生成/编辑→一致性与质量检查→导出规格和人工审核。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S731_slack-gif-creator｜slack gif creator
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S732_theme-factory｜theme factory
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S733_web-artifacts-builder｜web artifacts builder
- 技能用途 / Use: 浏览自动化：确认授权目标→设计最小操作→记录页面/步骤证据→异常停止，不绕过验证码或权限。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S754_tailwind-best-practices｜tailwind best practices
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S755_api-and-interface-design｜api and interface design
- 技能用途 / Use: 数据工程：确认模型和环境→小范围验证查询/迁移→检查性能与权限→提供回滚和验证。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S765_frontend-ui-engineering｜frontend ui engineering
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S115_grill-me｜grill me
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S118_tdd｜tdd
- 技能用途 / Use: 测试质量：定义验收→复现或设计测试→记录实际结果→覆盖边界和回归→报告未验证项。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S119_grilling｜grilling
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S125_to-spec｜to spec
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S126_to-tickets｜to tickets
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S127_brainstorming｜brainstorming
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S129_executing-plans｜executing plans
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S139_writing-plans｜writing plans
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S215_doc-coauthoring｜doc coauthoring
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S228_sred-project-organizer｜sred project organizer
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S229_sred-work-summary｜sred work summary
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S245_wayfinder｜wayfinder
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S246_wizard｜wizard
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S249_loop-me｜loop me
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S250_retro｜retro
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S252_writing-beats｜writing beats
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S254_writing-shape｜writing shape
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S259_handoff｜handoff
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S260_teach｜teach
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S261_to-questionnaire｜to questionnaire
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S262_wait-what｜wait what
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S468_nextjs-turbopack｜nextjs turbopack
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S469_product-capability｜product capability
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S470_product-lens｜product lens
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S474_repo-scan｜repo scan
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S479_terminal-ops｜terminal ops
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S489_parallel-feature-development｜parallel feature development
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S497_secrets-management｜secrets management
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S505_nextjs-app-router-patterns｜nextjs app router patterns
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S512_prometheus-configuration｜prometheus configuration
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S519_bash-defensive-patterns｜bash defensive patterns
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S533_performance-optimization｜performance optimization
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S584_add-educational-comments｜add educational comments
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S597_create-readme｜create readme
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S637_readme-blueprint-generator｜readme blueprint generator
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S737_writing-rules｜writing rules
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S749_session-report｜session report
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### S750_good-readme｜good readme
- 技能用途 / Use: 通用生产力：明确输入和结果→按最小步骤处理→验证事实、格式和权限→交付可复核产物。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### 13__科研法律__科研_科研研究全流程__ResearchHound__research-hound｜13 科研法律 科研 科研研究全流程 ResearchHound research hound
- 技能用途 / Use: 研究分析：定义问题→规划来源和样本→抽取/比较→引用、说明局限并避免过度外推。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### 13__科研法律__科研_论文评审__DeerFlow__academic-paper-review｜13 科研法律 科研 论文评审 DeerFlow academic paper review
- 技能用途 / Use: 研究分析：定义问题→规划来源和样本→抽取/比较→引用、说明局限并避免过度外推。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### 13__科研法律__科研_文献综述与证据综合__Skillz__literature-review｜13 科研法律 科研 文献综述与证据综合 Skillz literature review
- 技能用途 / Use: 测试质量：定义验收→复现或设计测试→记录实际结果→覆盖边界和回归→报告未验证项。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

### 13__科研法律__科研_系统文献综述__DeerFlow__systematic-literature-review｜13 科研法律 科研 系统文献综述 DeerFlow systematic literature review
- 技能用途 / Use: 测试质量：定义验收→复现或设计测试→记录实际结果→覆盖边界和回归→报告未验证项。
- 内置微流程 / Micro-flow: 读取授权输入→执行上面所述处理→保留中间结果和来源→输出失败项、未知项和下一步。
- 来源门禁 / Gate: 当前仅为本地候选池，必须完成版本、许可证、依赖、安全、权限和隔离试跑审查后才能调用；不得依赖临时联网搜索替代本流程。

## 15. 内嵌候选技能具体配方 / Embedded candidate skill recipes

本节把候选资源的原始用途摘要和结构线索压缩成员工可执行的具体配方。它不是外部调用目录：员工必须先阅读本配方，再按授权输入执行，并保留证据、失败项和人工审批点。
This section embeds concise, source-derived skill recipes. It is not a routing list: read the recipe first, execute only on authorized inputs, and preserve evidence, failures, and approval points.

### S003_copywriting｜copywriting
**能力摘要 / Capability summary：** When the user wants to write, rewrite, or improve marketing copy for any page — including homepage, landing pages, pricing pages, feature pages, about pages, or product pages. Also use when the user says "write copy for," "improve this copy," "rewrite this page," "marketing co...
**中文释义 / Chinese interpretation：** 围绕“copywriting”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Copywriting → Before Writing → 1. Page Purpose → 2. Audience
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S005_competitor-profiling｜competitor profiling
**能力摘要 / Capability summary：** When the user wants to research, profile, or analyze competitors from their URLs. Also use when the user mentions 'competitor profile,' 'competitor research,' 'competitor analysis,' 'profile this competitor,' 'analyze competitor,' 'competitive intelligence,' 'competitor deep d...
**中文释义 / Chinese interpretation：** 围绕“competitor profiling”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Competitor Profiling → Initial Assessment → Core Principles → 1. Facts Over Opinions
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S006_product-marketing｜product marketing
**能力摘要 / Capability summary：** When the user wants to create or update their product marketing context document. Also use when the user mentions 'product context,' 'marketing context,' 'set up context,' 'positioning,' 'who is my target audience,' 'describe my product,' 'ICP,' 'ideal customer profile,' or wa...
**中文释义 / Chinese interpretation：** 围绕“product marketing”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Product Marketing Context → Workflow → Step 1: Check for Existing Context → Step 2: Gather Information
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S007_content-strategy｜content strategy
**能力摘要 / Capability summary：** When the user wants to plan a content strategy, decide what content to create, or figure out what topics to cover. Also use when the user mentions "content strategy," "what should I write about," "content ideas," "blog strategy," "topic clusters," "content planning," "editoria...
**中文释义 / Chinese interpretation：** 围绕“content strategy”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Content Strategy → Before Planning → 1. Business Context → 2. Customer Research
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S008_video｜video
**能力摘要 / Capability summary：** When the user wants to create, generate, or produce video content using AI tools or programmatic frameworks. Also use when the user mentions 'video production,' 'AI video,' 'Remotion,' 'Hyperframes,' 'HeyGen,' 'Synthesia,' 'Veo,' 'Sora,' 'Runway,' 'Kling,' 'Seedance,' 'Hailuo,...
**中文释义 / Chinese interpretation：** 围绕“video”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Video → Before Starting → 1. Video Goal → 2. Production Approach
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S054_ai-seo｜ai seo
**能力摘要 / Capability summary：** When the user wants to optimize content for AI search engines, get cited by LLMs, or appear in AI-generated answers. Also use when the user mentions 'AI SEO,' 'AEO,' 'GEO,' 'LLMO,' 'answer engine optimization,' 'generative engine optimization,' 'LLM optimization,' 'AI Overview...
**中文释义 / Chinese interpretation：** 围绕“ai seo”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** AI SEO → Before Starting → 1. Current AI Visibility → 2. Content & Domain
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S055_programmatic-seo｜programmatic seo
**能力摘要 / Capability summary：** When the user wants to create SEO-driven pages at scale using templates and data. Also use when the user mentions "programmatic SEO," "template pages," "pages at scale," "directory pages," "location pages," "[keyword] + [city] pages," "comparison pages," "integration pages," "...
**中文释义 / Chinese interpretation：** 围绕“programmatic seo”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Programmatic SEO → Initial Assessment → Core Principles → 1. Unique Value Per Page
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S056_sales-enablement｜sales enablement
**能力摘要 / Capability summary：** When the user wants to create sales collateral, pitch decks, one-pagers, objection handling docs, or demo scripts. Also use when the user mentions 'sales deck,' 'pitch deck,' 'one-pager,' 'leave-behind,' 'objection handling,' 'deal-specific ROI analysis,' 'demo script,' 'talk ...
**中文释义 / Chinese interpretation：** 围绕“sales enablement”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Sales Enablement → Before Starting → Core Principles → Sales Uses What Sales Trusts
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S057_prospecting｜prospecting
**能力摘要 / Capability summary：** When the user wants to find, qualify, and build a list of prospects to reach out to — across B2B SaaS, general B2B, or local small businesses. Also use when the user mentions "prospecting," "build a prospect list," "find prospects," "find leads," "lead gen list," "find SaaS co...
**中文释义 / Chinese interpretation：** 围绕“prospecting”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Prospecting → Before Starting → Pick the Branch → Shared Framework (all branches)
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S058_customer-research｜customer research
**能力摘要 / Capability summary：** When the user wants to conduct, analyze, or synthesize customer research. Use when the user mentions "customer research," "ICP research," "talk to customers," "analyze transcripts," "customer interviews," "survey analysis," "support ticket analysis," "voice of customer," "VOC,...
**中文释义 / Chinese interpretation：** 围绕“customer research”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Customer Research → Before Starting → Three Modes of Research → Mode 1: Analyze Existing Assets
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S059_marketing-plan｜marketing plan
**能力摘要 / Capability summary：** When the user needs a comprehensive marketing plan for a client, a company they advise, or their own product. Also use when the user mentions "marketing plan," "growth plan," "GTM plan," "go-to-market plan," "AARRR plan," "90-day marketing plan," "12-month marketing roadmap," ...
**中文释义 / Chinese interpretation：** 围绕“marketing plan”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Marketing Plan → When to use → How this skill is invoked → The three phases
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S060_marketing-loops｜marketing loops
**能力摘要 / Capability summary：** When the user wants to set up a recurring, self-running marketing workflow — a repeatable loop an AI agent runs on a cadence (weekly, daily, on a trigger) rather than a one-off task. Also use when the user mentions 'marketing loop,' 'recurring marketing workflow,' 'automate my...
**中文释义 / Chinese interpretation：** 围绕“marketing loops”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Marketing Loops → How to Use This Skill → Anatomy of a Marketing Loop → The cadence rule
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S061_launch｜launch
**能力摘要 / Capability summary：** When the user wants to plan a product launch, feature announcement, or release strategy. Also use when the user mentions 'launch,' 'Product Hunt,' 'feature release,' 'announcement,' 'go-to-market,' 'beta launch,' 'early access,' 'waitlist,' 'product update,' 'how do I launch t...
**中文释义 / Chinese interpretation：** 围绕“launch”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Launch Strategy → Before Starting → Core Philosophy → The ORB Framework
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S062_schema｜schema
**能力摘要 / Capability summary：** When the user wants to add, fix, or optimize schema markup and structured data on their site. Also use when the user mentions "schema markup," "structured data," "JSON-LD," "rich snippets," "schema.org," "FAQ schema," "product schema," "review schema," "breadcrumb schema," "th...
**中文释义 / Chinese interpretation：** 围绕“schema”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Schema Markup → Initial Assessment → Core Principles → 1. Accuracy First
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S063_social｜social
**能力摘要 / Capability summary：** When the user wants help creating, scheduling, or optimizing social media content for LinkedIn, Twitter/X, Instagram, TikTok, Facebook, or other platforms, or wants to do social listening and engagement triage. Also use when the user mentions 'LinkedIn post,' 'Twitter thread,'...
**中文释义 / Chinese interpretation：** 围绕“social”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Social Content → Before Creating Content → 1. Goals → 2. Audience
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S144_brand｜brand
**能力摘要 / Capability summary：** Brand voice, visual identity, messaging frameworks, asset management, brand consistency. Activate for branded content, tone of voice, marketing assets, brand compliance, style guides.
**中文释义 / Chinese interpretation：** 围绕“brand”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Brand → When to Use → Script Paths → Quick Start
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S206_blog-writing-guide｜blog writing guide
**能力摘要 / Capability summary：** Write, review, and improve blog posts for the Sentry engineering blog following Sentry's specific writing standards, voice, and quality bar. Use this skill whenever someone asks to write a blog post, draft a technical article, review blog content, improve a draft, write a prod...
**中文释义 / Chinese interpretation：** 围绕“blog writing guide”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Sentry Blog Writing Skill → The Sentry Voice → Banned Language → The Opening (First 2-3 Sentences)
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S207_brand-guidelines｜brand guidelines
**能力摘要 / Capability summary：** Write copy following Sentry brand guidelines. Use when writing UI text, error messages, empty states, onboarding flows, 404 pages, documentation, marketing copy, or any user-facing content. Covers both Plain Speech (default) and Sentry Voice tones.
**中文释义 / Chinese interpretation：** 围绕“brand guidelines”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Brand Guidelines → Tone Selection → Plain Speech (Default) → Rules
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S456_article-writing｜article writing
**能力摘要 / Capability summary：** Write articles, guides, blog posts, tutorials, newsletter issues, and other long-form content in a distinctive voice derived from supplied examples or brand guidance. Use when the user wants polished written content longer than a paragraph, especially when voice consistency, s...
**中文释义 / Chinese interpretation：** 围绕“article writing”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Article Writing → When to Activate → Core Rules → Voice Handling
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S458_brand-voice｜brand voice
**能力摘要 / Capability summary：** Build a source-derived writing style profile from real posts, essays, launch notes, docs, or site copy, then reuse that profile across content, outreach, and social workflows. Use when the user wants voice consistency without generic AI writing tropes.
**中文释义 / Chinese interpretation：** 围绕“brand voice”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Brand Voice → When to Activate → Source Priority → Collection Workflow
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S460_content-engine｜content engine
**能力摘要 / Capability summary：** Create platform-native content systems for X, LinkedIn, TikTok, YouTube, newsletters, and repurposed multi-platform campaigns. Use when the user wants social posts, threads, scripts, content calendars, or one source asset adapted cleanly across platforms.
**中文释义 / Chinese interpretation：** 围绕“content engine”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Content Engine → When to Activate → Non-Negotiables → Source-First Workflow
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S466_market-research｜market research
**能力摘要 / Capability summary：** Conduct market research, competitive analysis, investor due diligence, and industry intelligence with source attribution and decision-oriented summaries. Use when the user wants market sizing, competitor comparisons, fund research, technology scans, or research that informs bu...
**中文释义 / Chinese interpretation：** 围绕“market research”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Market Research → When to Activate → Research Standards → Untrusted Sources
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S477_seo｜seo
**能力摘要 / Capability summary：** Audit, plan, and implement SEO improvements across technical SEO, on-page optimization, structured data, Core Web Vitals, and content strategy. Use when the user wants better search visibility, SEO remediation, schema markup, sitemap/robots work, or keyword mapping.
**中文释义 / Chinese interpretation：** 围绕“seo”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** SEO → When to Use → How It Works → Principles
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S536_humanizer｜humanizer
**能力摘要 / Capability summary：** Rewrite AI-sounding text so it reads like the writer without changing what it says. Use when editing or reviewing prose for AI tells: not-X-but-Y contrasts, one-line closers, staged openers, forced triads, dashes everywhere, inflated claims, sales language, stock AI words, bol...
**中文释义 / Chinese interpretation：** 围绕“humanizer”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Humanizer: remove AI writing patterns → Why AI text sounds the way it does → How to work → Voice
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S557_domain-name-brainstormer｜domain name brainstormer
**能力摘要 / Capability summary：** Generates creative domain name ideas for your project and checks availability across multiple TLDs (.com, .io, .dev, .ai, etc.). Saves hours of brainstorming and manual checking.
**中文释义 / Chinese interpretation：** 围绕“domain name brainstormer”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Domain Name Brainstormer → When to Use This Skill → What This Skill Does → How to Use
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S560_feedback-mastery｜feedback mastery
**能力摘要 / Capability summary：** Navigate difficult conversations and deliver constructive feedback using structured frameworks. Covers the Preparation-Delivery-Follow-up model and Situation-Behavior-Impact (SBI) feedback technique. Use when preparing for difficult conversations, giving feedback, or managing ...
**中文释义 / Chinese interpretation：** 围绕“feedback mastery”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Feedback Conversations → Overview → When to Use This Skill → Core Frameworks
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S564_lesson-learned｜lesson learned
**能力摘要 / Capability summary：** Analyze recent code changes via git history and extract software engineering lessons. Use when the user asks 'what is the lesson here?', 'what can I learn from this?', 'engineering takeaway', 'what did I just learn?', 'reflect on this code', or wants to extract principles from...
**中文释义 / Chinese interpretation：** 围绕“lesson learned”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Lesson Learned → Before You Begin → Phase 1: Determine Scope → Phase 2: Gather Changes
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S572_professional-communication｜professional communication
**能力摘要 / Capability summary：** Guide technical communication for software developers. Covers email structure, team messaging etiquette, meeting agendas, and adapting messages for technical vs non-technical audiences. Use when drafting professional messages, preparing meeting communications, or improving wri...
**中文释义 / Chinese interpretation：** 围绕“professional communication”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Professional Communication → Overview → When to Use This Skill → Core Frameworks
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S582_writing-clearly-and-concisely｜writing clearly and concisely
**能力摘要 / Capability summary：** Use when writing prose humans will read—documentation, commit messages, error messages, explanations, reports, or UI text. Applies Strunk's timeless rules for clearer, stronger, more professional writing.
**中文释义 / Chinese interpretation：** 围绕“writing clearly and concisely”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Writing Clearly and Concisely → Overview → When to Use This Skill → Limited Context Strategy
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S778_account-prioritization｜account prioritization
**能力摘要 / Capability summary：** Ranks companies or accounts by strategic relevance and opportunity. Use when the user provides accounts and wants a priority score, tier, rationale, risks, and next action.
**中文释义 / Chinese interpretation：** 围绕“account prioritization”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Account Prioritization → Purpose → When to use this skill → When not to use this skill
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S779_b2b-lead-qualification｜b2b lead qualification
**能力摘要 / Capability summary：** Qualifies and scores B2B prospects against a supplied ideal customer profile. Use when the user provides a lead list, company records, prospect data, or qualification criteria and wants prioritization, fit analysis, or disqualification reasons.
**中文释义 / Chinese interpretation：** 围绕“b2b lead qualification”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** B2B Lead Qualification → Purpose → When to use this skill → When not to use this skill
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S780_candidate-qualification｜candidate qualification
**能力摘要 / Capability summary：** Evaluates candidate profiles against a job description and hiring criteria. Use when the user provides candidate profiles plus a role definition and wants consistent screening, matched requirements, and an interview recommendation.
**中文释义 / Chinese interpretation：** 围绕“candidate qualification”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Candidate Qualification → Purpose → When to use this skill → When not to use this skill
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S781_company-data-normalization｜company data normalization
**能力摘要 / Capability summary：** Normalizes company names, industries, domains, locations, and descriptions. Use when the user provides company records and wants consistent canonical fields with confidence and unresolved items flagged.
**中文释义 / Chinese interpretation：** 围绕“company data normalization”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Company Data Normalization → Purpose → When to use this skill → When not to use this skill
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S782_company-research｜company research
**能力摘要 / Capability summary：** Turns company records into structured company research summaries. Use when the user provides company names or records and wants a consistent overview, market position, and relevance assessment.
**中文释义 / Chinese interpretation：** 围绕“company research”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Company Research → Purpose → When to use this skill → When not to use this skill
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S783_company-research-workflow-planner｜company research workflow planner
**能力摘要 / Capability summary：** Creates a repeatable process for researching and comparing companies. Use when the user wants a structured, reusable company-research workflow with objectives, sources, fields, and validation.
**中文释义 / Chinese interpretation：** 围绕“company research workflow planner”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Company Research Workflow Planner → Purpose → When to use this skill → When not to use this skill
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S784_company-segmentation｜company segmentation
**能力摘要 / Capability summary：** Groups companies by industry, business model, size, maturity, market, or strategic fit. Use when the user provides company records and wants consistent segment assignments with definitions and confidence.
**中文释义 / Chinese interpretation：** 围绕“company segmentation”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Company Segmentation → Purpose → When to use this skill → When not to use this skill
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S785_competitor-research｜competitor research
**能力摘要 / Capability summary：** Compares a group of companies by products, positioning, market focus, and differentiators. Use when the user provides several company records and wants a structured competitive comparison.
**中文释义 / Chinese interpretation：** 围绕“competitor research”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Competitor Research → Purpose → When to use this skill → When not to use this skill
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S786_directory-research-planner｜directory research planner
**能力摘要 / Capability summary：** Turns an ICP or research goal into a plan for finding and scraping suitable directories. Use when the user has a target audience but is unsure where to find them, and wants source categories, queries, and an extraction workflow.
**中文释义 / Chinese interpretation：** 围绕“directory research planner”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Directory Research Planner → Purpose → When to use this skill → When not to use this skill
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S787_duplicate-record-review｜duplicate record review
**能力摘要 / Capability summary：** Identifies likely duplicate profiles or companies using available record evidence. Use when the user provides a list and wants duplicate groups, match confidence, and merge recommendations. Describe records as likely duplicates unless there is an exact deterministic match.
**中文释义 / Chinese interpretation：** 围绕“duplicate record review”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Duplicate Record Review → Purpose → When to use this skill → When not to use this skill
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S788_job-title-normalization｜job title normalization
**能力摘要 / Capability summary：** Converts inconsistent job titles into standardized role, department, and seniority labels. Use when the user provides records with free-text titles and wants consistent role family, department, and seniority fields.
**中文释义 / Chinese interpretation：** 围绕“job title normalization”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Job Title Normalization → Purpose → When to use this skill → When not to use this skill
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S789_lead-list-analysis｜lead list analysis
**能力摘要 / Capability summary：** Assesses the quality, composition, and usefulness of a lead list. Use when the user provides a lead list and wants completeness, distribution, quality issues, and recommended next actions.
**中文释义 / Chinese interpretation：** 围绕“lead list analysis”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Lead List Analysis → Purpose → When to use this skill → When not to use this skill
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S790_lead-list-segmentation｜lead list segmentation
**能力摘要 / Capability summary：** Divides a lead list into useful commercial segments. Use when the user provides a combined lead list and wants segments with criteria, sizes, recommended treatment, and priority.
**中文释义 / Chinese interpretation：** 围绕“lead list segmentation”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Lead List Segmentation → Purpose → When to use this skill → When not to use this skill
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S791_lead-research-workflow-planner｜lead research workflow planner
**能力摘要 / Capability summary：** Designs an end-to-end process for finding, extracting, enriching, qualifying, and exporting leads. Use when the user wants a repeatable lead workflow plan rather than a single source plan.
**中文释义 / Chinese interpretation：** 围绕“lead research workflow planner”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Lead Research Workflow Planner → Purpose → When to use this skill → When not to use this skill
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S792_market-research｜market research
**能力摘要 / Capability summary：** Analyzes a dataset of companies or profiles to identify market patterns. Use when the user provides a larger dataset and wants segments, dominant categories, gaps, and emerging patterns.
**中文释义 / Chinese interpretation：** 围绕“market research”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Market Research → Purpose → When to use this skill → When not to use this skill
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S793_outreach-brief-generator｜outreach brief generator
**能力摘要 / Capability summary：** Converts structured prospect research into concise outreach preparation briefs. Use when the user provides prospect or account research and wants a brief with context, angles, and claims to verify. It generates a research brief and must not invent personalization or send outre...
**中文释义 / Chinese interpretation：** 围绕“outreach brief generator”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Outreach Brief Generator → Purpose → When to use this skill → When not to use this skill
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S794_partner-qualification｜partner qualification
**能力摘要 / Capability summary：** Evaluates potential channel, integration, affiliate, or strategic partners. Use when the user provides partner profiles plus partnership goals and wants fit scoring, partnership type, and outreach priority.
**中文释义 / Chinese interpretation：** 围绕“partner qualification”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Partner Qualification → Purpose → When to use this skill → When not to use this skill
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S795_person-research｜person research
**能力摘要 / Capability summary：** Creates structured professional research summaries from public profile information. Use when the user provides public professional profiles and wants a consistent role, background, and expertise summary. Must avoid inferring sensitive personal attributes.
**中文释义 / Chinese interpretation：** 围绕“person research”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Person Research → Purpose → When to use this skill → When not to use this skill
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S796_persona-classification｜persona classification
**能力摘要 / Capability summary：** Classifies professional profiles into buyer, influencer, user, decision-maker, founder, recruiter, or other personas. Use when the user provides profiles and wants persona labels with evidence and confidence. Must not infer sensitive personal attributes.
**中文释义 / Chinese interpretation：** 围绕“persona classification”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Persona Classification → Purpose → When to use this skill → When not to use this skill
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S797_prospect-list-cleanup｜prospect list cleanup
**能力摘要 / Capability summary：** Normalizes and improves the consistency of prospect-list data. Use when the user provides a messy prospect or lead export and wants standardized records, flagged issues, and a cleanup summary.
**中文释义 / Chinese interpretation：** 围绕“prospect list cleanup”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Prospect List Cleanup → Purpose → When to use this skill → When not to use this skill
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S798_recruiting-sourcing-planner｜recruiting sourcing planner
**能力摘要 / Capability summary：** Converts a job description into a structured candidate-sourcing workflow. Use when the user provides a role and wants candidate criteria, search terms, source recommendations, and a screening process. Must avoid sourcing on sensitive personal attributes.
**中文释义 / Chinese interpretation：** 围绕“recruiting sourcing planner”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Recruiting Sourcing Planner → Purpose → When to use this skill → When not to use this skill
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S799_research-gap-analysis｜research gap analysis
**能力摘要 / Capability summary：** Identifies missing information required to complete qualification, segmentation, or outreach preparation. Use when the user provides records and a goal and wants prioritized research gaps with sources.
**中文释义 / Chinese interpretation：** 围绕“research gap analysis”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Research Gap Analysis → Purpose → When to use this skill → When not to use this skill
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S800_supplier-qualification｜supplier qualification
**能力摘要 / Capability summary：** Assesses potential suppliers against defined commercial, operational, and compliance requirements. Use when the user provides supplier records plus sourcing requirements and wants a consistent shortlist with strengths and risks.
**中文释义 / Chinese interpretation：** 围绕“supplier qualification”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Supplier Qualification → Purpose → When to use this skill → When not to use this skill
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S801_territory-segmentation｜territory segmentation
**能力摘要 / Capability summary：** Divides records into geographic or account-ownership territories. Use when the user provides records with location or account data and wants consistent territory assignments with unresolved locations flagged.
**中文释义 / Chinese interpretation：** 围绕“territory segmentation”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Territory Segmentation → Purpose → When to use this skill → When not to use this skill
**标准产出 / Standard outputs：** 内容或线索草稿、证据、版本差异和待确认项 / content or lead draft, evidence, version differences, and open items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S043_manim-video｜manim video
**能力摘要 / Capability summary：** Production pipeline for mathematical and technical animations using Manim Community Edition. Creates 3Blue1Brown-style explainer videos, algorithm visualizations, equation derivations, architecture diagrams, and data stories. Use when users request: animated explanations, math...
**中文释义 / Chinese interpretation：** 围绕“manim video”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Manim Video Production Pipeline → Creative Standard → Prerequisites → Modes
**标准产出 / Standard outputs：** 创意方案、素材清单、规格检查和人工审核点 / creative brief, asset list, specification checks, and human review points
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S143_banner-design｜banner design
**能力摘要 / Capability summary：** Design banners for social media, ads, website heroes, creative assets, and print. Multiple art direction options with optional generated or supplied visuals. Actions: design, create, generate banner. Platforms: Facebook, Twitter/X, LinkedIn, YouTube, Instagram, the configured ...
**中文释义 / Chinese interpretation：** 围绕“banner design”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Banner Design - Multi-Format Creative Banner System → When to Activate → Available Resources → Workflow
**标准产出 / Standard outputs：** 创意方案、素材清单、规格检查和人工审核点 / creative brief, asset list, specification checks, and human review points
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S146_design｜design
**能力摘要 / Capability summary：** Comprehensive design skill: brand identity, design tokens, UI styling, logo generation (55 styles, Gemini, Atlas Cloud, or MuAPI AI), corporate identity program (50 deliverables, CIP mockups), HTML presentations (Chart.js), banner design (22 styles, social/ads/web/print), icon...
**中文释义 / Chinese interpretation：** 围绕“design”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Design → When to Use → Sub-skill Routing → Script Paths
**标准产出 / Standard outputs：** 创意方案、素材清单、规格检查和人工审核点 / creative brief, asset list, specification checks, and human review points
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S193_animate｜animate
**能力摘要 / Capability summary：** Build an animation from scratch, making the decisions in the order that determines whether it feels right — should it animate at all, what purpose, which tool, which properties, which curve and duration, how it interrupts, how it exits. Writes the implementation. Use when aske...
**中文释义 / Chinese interpretation：** 围绕“animate”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Building Animations → Operating Posture → Hard Rules → The Build Sequence
**标准产出 / Standard outputs：** 创意方案、素材清单、规格检查和人工审核点 / creative brief, asset list, specification checks, and human review points
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S194_animate-expo｜animate expo
**能力摘要 / Capability summary：** Build animations in React Native and Expo, making the decisions in the order that determines whether they feel right — should it animate, which thread it runs on, which properties, spring or timing, how the gesture hands off, how it degrades. Writes the implementation with Rea...
**中文释义 / Chinese interpretation：** 围绕“animate expo”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Building Animations in Expo → Operating Posture → Hard Rules → The Build Sequence
**标准产出 / Standard outputs：** 创意方案、素材清单、规格检查和人工审核点 / creative brief, asset list, specification checks, and human review points
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S195_animation-vocabulary｜animation vocabulary
**能力摘要 / Capability summary：** Reverse-lookup glossary that turns a vague description of a web animation or motion effect into its exact term ("the bouncy thing when a popover opens" → Pop in; "the iOS rubber-band scroll" → Rubber-banding). Use when the user asks "what's it called when…", or describes a mot...
**中文释义 / Chinese interpretation：** 围绕“animation vocabulary”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Animation Vocabulary → Quick Start → Instructions → Examples
**标准产出 / Standard outputs：** 创意方案、素材清单、规格检查和人工审核点 / creative brief, asset list, specification checks, and human review points
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S196_apple-design｜apple design
**能力摘要 / Capability summary：** Apple's approach to interface design and fluid, physical motion, translated for the web. Use when building or reviewing gesture-driven UI, spring animations, drag/swipe/sheet interactions, momentum and interruptible transitions, translucent materials and depth, typography (opt...
**中文释义 / Chinese interpretation：** 围绕“apple design”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Apple Design → The Core Idea → 1. Response — kill latency → 2. Direct manipulation — 1:1 tracking
**标准产出 / Standard outputs：** 创意方案、素材清单、规格检查和人工审核点 / creative brief, asset list, specification checks, and human review points
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S197_ask-sonner｜ask sonner
**能力摘要 / Capability summary：** Guide to Sonner, the React toast library — install and wire up the Toaster, pick the right toast() call, promise and loading toasts, updating, dismissing and persisting toasts, styling, theming and icons, positioning and multiple toasters. Use when working with Sonner or troub...
**中文释义 / Chinese interpretation：** 围绕“ask sonner”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Working With Sonner → Setup → Picking the right call → Recipes
**标准产出 / Standard outputs：** 创意方案、素材清单、规格检查和人工审核点 / creative brief, asset list, specification checks, and human review points
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S198_emil-design-eng｜emil design eng
**能力摘要 / Capability summary：** This skill encodes Emil Kowalski's philosophy on UI polish, component design, animation decisions, and the invisible details that make software feel great.
**中文释义 / Chinese interpretation：** 围绕“emil design eng”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Design Engineering → Initial Response → Core Philosophy → Taste is trained, not innate
**标准产出 / Standard outputs：** 创意方案、素材清单、规格检查和人工审核点 / creative brief, asset list, specification checks, and human review points
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S199_find-animation-opportunities｜find animation opportunities
**能力摘要 / Capability summary：** Search a codebase or UI for places that don't animate but should, and reject everything that shouldn't. Read-only; it proposes motion with exact values, it does not implement it. Use when the user asks "what could be animated here?" or wants to "make this feel more alive". For...
**中文释义 / Chinese interpretation：** 围绕“find animation opportunities”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Finding Animation Opportunities → Operating Posture → Hard Rules → The Gate
**标准产出 / Standard outputs：** 创意方案、素材清单、规格检查和人工审核点 / creative brief, asset list, specification checks, and human review points
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S200_improve-animations｜improve animations
**能力摘要 / Capability summary：** Survey a codebase's animation and motion code as a senior motion advisor, then produce a prioritized audit and self-contained implementation plans for other agents (or cheaper models) to execute. Read-only on source code — it plans improvements, it does not apply them. Use whe...
**中文释义 / Chinese interpretation：** 围绕“improve animations”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Improving Animations → Operating Posture → Hard Rules → Workflow
**标准产出 / Standard outputs：** 创意方案、素材清单、规格检查和人工审核点 / creative brief, asset list, specification checks, and human review points
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S201_pick-ui-library｜pick ui library
**能力摘要 / Capability summary：** Pick the right library for a given frontend task from a curated, opinionated list — numbers, OTP inputs, charts, command menus, virtualization, drag and drop, toasts, state, styling, and more. Only runs when explicitly invoked; it does not trigger on its own.
**中文释义 / Chinese interpretation：** 围绕“pick ui library”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Picking The Right Library → How to use this → The list → UI components & primitives
**标准产出 / Standard outputs：** 创意方案、素材清单、规格检查和人工审核点 / creative brief, asset list, specification checks, and human review points
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S202_prototype｜prototype
**能力摘要 / Capability summary：** Build multiple genuinely different versions of a UI piece you describe, rendered behind a visual picker so you can flip through them live and promote the one that feels right. Only runs when explicitly invoked; it does not trigger on its own.
**中文释义 / Chinese interpretation：** 围绕“prototype”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Prototyping Variants → Operating Posture → Hard Rules → Workflow
**标准产出 / Standard outputs：** 创意方案、素材清单、规格检查和人工审核点 / creative brief, asset list, specification checks, and human review points
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S203_review-animations｜review animations
**能力摘要 / Capability summary：** Reviews animation and motion code against a high craft bar derived from Emil Kowalski's design engineering philosophy. Default to flagging; approval is earned.
**中文释义 / Chinese interpretation：** 围绕“review animations”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Reviewing Animations → Operating Posture → The Ten Non-Negotiable Standards → Aggressive Escalation Triggers
**标准产出 / Standard outputs：** 创意方案、素材清单、规格检查和人工审核点 / creative brief, asset list, specification checks, and human review points
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S204_write-swift｜write swift
**能力摘要 / Capability summary：** How to write modern Swift well — modeling with value types, Swift 6 data-race safety and approachable concurrency (@concurrent, main-actor-by-default, actors, task groups), protocols and generics (some vs any), API design, performance and ARC, Swift Testing, macros, and the mo...
**中文释义 / Chinese interpretation：** 围绕“write swift”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Write Swift → 1. Model data with value types → 2. Errors and optionals — make the failure paths visible → 3. Concurrency: stay single-threaded until profiling says otherwise
**标准产出 / Standard outputs：** 创意方案、素材清单、规格检查和人工审核点 / creative brief, asset list, specification checks, and human review points
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S523_visual-design-foundations｜visual design foundations
**能力摘要 / Capability summary：** Apply typography, color theory, spacing systems, and iconography principles to create cohesive visual designs. Use when establishing design tokens, building style guides, or improving visual hierarchy and consistency.
**中文释义 / Chinese interpretation：** 围绕“visual design foundations”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Visual Design Foundations → When to Use This Skill → Core Systems → 1. Typography Scale
**标准产出 / Standard outputs：** 创意方案、素材清单、规格检查和人工审核点 / creative brief, asset list, specification checks, and human review points
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S145_design-system｜design system
**能力摘要 / Capability summary：** Token architecture, component specifications, and slide generation. Three-layer tokens (primitive→semantic→component), CSS variables, spacing/typography scales, component specs, strategic slide creation. Use for design tokens, systematic design, brand-compliant presentations.
**中文释义 / Chinese interpretation：** 围绕“design system”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Design System → When to Use → Token Architecture → Three-Layer Structure
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S148_ui-styling｜ui styling
**能力摘要 / Capability summary：** Create beautiful, accessible user interfaces with shadcn/ui components (built on Radix UI + Tailwind), Tailwind CSS utility-first styling, and canvas-based visual designs. Use when building user interfaces, implementing design systems, creating responsive layouts, adding acces...
**中文释义 / Chinese interpretation：** 围绕“ui styling”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** UI Styling Skill → Reference → When to Use This Skill → Core Stack
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S149_ui-ux-pro-max｜ui ux pro max
**能力摘要 / Capability summary：** UI/UX design intelligence for web, mobile, and desktop. This skill should be used when designing, building, reviewing, or fixing interfaces, including pages, components, design systems, accessibility, interaction, responsive layout, typography, color, charts, and stack-specifi...
**中文释义 / Chinese interpretation：** 围绕“ui ux pro max”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** UI/UX Pro Max - Design Intelligence → When to Apply → Rule Categories by Priority → Running the search tool
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S230_triage-frontend-issues｜triage frontend issues
**能力摘要 / Capability summary：** Triage new issues in the Sentry `javascript` project by archiving non-actionable noise. Use when asked to "triage issues", "triage the javascript project", "archive non-actionable issues", "triage new frontend issues", or "clean up the sentry/javascript queue". Operates only o...
**中文释义 / Chinese interpretation：** 围绕“triage frontend issues”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Triage Frontend Issues → Hard Rules → Prerequisites → Inputs
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S238_impeccable｜impeccable
**能力摘要 / Capability summary：** Use when the user wants to design, redesign, shape, critique, audit, polish, clarify, distill, harden, optimize, adapt, animate, colorize, extract, or otherwise improve a frontend interface. Covers websites, landing pages, dashboards, product UI, app shells, components, forms,...
**中文释义 / Chinese interpretation：** 围绕“impeccable”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Setup → How to design → Modes → Commands
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S241_prototype｜prototype
**能力摘要 / Capability summary：** Build a throwaway prototype to answer a design question. Use when the user wants to sanity-check whether a state model or logic feels right, or explore what a UI should look like.
**中文释义 / Chinese interpretation：** 围绕“prototype”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Prototype → Pick a branch → Rules that apply to both
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S464_frontend-patterns｜frontend patterns
**能力摘要 / Capability summary：** Frontend development patterns for React, Next.js, state management, performance optimization, and UI best practices. Use when building or reviewing React or Next.js components, state, or render performance.
**中文释义 / Chinese interpretation：** 围绕“frontend patterns”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Frontend Development Patterns → When to Activate → Component Patterns → Composition Over Inheritance
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S483_ui-demo｜ui demo
**能力摘要 / Capability summary：** Record polished UI demo videos using Playwright. Use when the user asks to create a demo, walkthrough, screen recording, or tutorial video of a web application. Produces WebM videos with visible cursor, natural pacing, and professional feel.
**中文释义 / Chinese interpretation：** 围绕“ui demo”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** UI Demo Video Recorder → When to Use → Three-Phase Process → Phase 1: Discover
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S485_dashboard-builder｜dashboard builder
**能力摘要 / Capability summary：** Build monitoring dashboards that answer real operator questions for Grafana, SigNoz, and similar platforms. Use when turning metrics into a working dashboard instead of a vanity board.
**中文释义 / Chinese interpretation：** 围绕“dashboard builder”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Dashboard Builder → When to Use → Guardrails → Workflow
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S491_api-design-principles｜api design principles
**能力摘要 / Capability summary：** Master REST and GraphQL API design principles to build intuitive, scalable, and maintainable APIs that delight developers. Use when designing new APIs, reviewing API specifications, or establishing API design standards.
**中文释义 / Chinese interpretation：** 围绕“api design principles”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** API Design Principles → When to Use This Skill → Core Concepts → 1. RESTful Design Principles
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S495_kpi-dashboard-design｜kpi dashboard design
**能力摘要 / Capability summary：** Design effective KPI dashboards with metrics selection, visualization best practices, and real-time monitoring patterns. Use this skill when building an executive SaaS metrics dashboard tracking MRR, churn, and LTV/CAC ratios; designing an operations center with live service h...
**中文释义 / Chinese interpretation：** 围绕“kpi dashboard design”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** KPI Dashboard Design → When to Use This Skill → Core Concepts → 1. KPI Framework
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S498_postgresql-table-design｜postgresql table design
**能力摘要 / Capability summary：** Use this skill when designing or reviewing a PostgreSQL-specific schema. Covers best-practices, data types, indexing, constraints, performance patterns, and advanced features
**中文释义 / Chinese interpretation：** 围绕“postgresql table design”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** PostgreSQL Table Design → When to Use → Core Rules → PostgreSQL Gotchas
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S506_tailwind-design-system｜tailwind design system
**能力摘要 / Capability summary：** Build scalable design systems with Tailwind CSS v4, design tokens, component libraries, and responsive patterns. Use when creating component libraries, implementing design systems, or standardizing UI patterns.
**中文释义 / Chinese interpretation：** 围绕“tailwind design system”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Tailwind Design System (v4) → When to Use This Skill → Key v4 Changes → Quick Start
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S520_design-system-patterns｜design system patterns
**能力摘要 / Capability summary：** Build scalable design systems with design tokens, theming infrastructure, and component architecture patterns. Use when creating design tokens, implementing theme switching, building component libraries, or establishing design system foundations.
**中文释义 / Chinese interpretation：** 围绕“design system patterns”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Design System Patterns → When to Use This Skill → Core Capabilities → 1. Design Tokens
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S521_interaction-design｜interaction design
**能力摘要 / Capability summary：** Design and implement microinteractions, motion design, transitions, and user feedback patterns. Use when adding polish to UI interactions, implementing loading states, or creating delightful user experiences.
**中文释义 / Chinese interpretation：** 围绕“interaction design”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Interaction Design → When to Use This Skill → Core Principles → 1. Purposeful Motion
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S522_responsive-design｜responsive design
**能力摘要 / Capability summary：** Implement modern responsive layouts using container queries, fluid typography, CSS Grid, and mobile-first breakpoint strategies. Use when building adaptive interfaces, implementing fluid layouts, or creating component-level responsive behavior.
**中文释义 / Chinese interpretation：** 围绕“responsive design”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Responsive Design → When to Use This Skill → Detailed patterns and worked examples → Best Practices
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S525_api-and-interface-design｜api and interface design
**能力摘要 / Capability summary：** Guides stable API and interface design. Use when designing APIs, module boundaries, or any public interface. Use when creating REST or GraphQL endpoints, defining type contracts between modules, or establishing boundaries between frontend and backend.
**中文释义 / Chinese interpretation：** 围绕“api and interface design”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** API and Interface Design → Overview → When to Use → Core Principles
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S532_frontend-ui-engineering｜frontend ui engineering
**能力摘要 / Capability summary：** Builds production-quality, accessible, responsive user-facing UIs. Use when building or modifying interfaces and pages, creating components, implementing layouts, meeting WCAG accessibility requirements, managing state, or when the output needs to look and feel production-qual...
**中文释义 / Chinese interpretation：** 围绕“frontend ui engineering”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Frontend UI Engineering → Overview → When to Use → Component Architecture
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S547_backend-to-frontend-handoff-docs｜backend to frontend handoff docs
**能力摘要 / Capability summary：** Create API handoff documentation for frontend developers. Use when backend work is complete and needs to be documented for frontend integration, or user says 'create handoff', 'document API', 'frontend handoff', or 'API documentation'.
**中文释义 / Chinese interpretation：** 围绕“backend to frontend handoff docs”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** API Handoff Mode → Goal → Inputs → Workflow
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S555_design-system-starter｜design system starter
**能力摘要 / Capability summary：** Create and evolve design systems with design tokens, component architecture, accessibility guidelines, and documentation templates. Ensures consistent, scalable, and accessible UI across products.
**中文释义 / Chinese interpretation：** 围绕“design system starter”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Design System Starter → Quick Start → Triggers → Quick Reference
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S558_draw-io｜draw io
**能力摘要 / Capability summary：** draw.io diagram creation, editing, and review. Use for .drawio XML editing, PNG conversion, layout adjustment, and the configured platform icon usage.
**中文释义 / Chinese interpretation：** 围绕“draw io”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** draw.io Diagram Skill → 1. Basic Rules → 2. Font Settings → 3. Conversion Commands
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S559_excalidraw｜excalidraw
**能力摘要 / Capability summary：** Use when working with *.excalidraw or *.excalidraw.json files, user mentions diagrams/flowcharts, or requests architecture visualization - delegates all Excalidraw operations to subagents to prevent context exhaustion from verbose JSON (single files: 4k-22k tokens, can exceed ...
**中文释义 / Chinese interpretation：** 围绕“excalidraw”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Excalidraw Subagent Delegation → Overview → The Problem → When to Use
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S561_frontend-to-backend-requirements｜frontend to backend requirements
**能力摘要 / Capability summary：** Document frontend data needs for backend developers. Use when frontend needs to communicate API requirements to backend, or user says 'backend requirements', 'what data do I need', 'API requirements', or is describing data needs for a UI.
**中文释义 / Chinese interpretation：** 围绕“frontend to backend requirements”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Backend Requirements Mode → The Point → What You Own vs. What Backend Owns → Workflow
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S567_mermaid-diagrams｜mermaid diagrams
**能力摘要 / Capability summary：** Comprehensive guide for creating software diagrams using Mermaid syntax. Use when users need to create, visualize, or document software through diagrams including class diagrams (domain modeling, object-oriented design), sequence diagrams (application flows, API interactions, ...
**中文释义 / Chinese interpretation：** 围绕“mermaid diagrams”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Mermaid Diagramming → Core Syntax Structure → Diagram Type Selection Guide → Quick Start Examples
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S568_mui｜mui
**能力摘要 / Capability summary：** Material-UI v7 component library patterns including sx prop styling, theme integration, responsive design, and MUI-specific hooks. Use when working with MUI components, styling with sx prop, theme customization, or MUI utilities.
**中文释义 / Chinese interpretation：** 围绕“mui”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** MUI v7 Patterns → Purpose → When to Use This Skill → Quick Start
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S574_react-dev｜react dev
**能力摘要 / Capability summary：** This skill should be used when building React components with TypeScript, typing hooks, handling events, or when React TypeScript, React 19, Server Components are mentioned. Covers type-safe patterns for React 18-19 including generic components, proper event typing, and routin...
**中文释义 / Chinese interpretation：** 围绕“react dev”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** React TypeScript
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S575_react-useeffect｜react useeffect
**能力摘要 / Capability summary：** React useEffect best practices from official docs. Use when writing/reviewing useEffect, useState for derived values, data fetching, or state synchronization. Teaches when NOT to use Effect and better alternatives.
**中文释义 / Chinese interpretation：** 围绕“react useeffect”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** You Might Not Need an Effect → Quick Reference → When You DO Need Effects → When You DON'T Need Effects
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S577_requirements-clarity｜requirements clarity
**能力摘要 / Capability summary：** Clarify ambiguous requirements through focused dialogue before implementation. Use when requirements are unclear, features are complex (>2 days), or involve cross-team coordination. Ask two core questions - Why? (YAGNI check) and Simpler? (KISS check) - to ensure clarity befor...
**中文释义 / Chinese interpretation：** 围绕“requirements clarity”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Requirements Clarity Skill → Description → Instructions → Core Principles
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S583_acquire-codebase-knowledge｜acquire codebase knowledge
**能力摘要 / Capability summary：** Use this skill when the user explicitly asks to map, document, or onboard into an existing codebase. Trigger for prompts like "map this codebase", "document this architecture", "onboard me to this repo", or "create codebase docs". Do not trigger for routine feature implementat...
**中文释义 / Chinese interpretation：** 围绕“acquire codebase knowledge”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Acquire Codebase Knowledge → Output Contract (Required) → Workflow → Focus Area Mode
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S591_anti-ui-slop｜anti ui slop
**能力摘要 / Capability summary：** Stop coding agents from shipping generic UI. Use UIZZE''s 800,000+ real web and iOS screens to build product-specific interfaces, define a design contract, cover required states, and run a hard finish gate. Use when designing, implementing, redesigning, critiquing, or pre-ship...
**中文释义 / Chinese interpretation：** 围绕“anti ui slop”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Stop Making UI Slop → Overview → Prerequisites → Authentication
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S623_penpot-uiux-design｜penpot uiux design
**能力摘要 / Capability summary：** Comprehensive guide for creating professional UI/UX designs in Penpot using MCP tools. Use this skill when: (1) Creating new UI/UX designs for web, mobile, or desktop applications, (2) Building design systems with components and tokens, (3) Designing dashboards, forms, navigat...
**中文释义 / Chinese interpretation：** 围绕“penpot uiux design”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Penpot UI/UX Design Guide → Available MCP Tools → MCP Server Setup → Before Setup: Check If Already Running
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S629_premium-frontend-ui｜premium frontend ui
**能力摘要 / Capability summary：** A comprehensive guide for GitHub Copilot to craft immersive, high-performance web experiences with advanced motion, typography, and architectural craftsmanship.
**中文释义 / Chinese interpretation：** 围绕“premium frontend ui”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Immersive Frontend UI Craftsmanship → 1. Establishing the Creative Foundation → 2. Structural Requirements for Immersive UI → 2.1 The Entry Sequence (Preloading & Initialization)
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S632_python-pypi-package-builder｜python pypi package builder
**能力摘要 / Capability summary：** End-to-end skill for building, testing, linting, versioning, and publishing a production-grade Python library to PyPI. Covers all four build backends (setuptools+setuptools_scm, hatchling, flit, poetry), PEP 440 versioning, semantic versioning, dynamic git-tag versioning, OOP/...
**中文释义 / Chinese interpretation：** 围绕“python pypi package builder”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Python PyPI Package Builder Skill → Quick Navigation → 1. Skill Trigger → 2. Package Type Decision
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S634_react19-concurrent-patterns｜react19 concurrent patterns
**能力摘要 / Capability summary：** Preserve React 18 concurrent patterns and adopt React 19 APIs (useTransition, useDeferredValue, Suspense, use(), useOptimistic, Actions) during migration.
**中文释义 / Chinese interpretation：** 围绕“react19 concurrent patterns”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** React 19 Concurrent Patterns → Part 1 Preserve: React 18 Concurrent Patterns That Must Survive the Migration → createRoot Already Migrated by the R18 Orchestra → useTransition No Migration Needed
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S635_react19-source-patterns｜react19 source patterns
**能力摘要 / Capability summary：** Reference for React 19 source-file migration patterns, including API changes, ref handling, and context updates.
**中文释义 / Chinese interpretation：** 围绕“react19 source patterns”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** React 19 Source Migration Patterns → Quick Reference Table → PropTypes Rule → Read the Reference
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S643_ui-screenshots｜ui screenshots
**能力摘要 / Capability summary：** Capture screenshots of web apps during development using Playwright and PIL. Supports full-page captures, interactive states, and an iterate-on-crop workflow that avoids slow re-screenshots.
**中文释义 / Chinese interpretation：** 围绕“ui screenshots”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** UI Screenshots → When to Use This Skill → Prerequisites → Core Workflow
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S645_web-design-reviewer｜web design reviewer
**能力摘要 / Capability summary：** This skill enables visual inspection of websites running locally or remotely to identify and fix design issues. Triggers on requests like "review website design", "check the UI", "fix the layout", "find design problems". Detects issues with responsive design, accessibility, vi...
**中文释义 / Chinese interpretation：** 围绕“web design reviewer”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Web Design Reviewer → Scope of Application → Prerequisites → Required
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S656_dart-build-cli-app｜dart build cli app
**能力摘要 / Capability summary：** Entrypoint structure, exit codes, cross-platform scripts. Use when building command line utilities, scripts, or applications.
**中文释义 / Chinese interpretation：** 围绕“dart build cli app”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Building Dart CLI Applications → Contents → Project Setup & Architecture → Argument Parsing & Command Routing
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S674_kotlin-tooling-native-build-performance｜kotlin tooling native build performance
**能力摘要 / Capability summary：** Diagnoses and fixes slow Kotlin/Native compilation and linking in Kotlin Multiplatform projects that target iOS. Use when the user reports slow iOS or shared-framework builds, long linkDebug*/linkRelease* or XCFramework tasks, cold CI builds that re-download the Kotlin/Native ...
**中文释义 / Chinese interpretation：** 围绕“kotlin tooling native build performance”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Kotlin/Native Build Performance → Step 0: Classify the Slow Scenario → Step 1: Audit and Measure → Step 2: Fix in Safe Order
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S688_author-component｜author component
**能力摘要 / Capability summary：** Create or review Blazor components (.razor files) with correct architecture. USE FOR: writing new Blazor components that do NOT involve JavaScript interop, implementing parameters and EventCallback, RenderFragment slots, component lifecycle (OnInitializedAsync, OnParametersSet...
**中文释义 / Chinese interpretation：** 围绕“author component”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Author Blazor Component → Core Rules → RenderFragment & Generics → File Patterns
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S690_coordinate-components｜coordinate components
**能力摘要 / Capability summary：** Share state between components that don't have a direct parent-child parameter relationship, using cascading values, scoped services with change events, or CascadingValueSource via DI. USE WHEN the user needs a CascadingParameter or CascadingValue that works across render mode...
**中文释义 / Chinese interpretation：** 围绕“coordinate components”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Coordinate Components → Step 1 — Read AGENTS.md → Step 2 — Decide the scope → Workflow (quick reference)
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S693_plan-ui-change｜plan ui change
**能力摘要 / Capability summary：** Plan complex Blazor UI features by decomposing them into focused components. USE FOR: building a complex Blazor page with multiple sections, planning component decomposition, designing a multi-section dashboard or layout, breaking down a large UI feature into composable compon...
**中文释义 / Chinese interpretation：** 围绕“plan ui change”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Plan a Blazor UI Change → Planning Workflow → Step 1 — Map the Visual Regions → Step 2 — Classify Each Component
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S704_build-parallelism｜build parallelism
**能力摘要 / Capability summary：** Diagnose and fix under-parallelized MSBuild builds. USE WHEN a multi-project solution build is slower than expected, doesn't speed up when you add cores, pegs a single core while others idle, or you want to know why `-m` isn't helping. Note: `/maxcpucount` default is 1 (sequen...
**中文释义 / Chinese interpretation：** 围绕“build parallelism”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Diagnose a slow parallel build (start here) → MSBuild Parallelism Model → Project Dependency Graph → Graph Build Mode (`/graph`)
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S705_build-perf-baseline｜build perf baseline
**能力摘要 / Capability summary：** Establish build performance baselines and apply systematic optimization techniques. USE FOR: diagnosing slow builds, establishing before/after measurements (cold, warm, no-op scenarios), applying optimization strategies like static graph builds, artifacts output, and dependenc...
**中文释义 / Chinese interpretation：** 围绕“build perf baseline”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Build Performance Baseline & Optimization → Overview → Step 1: Establish a Performance Baseline → Cold Build (First Build)
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S706_build-perf-diagnostics｜build perf diagnostics
**能力摘要 / Capability summary：** Diagnose MSBuild build performance bottlenecks using binary log analysis. USE FOR: identifying why builds are slow by analyzing binlog performance summaries, detecting ResolveAssemblyReference (RAR) taking >5s, Roslyn analyzers consuming >30% of Csc time, single targets domina...
**中文释义 / Chinese interpretation：** 围绕“build perf diagnostics”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Performance Analysis Methodology → Alternate flow when MCP is unavailable: binlog replay to text logs → Key Metrics and Thresholds → Common Bottlenecks
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S723_academy-guide｜academy guide
**能力摘要 / Capability summary：** Stop and check this skill before finishing any reply to a question about how to use the configured platform or a the configured platform product — it recommends matching courses, tutorials, and use cases from the configured platform Academy (academy.the configured platform.com...
**中文释义 / Chinese interpretation：** 围绕“academy guide”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** the configured platform Academy guide → Purpose → Rules → The catalog
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S724_algorithmic-art｜algorithmic art
**能力摘要 / Capability summary：** Creating algorithmic art using p5.js with seeded randomness and interactive parameter exploration. Use this when users request creating art using code, generative art, algorithmic art, flow fields, or particle systems. Create original algorithmic art rather than copying existi...
**中文释义 / Chinese interpretation：** 围绕“algorithmic art”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** ALGORITHMIC PHILOSOPHY CREATION → THE CRITICAL UNDERSTANDING → HOW TO GENERATE AN ALGORITHMIC PHILOSOPHY → PHILOSOPHY EXAMPLES
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S725_canvas-design｜canvas design
**能力摘要 / Capability summary：** Create beautiful visual art in .png and .pdf documents using design philosophy. You should use this skill when the user asks to create a poster, piece of art, design, or other static piece. Create original visual designs, never copying existing artists' work to avoid copyright...
**中文释义 / Chinese interpretation：** 围绕“canvas design”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** DESIGN PHILOSOPHY CREATION → THE CRITICAL UNDERSTANDING → HOW TO GENERATE A VISUAL PHILOSOPHY → PHILOSOPHY EXAMPLES
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S727_frontend-design｜frontend design
**能力摘要 / Capability summary：** Guidance for distinctive, intentional visual design when building new UI or reshaping an existing one. Helps with aesthetic direction, typography, and making choices that don't read as templated defaults.
**中文释义 / Chinese interpretation：** 围绕“frontend design”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Frontend Design → Ground your designs in the subject matter → Design principles → Process: plan, review against the brief, build, critique
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S731_slack-gif-creator｜slack gif creator
**能力摘要 / Capability summary：** Knowledge and utilities for creating animated GIFs optimized for Slack. Provides constraints, validation tools, and animation concepts. Use when users request animated GIFs for Slack like "make me a GIF of X doing Y for Slack.
**中文释义 / Chinese interpretation：** 围绕“slack gif creator”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Slack GIF Creator → Slack Requirements → Core Workflow → 1. Create builder
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S732_theme-factory｜theme factory
**能力摘要 / Capability summary：** Toolkit for styling artifacts with a theme. These artifacts can be slides, docs, reportings, HTML landing pages, etc. There are 10 pre-set themes with colors/fonts that you can apply to any artifact that has been creating, or can generate a new theme on-the-fly.
**中文释义 / Chinese interpretation：** 围绕“theme factory”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Theme Factory Skill → Purpose → Usage Instructions → Themes Available
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S733_web-artifacts-builder｜web artifacts builder
**能力摘要 / Capability summary：** Suite of tools for creating elaborate, multi-component the configured platform.ai HTML artifacts using modern frontend web technologies (React, Tailwind CSS, shadcn/ui). Use for complex artifacts requiring state management, routing, or shadcn/ui components - not for simple sin...
**中文释义 / Chinese interpretation：** 围绕“web artifacts builder”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Web Artifacts Builder → Design & Style Guidelines → Quick Start → Step 1: Initialize Project
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S754_tailwind-best-practices｜tailwind best practices
**能力摘要 / Capability summary：** Write Tailwind CSS following practices that keep a fast-to-write codebase maintainable — use design tokens instead of magic values, keep class lists short, group tokens semantically, generate classes in consistent order, avoid @apply for extracting repeated styles, and use fix...
**中文释义 / Chinese interpretation：** 围绕“tailwind best practices”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Tailwind CSS best practices → Workflow → 1. Cut unnecessary utility classes → 2. Group design tokens and name them semantically
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S755_api-and-interface-design｜api and interface design
**能力摘要 / Capability summary：** Guides stable API and interface design. Use when designing APIs, module boundaries, or any public interface. Use when creating REST or GraphQL endpoints, defining type contracts between modules, or establishing boundaries between frontend and backend.
**中文释义 / Chinese interpretation：** 围绕“api and interface design”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** API and Interface Design → Overview → When to Use → Core Principles
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S765_frontend-ui-engineering｜frontend ui engineering
**能力摘要 / Capability summary：** Builds production-quality UIs. Use when building or modifying user-facing interfaces. Use when creating components, implementing layouts, managing state, or when the output needs to look and feel production-quality rather than AI-generated.
**中文释义 / Chinese interpretation：** 围绕“frontend ui engineering”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Frontend UI Engineering → Overview → When to Use → Component Architecture
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S115_grill-me｜grill me
**能力摘要 / Capability summary：** A relentless interview to sharpen a plan or design.
**中文释义 / Chinese interpretation：** 围绕“grill me”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** 确认输入 → 执行候选技能核心处理 → 检查结果和异常 / confirm inputs → execute the candidate core operation → check results and anomalies
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S118_tdd｜tdd
**能力摘要 / Capability summary：** Test-driven development. Use when the user wants to build features or fix bugs test-first, mentions "red-green-refactor", or wants integration tests.
**中文释义 / Chinese interpretation：** 围绕“tdd”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Test-Driven Development → What a good test is → Seams: where tests go → Anti-patterns
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S119_grilling｜grilling
**能力摘要 / Capability summary：** Grill the user relentlessly about a plan, decision, or idea. Use when the user wants to stress-test their thinking, or uses any 'grill' trigger phrases.
**中文释义 / Chinese interpretation：** 围绕“grilling”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** 确认输入 → 执行候选技能核心处理 → 检查结果和异常 / confirm inputs → execute the candidate core operation → check results and anomalies
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S125_to-spec｜to spec
**能力摘要 / Capability summary：** Turn the current conversation into a spec and publish it to the project issue tracker: no interview, just synthesis of what you've already discussed.
**中文释义 / Chinese interpretation：** 围绕“to spec”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Process → Problem Statement → Solution → User Stories
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S126_to-tickets｜to tickets
**能力摘要 / Capability summary：** Break a plan, spec, or the current conversation into a set of tracer-bullet tickets, each declaring its blocking edges, published to the configured tracker (edges as text in one file per ticket locally, or native blocking links on a real tracker).
**中文释义 / Chinese interpretation：** 围绕“to tickets”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** To Tickets → Process → 1. Gather context → 2. Explore the codebase (optional)
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S127_brainstorming｜brainstorming
**能力摘要 / Capability summary：** You MUST use this before any creative work - creating features, building components, adding functionality, or modifying behavior. Explores user intent, requirements and design before implementation.
**中文释义 / Chinese interpretation：** 围绕“brainstorming”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Brainstorming Ideas Into Designs → Three Paths → Anti-Pattern: "Too Simple To Need Approval" → Red Flags
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S129_executing-plans｜executing plans
**能力摘要 / Capability summary：** Use when you have a written implementation plan to execute in a separate session with review checkpoints
**中文释义 / Chinese interpretation：** 围绕“executing plans”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Executing Plans → Overview → The Process → Step 1: Load and Review Plan
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S139_writing-plans｜writing plans
**能力摘要 / Capability summary：** Use when you have a spec or requirements for a multi-step task, before touching code
**中文释义 / Chinese interpretation：** 围绕“writing plans”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Writing Plans → Overview → Scope Check → File Structure
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S215_doc-coauthoring｜doc coauthoring
**能力摘要 / Capability summary：** Guide users through a structured workflow for co-authoring documentation. Use when user wants to write documentation, proposals, technical specs, decision docs, or similar structured content. This workflow helps users efficiently transfer context, refine content through iterat...
**中文释义 / Chinese interpretation：** 围绕“doc coauthoring”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Doc Co-Authoring Workflow → When to Offer This Workflow → Stage 1: Context Gathering → Initial Questions
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S228_sred-project-organizer｜sred project organizer
**能力摘要 / Capability summary：** Take a list of projects and their related documentation, and organize them into the SRED format for submission.
**中文释义 / Chinese interpretation：** 围绕“sred project organizer”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** SRED Project Organization → Prerequisites → Process → Step 1
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S229_sred-work-summary｜sred work summary
**能力摘要 / Capability summary：** Go back through the previous year of work and create a Notion doc that groups relevant links into projects that can then be documented as SRED projects.
**中文释义 / Chinese interpretation：** 围绕“sred work summary”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** SRED Work Summary → Prerequisites → Process → Step 1
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S245_wayfinder｜wayfinder
**能力摘要 / Capability summary：** Plan a huge chunk of work (more than one agent session can hold) as a shared map of decision tickets on your issue tracker, and resolve them one at a time until the way to the destination is clear.
**中文释义 / Chinese interpretation：** 围绕“wayfinder”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Plan, don't do → Refer by name → The Map → The map body
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S246_wizard｜wizard
**能力摘要 / Capability summary：** Generate an interactive bash wizard that walks a human through steps only they can perform. Use when provisioning infrastructure, setting up credentials or CI secrets, walking an unfamiliar third-party dashboard, or running a one-off migration or cutover. Don't invoke this for...
**中文释义 / Chinese interpretation：** 围绕“wizard”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Wizard → Process → 1. Scope the procedure → 2. Map each stage's journey
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S249_loop-me｜loop me
**能力摘要 / Capability summary：** Grill me about specs for the workflows I want to build, within this workspace.
**中文释义 / Chinese interpretation：** 围绕“loop me”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** The loop lens → Vocabulary → Definition of done → The workspace
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S250_retro｜retro
**能力摘要 / Capability summary：** Conduct a retrospective on a coding session.
**中文释义 / Chinese interpretation：** 围绕“retro”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Steps → Reference → Implementation vs Review → Files
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S252_writing-beats｜writing beats
**能力摘要 / Capability summary：** Writing, exploit; assemble raw material into a journey of beats, grounding each term before a beat leans on it.
**中文释义 / Chinese interpretation：** 围绕“writing beats”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Grounding → What is a beat → Pulling from the pile → Ending the journey
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S254_writing-shape｜writing shape
**能力摘要 / Capability summary：** Writing, exploit: shape raw material into an article, paragraph by paragraph.
**中文释义 / Chinese interpretation：** 围绕“writing shape”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** The loop → Grounding → Conversational feel → Pulling from the pile
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S259_handoff｜handoff
**能力摘要 / Capability summary：** Compact the current conversation into a handoff document for another agent to pick up.
**中文释义 / Chinese interpretation：** 围绕“handoff”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** 确认输入 → 执行候选技能核心处理 → 检查结果和异常 / confirm inputs → execute the candidate core operation → check results and anomalies
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S260_teach｜teach
**能力摘要 / Capability summary：** Teach the user a new skill or concept, within this workspace.
**中文释义 / Chinese interpretation：** 围绕“teach”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Teaching Workspace → Philosophy → Fluency vs Storage Strength → Lessons
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S261_to-questionnaire｜to questionnaire
**能力摘要 / Capability summary：** Turn a decision you can't fully answer into a questionnaire for someone else to fill in.
**中文释义 / Chinese interpretation：** 围绕“to questionnaire”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Document structure → <Questionnaire title> → Context → How to answer
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S262_wait-what｜wait what
**能力摘要 / Capability summary：** Stop. That last message did not land: re-pitch it.
**中文释义 / Chinese interpretation：** 围绕“wait what”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** 确认输入 → 执行候选技能核心处理 → 检查结果和异常 / confirm inputs → execute the candidate core operation → check results and anomalies
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S468_nextjs-turbopack｜nextjs turbopack
**能力摘要 / Capability summary：** Next.js 16+ and Turbopack — incremental bundling, FS caching, dev speed, and when to use Turbopack vs webpack.
**中文释义 / Chinese interpretation：** 围绕“nextjs turbopack”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Next.js and Turbopack → When to Use → How It Works → Examples
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S469_product-capability｜product capability
**能力摘要 / Capability summary：** Translate PRD intent, roadmap asks, or product discussions into an implementation-ready capability plan that exposes constraints, invariants, interfaces, and unresolved decisions before multi-service work starts. Use when the user needs an ECC-native PRD-to-SRS lane instead of...
**中文释义 / Chinese interpretation：** 围绕“product capability”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Product Capability → When to Use → Canonical Artifact → Non-Negotiable Rules
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S470_product-lens｜product lens
**能力摘要 / Capability summary：** Use this skill to validate the "why" before building, run product diagnostics, and pressure-test product direction before the request becomes an implementation contract.
**中文释义 / Chinese interpretation：** 围绕“product lens”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Product Lens — Think Before You Build → When to Use → How It Works → Mode 1: Product Diagnostic
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S474_repo-scan｜repo scan
**能力摘要 / Capability summary：** Bootstrap pointer that installs the external repo-scan skill from a pinned, reviewable commit. Use when repo-scan must be installed before running its cross-stack source-code asset audit; this ECC pointer does not perform the audit itself.
**中文释义 / Chinese interpretation：** 围绕“repo scan”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** repo-scan → When to Use → Installation → Clone first so the pinned commit can be reviewed before installation
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S479_terminal-ops｜terminal ops
**能力摘要 / Capability summary：** Evidence-first repo execution workflow for ECC. Use when the user wants a command run, a repo checked, a CI failure debugged, or a narrow fix pushed with exact proof of what was executed and verified.
**中文释义 / Chinese interpretation：** 围绕“terminal ops”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Terminal Ops → Skill Stack → When to Use → Guardrails
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S489_parallel-feature-development｜parallel feature development
**能力摘要 / Capability summary：** Coordinate parallel feature development with file ownership strategies, conflict avoidance rules, and integration patterns for multi-agent implementation. Use this skill when decomposing a large feature into independent work streams, when two or more agents need to implement d...
**中文释义 / Chinese interpretation：** 围绕“parallel feature development”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Parallel Feature Development → When to Use This Skill → File Ownership Strategies → By Directory
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S497_secrets-management｜secrets management
**能力摘要 / Capability summary：** Implement secure secrets management for CI/CD pipelines using Vault, the configured platform Secrets Manager, or native platform solutions. Use when handling sensitive credentials, rotating secrets, or securing CI/CD environments.
**中文释义 / Chinese interpretation：** 围绕“secrets management”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Secrets Management → Purpose → When to Use → Secrets Management Tools
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S505_nextjs-app-router-patterns｜nextjs app router patterns
**能力摘要 / Capability summary：** Master Next.js 14+ App Router with Server Components, streaming, parallel routes, and advanced data fetching. Use when building Next.js applications, implementing SSR/SSG, or optimizing React Server Components.
**中文释义 / Chinese interpretation：** 围绕“nextjs app router patterns”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Next.js App Router Patterns → When to Use This Skill → Core Concepts → 1. Rendering Modes
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S512_prometheus-configuration｜prometheus configuration
**能力摘要 / Capability summary：** Set up Prometheus for comprehensive metric collection, storage, and monitoring of infrastructure and applications. Use when implementing metrics collection, setting up monitoring infrastructure, or configuring alerting systems.
**中文释义 / Chinese interpretation：** 围绕“prometheus configuration”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Prometheus Configuration → Purpose → When to Use → Detailed patterns and worked examples
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S519_bash-defensive-patterns｜bash defensive patterns
**能力摘要 / Capability summary：** Master defensive Bash programming techniques for production-grade scripts. Use when writing robust shell scripts, CI/CD pipelines, or system utilities requiring fault tolerance and safety.
**中文释义 / Chinese interpretation：** 围绕“bash defensive patterns”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Bash Defensive Patterns → When to Use This Skill → Detailed patterns and worked examples → Best Practices Summary
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S533_performance-optimization｜performance optimization
**能力摘要 / Capability summary：** Optimizes application performance across frontend, backend, queries, and databases. Use when performance requirements exist, when you suspect performance regressions, when Core Web Vitals or load times need improvement, when N+1 query patterns need fixing, or when profiling re...
**中文释义 / Chinese interpretation：** 围绕“performance optimization”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Performance Optimization → Overview → When to Use → Core Web Vitals Targets
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S584_add-educational-comments｜add educational comments
**能力摘要 / Capability summary：** Add educational comments to the file specified, or prompt asking for file to comment if one is not provided.
**中文释义 / Chinese interpretation：** 围绕“add educational comments”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Add Educational Comments → Role → Objectives → Line Count Guidance
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S597_create-readme｜create readme
**能力摘要 / Capability summary：** Create a README.md file for the project
**中文释义 / Chinese interpretation：** 围绕“create readme”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Role → Task
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S637_readme-blueprint-generator｜readme blueprint generator
**能力摘要 / Capability summary：** Intelligent README.md generation prompt that analyzes project documentation structure and creates comprehensive repository documentation. Scans .github/copilot directory files and copilot-instructions.md to extract project information, technology stack, architecture, developme...
**中文释义 / Chinese interpretation：** 围绕“readme blueprint generator”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** README Generator Prompt → Project Name and Description → Technology Stack → Project Architecture
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S737_writing-rules｜writing rules
**能力摘要 / Capability summary：** This skill should be used when the user asks to "create a hookify rule", "write a hook rule", "configure hookify", "add a hookify rule", or needs guidance on hookify rule syntax and patterns.
**中文释义 / Chinese interpretation：** 围绕“writing rules”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Writing Hookify Rules → Overview → Rule File Format → Basic Structure
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S749_session-report｜session report
**能力摘要 / Capability summary：** Generate an explorable HTML report of the configured platform Code session usage (tokens, cache, subagents, skills, expensive prompts) from ~/.the configured platform/projects transcripts.
**中文释义 / Chinese interpretation：** 围绕“session report”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Session Report → Steps → Notes
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### S750_good-readme｜good readme
**能力摘要 / Capability summary：** Write or improve a README.md for an open source project. Use this for any request to create, rewrite, review, or polish a README, project description, or "getting started" docs for a library, framework, or tool, or to make an open source project more popular or attractive to u...
**中文释义 / Chinese interpretation：** 围绕“good readme”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Write a good README → Structure: a "progressive JPEG" → 0. Clean up → 1. Opening block
**标准产出 / Standard outputs：** 可复核产物、中间结果、来源和失败清单 / reviewable artifact, intermediate results, sources, and failure list
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### 13__科研法律__科研_科研研究全流程__ResearchHound__research-hound｜13 科研法律 科研 科研研究全流程 ResearchHound research hound
**能力摘要 / Capability summary：** Scientific research workflow: literature review, citation verification, claim audits, IMRaD/PRISMA linting, rubric scoring. Use for papers, systematic reviews, peer review, methods, p-hacking.
**中文释义 / Chinese interpretation：** 围绕“13 科研法律 科研 科研研究全流程 ResearchHound research hound”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Research → Two ways to use this skill → The pipeline → Entering mid-pipeline
**标准产出 / Standard outputs：** 结构化数据、分析结果、假设、局限和复核项 / structured data, analysis, assumptions, limits, and review items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### 13__科研法律__科研_论文评审__DeerFlow__academic-paper-review｜13 科研法律 科研 论文评审 DeerFlow academic paper review
**能力摘要 / Capability summary：** Use this skill when the user requests to review, analyze, critique, or summarize academic papers, research articles, preprints, or scientific publications. Supports comprehensive structured reviews covering methodology assessment, contribution evaluation, literature positionin...
**中文释义 / Chinese interpretation：** 围绕“13 科研法律 科研 论文评审 DeerFlow academic paper review”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Academic Paper Review Skill → Overview → Core Capabilities → When to Use This Skill
**标准产出 / Standard outputs：** 结构化数据、分析结果、假设、局限和复核项 / structured data, analysis, assumptions, limits, and review items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### 13__科研法律__科研_文献综述与证据综合__Skillz__literature-review｜13 科研法律 科研 文献综述与证据综合 Skillz literature review
**能力摘要 / Capability summary：** Conduct systematic scientific literature reviews by integrating multi-source searches, iterative analysis, and synthesis into well-structured reports with proper citations.
**中文释义 / Chinese interpretation：** 围绕“13 科研法律 科研 文献综述与证据综合 Skillz literature review”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Scientific Literature Review Skill → Overview → When to Use This Skill → CRITICAL: Citation Verification Requirements
**标准产出 / Standard outputs：** 结构化数据、分析结果、假设、局限和复核项 / structured data, analysis, assumptions, limits, and review items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.

### 13__科研法律__科研_系统文献综述__DeerFlow__systematic-literature-review｜13 科研法律 科研 系统文献综述 DeerFlow systematic literature review
**能力摘要 / Capability summary：** Use this skill when the user wants a systematic literature review, survey, or synthesis across multiple academic papers on a topic. Also covers annotated bibliographies and cross-paper comparisons. Searches arXiv and outputs reports in APA, IEEE, or BibTeX format. Not for sing...
**中文释义 / Chinese interpretation：** 围绕“13 科研法律 科研 系统文献综述 DeerFlow systematic literature review”处理授权输入，按照来源摘要和关键动作完成任务，并输出可复核结果、异常和待确认项。
**触发条件 / Trigger：** 输入目标与该技能用途相符，且资料、权限、地区和输出格式已明确 / Use when the requested outcome matches this capability and the inputs, permissions, locale, and output format are clear.
**关键动作 / Key actions：** Systematic Literature Review Skill → Overview → When to Use This Skill → Workflow
**标准产出 / Standard outputs：** 结构化数据、分析结果、假设、局限和复核项 / structured data, analysis, assumptions, limits, and review items
**失败边界 / Failure boundary：** 输入不足、来源冲突、权限不明、解析失败或需要外部不可逆动作时停止并进入待确认队列 / Stop and enter review when inputs are missing, sources conflict, permissions are unclear, parsing fails, or an irreversible external action is required.
## 16. 技能收集、自我编辑与Token预算 / Skill collection, self-editing, and token budget

本员工使用“候选→验证→激活→弃用”的生命周期。对本地、自研或GitHub候选，先记录规范名称、用途、触发条件、输入、关键动作、输出、失败边界、来源、许可证、依赖、权限、语言、版本、证据、最后验证时间和运行状态，再去重、审查、生成双语配方并执行固定用例。许可证、依赖、权限或运行状态不明时保持candidate或blocked。

This employee uses a candidate→verified→active→deprecated lifecycle. For local, self-developed, or GitHub candidates, record the normalized name, purpose, triggers, inputs, key actions, outputs, failure boundaries, source, license, dependencies, permissions, locales, version, evidence, last verification time, and runtime status before deduplication, review, bilingual recipe generation, and fixed-case testing. Unknown license, dependencies, permissions, or runtime status remain candidate or blocked.

自我编辑只生成变更提案，不直接覆盖当前版本：

```text
observe_result
→ extract_success_failure_evidence_without_secrets
→ detect_repeated_failure_or_verified_improvement
→ create_diff(old_version, new_delta, evidence, affected_cases)
→ check_safety_gates_and_locale_consistency
→ run_shadow_regression(normal, missing_input, conflict, high_risk)
→ pass: stage_for_approval; fail: keep_current_and_open_review
→ approved: version_bump + changelog + rollback_pointer
```

允许提出的变更：补充已验证触发词、澄清步骤、增加失败边界、修复双语表达、更新已证实的输出格式。禁止自动修改安全门禁、审批要求、专业免责声明、来源许可结论、事实证据以及发送、付款、删除、录用、签约等外部动作权限。每次变更必须保留旧版本、差异、证据、测试结果、批准人和回滚点。

Allowed proposals include verified triggers, clearer steps, stronger failure boundaries, bilingual corrections, and proven output-format updates. Never auto-change safety gates, approval rules, professional disclaimers, license conclusions, evidence, or authority to send, pay, delete, hire, or sign. Preserve the old version, diff, evidence, test results, approver, and rollback pointer for every change.

变更提案最小输出 / Minimum change proposal:

```json
{"change_id":"EV-YYYYMMDD-NNN","target_skill":"skill_id","old_version":"x.y.z","new_delta":"最小差异","evidence_refs":[],"regression_cases":[],"risk":"low|medium|high","status":"pending_approval","rollback":"old_version"}
```

提案缺少证据、回归用例、风险等级或回滚点时，状态必须保持`blocked`，不得激活。 / If evidence, regression cases, risk, or rollback is missing, keep the proposal `blocked` and do not activate it.

Token估算：`T_call = T_shell + T_core + K×T_recipe + T_evidence + T_history + T_output_reserve`。K是本次真正选中的配方数，默认3—7，复杂任务最多先取10；禁止因为文件中有很多候选就全量加载。宿主有真实tokenizer时记录真实值，否则用UTF-8字节数/3.5至/4.5估算并标记为估算。

Token estimate: `T_call = T_shell + T_core + K×T_recipe + T_evidence + T_history + T_output_reserve`. K is the number of recipes actually selected, normally 3—7 and at most 10 initially for complex work. Never load all candidates merely because they exist. Use the host tokenizer when available; otherwise estimate with UTF-8 bytes divided by 3.5 to 4.5 and label it estimated.

调用档位：fast输入≤8k、输出预留2k；standard输入≤16k、输出预留4k；deep输入≤28k、输出预留8k。超过上限时压缩历史、减少候选、拆分任务或请求扩容，不得删除安全规则。记录输入/输出token、候选数、核心模块数、首轮完成率、重试、证据完整率、越权阻断率、人工修改比例、耗时和单位成本；只有质量不下降且输入token下降，才接受优化。

Call tiers: fast input≤8k with 2k output reserve; standard input≤16k with 4k output reserve; deep input≤28k with 8k output reserve. Above a limit, summarize history, reduce candidates, split the task, or request more context; never remove safety rules. Record input/output tokens, selected recipes, core modules, first-pass completion, retries, evidence completeness, unauthorized-action blocking, human-edit rate, latency, and cost per task. Accept an optimization only when quality does not regress and input tokens decrease.
### 缓存与压缩策略 / Cache and compression strategy

使用内容寻址缓存：`cache_key = sha256(skill_id|source_version|locale|host_model|task_signature)`。缓存分为路由/安全规则、已验证配方、核验过的证据摘要和幂等结果四层；技能版本、来源版本、语言、模型、权限、证据有效期或任务签名变化时立即失效。许可证待审、权限变化、冲突证据和外部动作状态不得命中旧缓存。

Use content-addressed caching: `cache_key = sha256(skill_id|source_version|locale|host_model|task_signature)`. Cache routing/safety rules, verified recipes, verified evidence summaries, and idempotent results as separate layers. Invalidate when skill version, source version, locale, model, permissions, evidence freshness, or task signature changes. Never reuse stale cache for pending licenses, changed permissions, conflicting evidence, or external-action state.

压缩只删除重复模板，不删除事实、动作、证据或失败边界。历史对话使用带来源和版本的摘要；禁止缓存密钥、个人敏感数据、审批凭证、付款状态和未脱敏输入。记录缓存命中率、失效率、陈旧命中、节省Token和缓存相关回滚次数。

Compression removes duplicated boilerplate only; it never removes facts, actions, evidence, or failure boundaries. Summarize history with source and version metadata. Never cache secrets, personal data, approval credentials, payment state, or unsanitized input. Record hit rate, invalidations, stale hits, tokens saved, and cache-related rollbacks.

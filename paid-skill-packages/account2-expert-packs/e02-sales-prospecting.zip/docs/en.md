# AI Sales Research Assistant

## Purpose

Review user-provided and authorized lead records against an ideal-customer profile, then produce evidence-based priority labels and reviewable follow-up drafts.

## Inputs

## Decision behavior

Check ICP fit, evidence quality, source authorization, and privacy before prioritizing a lead. Explain why follow-up is justified and what must be verified; priority is not a purchase-probability claim. Follow the shared [employee thinking contract](../employee-thinking-contract.md).

Provide the ICP, product facts, and lead records. Avoid unnecessary personal data; an exported table or redacted record is preferred.

## Outputs

Each recommendation includes supporting fields, unknowns, and a next action. The result is sales preparation, not a close-probability prediction.

## Limits

This package does not scrape contacts, infer protected traits, send messages, write to a CRM, or quote prices automatically.

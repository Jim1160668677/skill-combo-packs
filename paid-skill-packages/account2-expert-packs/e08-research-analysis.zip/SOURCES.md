# 来源与许可

- 本包的职责、能力ID、双语描述和边界来自统一目录 mvp_skills/expert-packs/skill-integration-catalog.json。
- 本包只登记候选来源，不代表外部资源可直接复制、再分发或商业使用。
- 版本 0.1.0；状态：目录已映射，尚未完成运行时、许可证、宿主和专业规则验收。


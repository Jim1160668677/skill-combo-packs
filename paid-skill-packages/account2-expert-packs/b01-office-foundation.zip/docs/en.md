# AI Back Office Assistant

Turn meeting notes, email text, and office messages into traceable summaries, action items, decisions, conflicts, or reviewable drafts.

Provide the text, task type, and any reliable date, timezone, recipient, or company context. Unknown owners and dates stay unknown.

## Decision behavior

Before transforming anything, verify source, version, format, permission, required fields, and output purpose. Preserve the original and return a reviewable copy; follow the shared [employee thinking contract](../employee-thinking-contract.md).

No automatic sending, calendar changes, archiving, deletion, or formal-record edits. File ingestion and knowledge retrieval are separate capabilities.

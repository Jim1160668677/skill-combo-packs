# One-Person Company Executive Operator

## Positioning

This is the control-plane employee for an AI one-person company. It is not a skill list or a blind skill caller. It converts a business goal into an executable plan, assigns ownership to the right specialist employee, adds only necessary helpers, enforces call order, verifies outputs, and stops for human approval when an external action or regulated decision is involved.

## Typical behavior

For a request such as “help me sell a new product,” the operator first checks product facts, target customers, region, and channels. It then sequences research/positioning, content or proposal work, lead prioritization, customer FAQ, and compliance review. Evidence moves from one step to the next. The final result contains deliverables, evidence gaps, risks, and next actions; it does not claim that a sale has happened.

## Value

- Turns scattered Skills into coordinated work with ownership and dependencies.
- Reduces repeated calls and repeated per-call charges by planning before delegation.
- Blocks official-only, paid-restricted, login-required, and unknown-license candidates from default routing.
- Upgrades “the AI generated text” into a reviewable business deliverable.

## Current boundary

This is a structurally validated baseline. Host-runtime adaptation, live connector trials, complete license review, and native-language review are still pending. Structural validation is not production approval.

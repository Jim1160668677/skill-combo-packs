# O00来源与准入说明

- `../skill-integration-catalog.json`：74项共享业务/底座能力和8项总管控制能力的双语定义与来源映射。
- `../registry.json`：12个专家员工包和O00总管员工的注册信息。
- `../source-audit.json`：本地候选来源定位、许可证状态和审查状态。
- `../static-security-audit.json`：本地候选的静态安全与许可证线索筛查。
- `../source-eligibility-policy.json`：官方、付费、登录、许可证和外部候选的运行时准入规则。

O00是内部自研的控制层包装，不复制第三方Skill文本；它只按准入状态调用已审查的员工包或把缺口交给人工。

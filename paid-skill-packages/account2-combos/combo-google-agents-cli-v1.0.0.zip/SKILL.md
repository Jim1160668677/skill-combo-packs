---
name: combo-google-agents-cli
version: 1.0.0
displayName: Google ADK 智能体开发
summary: Google Agents CLI 全生命周期技能：脚手架、开发、部署、评估、可观测与发布。
description: 中文：Google ADK 智能体开发 组合技能包。Google ADK 智能体 CLI 工具链：scaffold→code→eval→observability→deploy→publish 一条龙。 包含 7 个子技能，覆盖：s177-google-agents-cli-adk-code, s178-google-agents-cli-deploy, s179-google-agents-cli-eval, s180-google-agents-cli-observability 等。每个子技能位于 skills/ 目录，可在具体任务中按需加载。English: Combo skill pack "Google ADK 智能体开发". It bundles 7 sub-skills under skills/ covering Google ADK 智能体 CLI 工具链：scaffold→code→eval→observability→deploy→publish 一条龙。.
license: MIT
tags: [skillhub, combo, pay]
category: ai-agent
---

# Google ADK 智能体开发

## 简介 / Overview

Google Agents CLI 全生命周期技能：脚手架、开发、部署、评估、可观测与发布。

Google ADK 智能体 CLI 工具链：scaffold→code→eval→observability→deploy→publish 一条龙。

本组合包包含 7 个子技能（见 skills/ 目录），按需加载对应子技能完成具体任务。

## 成员技能 / Member skills

| 子技能 slug | 说明 |
| --- | --- |
| s177-google-agents-cli-adk-code | google-agents-cli-adk-code — > |
| s178-google-agents-cli-deploy | google-agents-cli-deploy — > |
| s179-google-agents-cli-eval | google-agents-cli-eval — > |
| s180-google-agents-cli-observability | google-agents-cli-observability — > |
| s181-google-agents-cli-publish | google-agents-cli-publish — > |
| s182-google-agents-cli-scaffold | google-agents-cli-scaffold — > |
| s183-google-agents-cli-workflow | google-agents-cli-workflow — > |

## 计费与调用 / Billing & invocation

- Service URL：`https://fwskillpay-api.cn/v1/pay/skills/combo-google-agents-cli/invoke`

- 价格：¥ 0.10 / 次调用

- 支付后由 scripts/skill-paid.mjs 完成订单核验并返回结果；恢复命令 resume-pay / restage / record-poll 用于异常恢复。

## 交付说明 / Delivery notes

- 中文：本技能为 SkillPay 组合包，标题、摘要与交付边界提供中文与英文双语。
- 账号与凭证：包内不要求商户私钥、支付宝凭证或长期 Token。
- 外部服务边界：不代用户登录、抓取或调用云端服务；正文提到的工具仅在其真实可用时调用。
- 许可证：子技能来自公开免费技能池，本包按 MIT 条款再分发。
## 付费契约（支付宝 AI 按量付费，¥0.10/次）

本组合包通过登记云端付费网关（fwskillpay-api.cn）交付，必须先取得数据传输与付款授权，再按顺序执行支付助手（scripts/skill-paid.mjs）：

1. **probe**：调用前先披露登记接收方、发送数据、用途与本包单价，取得数据传输及该金额的付款授权。probe 预期返回 402 Payment-Needed 与本次真实账单（¥0.10，资源与登记一致）；400 表示输入无效、503 表示限流/队列满，均不进入 pay。未付款返回 200、暂存失败或金额不符均停止，不读取结果、不本地代做。
2. **pay**：展示 402 账单并取得付款同意后，宿主实际执行生成的官方 alipay-bot 付款指令（Payment-Proof）。helper 的 JSON 不是付款，用户完成支付；不重复等待确认，金额、资源不一致则停止不发起付款。
3. **complete / query**：付款后只查询原订单，不能重新 probe 或重复扣费。仅当同一原订单返回有效 Payment-Validation 和非空业务结果后才交付；正常流程官方 buyer-pay/query 已自动发送回执，不再独立 ACK。
4. **订单持久化与幂等**：订单状态写入包外私有状态目录，不打印、不上传；回执失败仅当官方输出明确给出交易号且用户要求恢复时，按该交易号执行恢复三命令：resume-pay / restage / record-poll。拒绝本地等价分析、提示词代做、缓存交付或免费回退。

English: This combo pack delivers through the registered paid gateway (fwskillpay-api.cn). Obtain data-transfer consent before probe and separate payment consent after showing the actual 402 bill (¥0.10, must match the registered price). Run the official alipay-bot invocation for payment (Payment-Proof) and deliver only the verified server result for the same order with valid Payment-Validation. Stop on nonpayment, cancellation, network/staging failure, price mismatch or an unpaid 200 response. Orders are persisted in a private state dir for idempotency; recovery commands: resume-pay / restage / record-poll. No local substitution, prompt-generated results, cached delivery or free fallback.

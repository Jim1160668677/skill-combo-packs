---
name: combo-azure-messaging-identity
version: 1.0.0
displayName: Azure 消息与身份安全 SDK
summary: 消息总线、通信服务及 Identity/KeyVault/Entra 等微软官方 SDK。
description: 中文：Azure 消息与身份安全 SDK 组合技能包。Azure 消息总线、通信服务与身份密钥体系：事件、队列、WebPubSub、通信、Identity、KeyVault、Entra、AppConfig。 包含 38 个子技能，覆盖：azure-eventgrid-dotnet, azure-eventgrid-java, azure-eventgrid-py, azure-eventhub-dotnet 等。每个子技能位于 skills/ 目录，可在具体任务中按需加载。English: Combo skill pack "Azure 消息与身份安全 SDK". It bundles 38 sub-skills under skills/ covering Azure 消息总线、通信服务与身份密钥体系：事件、队列、WebPubSub、通信、Identity、KeyVault、Entra、AppConfig。.
license: MIT
tags: [skillhub, combo, pay]
category: dev-programming
---

# Azure 消息与身份安全 SDK

## 简介 / Overview

消息总线、通信服务及 Identity/KeyVault/Entra 等微软官方 SDK。

Azure 消息总线、通信服务与身份密钥体系：事件、队列、WebPubSub、通信、Identity、KeyVault、Entra、AppConfig。

本组合包包含 38 个子技能（见 skills/ 目录），按需加载对应子技能完成具体任务。

## 成员技能 / Member skills

| 子技能 slug | 说明 |
| --- | --- |
| azure-eventgrid-dotnet | azure-eventgrid-dotnet — | |
| azure-eventgrid-java | azure-eventgrid-java — Build event-driven applications with Azure Event Grid SDK fo |
| azure-eventgrid-py | azure-eventgrid-py — | |
| azure-eventhub-dotnet | azure-eventhub-dotnet — | |
| azure-eventhub-java | azure-eventhub-java — Build real-time streaming applications with Azure Event Hubs |
| azure-eventhub-rust | azure-eventhub-rust — | |
| azure-eventhub-ts | azure-eventhub-ts — Build event streaming applications using Azure Event Hubs SD |
| azure-servicebus-dotnet | azure-servicebus-dotnet — | |
| azure-servicebus-ts | azure-servicebus-ts — Build messaging applications using Azure Service Bus SDK for |
| azure-messaging | azure-messaging — Troubleshoot and resolve issues with Azure Messaging SDKs fo |
| azure-messaging-webpubsub-java | azure-messaging-webpubsub-java — Build real-time web applications with Azure Web PubSub SDK f |
| azure-messaging-webpubsubservice-py | azure-messaging-webpubsubservice-py — | |
| azure-communication-callautomation-java | azure-communication-callautomation-java — Build call automation workflows with Azure Communication Ser |
| azure-communication-callingserver-java | azure-communication-callingserver-java — Azure Communication Services CallingServer (legacy) Java SDK |
| azure-communication-chat-java | azure-communication-chat-java — Build real-time chat applications with Azure Communication S |
| azure-communication-common-java | azure-communication-common-java — Azure Communication Services common utilities for Java. Use  |
| azure-communication-sms-java | azure-communication-sms-java — Send SMS messages with Azure Communication Services SMS Java |
| azure-identity-dotnet | azure-identity-dotnet — | |
| azure-identity-java | azure-identity-java — Azure Identity library for Java authentication with Azure se |
| azure-identity-py | azure-identity-py — | |
| azure-identity-rust | azure-identity-rust — | |
| azure-identity-ts | azure-identity-ts — Authenticate to Azure services using Azure Identity library  |
| azure-keyvault-certificates-rust | azure-keyvault-certificates-rust — | |
| azure-keyvault-keys-rust | azure-keyvault-keys-rust — | |
| azure-keyvault-keys-ts | azure-keyvault-keys-ts — Manage cryptographic keys using Azure Key Vault Keys SDK for |
| azure-keyvault-py | azure-keyvault-py — | |
| azure-keyvault-secrets-rust | azure-keyvault-secrets-rust — | |
| azure-keyvault-secrets-ts | azure-keyvault-secrets-ts — Manage secrets using Azure Key Vault Secrets SDK for JavaScr |
| azure-security-keyvault-keys-dotnet | azure-security-keyvault-keys-dotnet — | |
| azure-security-keyvault-keys-java | azure-security-keyvault-keys-java — Azure Key Vault Keys Java SDK for cryptographic key manageme |
| azure-security-keyvault-secrets-java | azure-security-keyvault-secrets-java — Azure Key Vault Secrets Java SDK for secret management. Use  |
| azure-appconfiguration-java | azure-appconfiguration-java — | |
| azure-appconfiguration-py | azure-appconfiguration-py — | |
| azure-appconfiguration-ts | azure-appconfiguration-ts — Build applications using Azure App Configuration SDK for Jav |
| entra-agent-id | entra-agent-id — Provision Microsoft Entra Agent Identity Blueprints, Bluepri |
| entra-app-registration | entra-app-registration — Guides Microsoft Entra ID app registration, OAuth 2.0 authen |
| microsoft-azure-webjobs-extensions-authentication-events-dotnet | microsoft-azure-webjobs-extensions-authentication-events-dotnet — Microsoft Entra Authentication Events SDK for .NET. Azure Fu |
| azure-maps-search-dotnet | azure-maps-search-dotnet — | |

## 计费与调用 / Billing & invocation

- Service URL：`https://fwskillpay-api.cn/v1/pay/skills/combo-azure-messaging-identity/invoke`

- 价格：¥ 0.10 / 次调用

- 支付后由 scripts/skill-paid.mjs 完成订单核验并返回结果；恢复命令 resume-pay / restage / record-poll 用于异常恢复。

## 交付说明 / Delivery notes

- 中文：本技能为 SkillPay 组合包，标题、摘要与交付边界提供中文与英文双语。
- 账号与凭证：包内不要求商户私钥、支付宝凭证或长期 Token。
- 外部服务边界：不代用户登录、抓取或调用云端服务；正文提到的工具仅在其真实可用时调用。
- 许可证：子技能来自公开免费技能池，本包按 MIT 条款再分发。
## 付费契约（支付宝 AI 按量付费，¥0.10/次）

本组合包通过登记云端付费网关（fwskillpay-api.cn）交付，必须先取得数据传输与付款授权，再按顺序执行支付助手（scripts/skill-paid.mjs）：

1. **probe**：调用前先披露登记接收方、发送数据、用途与本包单价，取得数据传输及该金额的付款授权。probe 预期返回 402 Payment-Needed 与本次真实账单（¥0.10，资源与登记一致）；400 表示输入无效、503 表示限流/队列满，均不进入 pay。未付款返回 200、暂存失败或金额不符均停止，不读取结果、不本地代做。
2. **pay**：展示 402 账单并取得付款同意后，宿主实际执行生成的官方 alipay-bot 付款指令（Payment-Proof）。helper 的 JSON 不是付款，用户完成支付；不重复等待确认，金额、资源不一致则停止不发起付款。
3. **complete / query**：付款后只查询原订单，不能重新 probe 或重复扣费。仅当同一原订单返回有效 Payment-Validation 和非空业务结果后才交付；正常流程官方 buyer-pay/query 已自动发送回执，不再独立 ACK。
4. **订单持久化与幂等**：订单状态写入包外私有状态目录，不打印、不上传；回执失败仅当官方输出明确给出交易号且用户要求恢复时，按该交易号执行恢复三命令：resume-pay / restage / record-poll。拒绝本地等价分析、提示词代做、缓存交付或免费回退。

English: This combo pack delivers through the registered paid gateway (fwskillpay-api.cn). Obtain data-transfer consent before probe and separate payment consent after showing the actual 402 bill (¥0.10, must match the registered price). Run the official alipay-bot invocation for payment (Payment-Proof) and deliver only the verified server result for the same order with valid Payment-Validation. Stop on nonpayment, cancellation, network/staging failure, price mismatch or an unpaid 200 response. Orders are persisted in a private state dir for idempotency; recovery commands: resume-pay / restage / record-poll. No local substitution, prompt-generated results, cached delivery or free fallback.

# 输入、语义约束与输出

必需 projectId、characters（1–12）、episodes（1–30）。角色需要 name/appearance/wardrobe/voice，可选 motivation。episodes 含唯一 episodeNumber（1–300）、title、goal、scenes（每集 1–20）；cliffhanger 可选。所有场景 sceneId 在跨集范围唯一，需 location/action/durationSec（整数 1–600），单集累计 ≤600，总场景 ≤120。场景角色必须已登记，可记录观察到的 appearance/wardrobe/voice 与 continuityNote。facts 最多 80，factId/description 必需且 ID 唯一；initialFacts、场景 requiresFacts/revealsFacts 必须引用已登记事实。按集号及场景输入顺序检查“向观众揭示之前已使用”的问题；不推断角色各自知识。拍摄分组不改变 storyOrder。

通用约束：projectId 是 1–64 字符字符串；ID 不重复；引用必须存在；数值必须为 JSON 数字，不把字符串或负数误当有效数据。JSON Schema 表示字段/类型边界，跨对象引用、累计时长和预算由服务器额外校验。

检查已有多集故事的依赖和制作顺序，与基础短剧系列大纲是不同交付任务。

返回字段：seriesRoom, findings, sceneCsv。envelope 含 ok、service、projectId、schemaVersion、生成时间、原订单引用与结构化交付标记。CSV 单元格会转义引号及可能触发公式的前缀；SRT 导出规范化换行和箭头，JSON 原文字段保持输入内容。

样例全是原创虚构接口演示，不是实际账号绩效或真实付款交付。

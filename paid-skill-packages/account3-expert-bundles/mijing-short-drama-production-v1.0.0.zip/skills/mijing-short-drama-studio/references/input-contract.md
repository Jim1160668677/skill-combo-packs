# 短剧输入契约 / Short drama input contract

- series-outline：mode、premise 字符串 10–500、characters 1–12；episodeCount 1–30（默认 6）、episodeDurationSec 15–600（默认 60）。交付角色锚点和规则化分集框架，不是完整对白剧本。
- continuity-audit：characters 1–12、scenes 1–60，场景角色名须已登记；发现 appearance、wardrobe、voice 差异时输出待审项。
- shot-list：scenes 1–40、aspectRatio（9:16/16:9/1:1/4:3/3:4）；总时长 ≤600。返回顺序镜头、起止时间和实际角色锚点。

characters 项为对象，name 字符串 1–48、appearance/wardrobe/voice 字符串 1–160；name 不重复，可选 motivation。scenes 项为对象，sceneId 1–64（不重复）、location 1–160、action 5–500、durationSec 整数 1–600（默认 5）；可选 dialogue、screenText、continuityNote；characters 是带 name 的对象数组，可附 appearance/wardrobe/voice/props。

All three modes preserve supplied facts and produce structured planning or checks. Rendering, voice synthesis and posting are outside this service. Character names and scene IDs must be unique.

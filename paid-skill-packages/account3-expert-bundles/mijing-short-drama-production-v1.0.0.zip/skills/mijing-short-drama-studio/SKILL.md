---
name: mijing-short-drama-studio
slug: mijing-short-drama-studio
displayName: 镜界短剧制作台 / Mijing Short Drama Studio
description: 整理短剧系列框架、角色连续性审查和带起止时间的镜头表；交付结构化文本。 Build structured short drama episode frames, anchor continuity checks and
  timestamped shot lists.
summary: 整理短剧系列框架、角色连续性审查和带起止时间的镜头表；交付结构化文本。 Build structured short drama episode frames, anchor continuity checks and timestamped
  shot lists.
license: MIT
tags:
- creative-production
- storyboard
- short-drama
version: 1.0.0
pricing:
  model: per_call
  amount_fen: 10
  currency: CNY
---

<!-- unified-payment-template: 1.0.4 -->
## 支付依赖与恢复 / Payment runtime and recovery

运行时需要 Node.js 20+ 和宿主的支付宝官方 `alipay-payment-skill`、`alipay-bot`。宿主不同不代表钱包授权可以搬运。正常第一条支付宝业务命令是官方 buyer-pay 或原单查询，不能加通用 check-wallet 前检。

只有真实业务命令无法找到/执行 alipay-bot 时，才加载官方技能的 `references/command-recovery.md`：取得外部安装授权，核对指定版本 `@alipay/agent-payment@1.0.23` 的官方完整性后安装，再重试原命令一次。不能每次调用都安装 latest，不能把卖家部署工具当作买方依赖；已启动但业务失败时原样展示并停止。

English: Use the current host's official Alipay buyer runtime. Only an actual command-not-found failure enters the official pinned-version installation recovery. Do not reinstall on every call, precheck wallets generically, or install merchant tooling in the buyer path.

仅在上述恢复条件成立且已获外部安装授权时执行下列两步。先查询完整性，必须逐字符等于下面的指定值；不一致或查不到则停止，不能继续安装：

```text
npm view '@alipay/agent-payment@1.0.23' dist.integrity --registry 'https://registry.npmjs.org'
```

```text
sha512-7OGSHhPnuKsyENpivpY60NgE77ktKtWTP8UBtmizeB1Et44KHFFIjDcSRIFpitEdKAC7uMBx3Mp1Zg/wbYmYCQ==
```

核对一致后才执行安装，并仅重试原先无法执行的命令一次：

```text
npx -y --registry=https://registry.npmjs.org @alipay/agent-payment@1.0.23 install
```

这里的命令是依赖恢复说明，不是正常付款前置；官方技能版本更新时须重新对照其 command-recovery.md，不沿用过期完整性值。

## 本包现行支付流程 / Registered checkout

本包支付配置为 payment-contract.json：资源 `mijing-short-drama-studio`、单价 ¥0.10 / CNY、支付宝服务 ID `API_FC3B91AF109D47C8`、完整服务地址 `https://fwskillpay-api.cn/v1/pay/skills/mijing-short-drama-studio/invoke`。配置与 SKILL/助手哈希不符即停止。平台展示价须在提交后单独回读，不能从本包检查推定平台价已经一致。

1. 调用前披露输入范围、接收方、用途、留存及 ¥0.10，取得本次数据传输和该金额的付款授权。已有授权不再二次询问；价格一致也不能代替授权。
2. 在包外私有目录准备 payload.json，按本 Skill 的输入契约执行 probe。400、503、429、未知网络状态或未付款的 200 都停止，不能本地代做付费结果。
3. 只核对网关公开 JSON 摘要中的金额、币种、商户订单号、资源 ID、服务 ID 和有效期；任一字段缺失、类型错误、过期或与登记不符都停止，不进入 pay。不解码 Payment-Needed 或 amtPaymentLink，不自行验签；公开摘要不能证明签名、实际付款或到账。
4. 本次唯一非空 amtPaymentLink 优先，并原样交给官方 `--amt-payment-link`，不写付款材料文件；链接缺失才使用原值保存的 Payment-Needed 文件。空、多个或歧义链接停止，两种参数互斥，不能补造或从历史输出补齐。
5. 已有该金额授权时立即准备 pay，宿主在返回的 workingDirectory 实际用 executable 与参数数组运行官方 buyer-pay。参数 JSON 不算弹码。会话按下表取值，保持本次原请求与幂等键。
6. 原样输出当前官方对客文本一次，完整展示全部 MEDIA 图片；不复用旧图、不绘制替代二维码。链接生成、success:true、OPEN_LINK_CREATED 不代表付款或交付。
7. 宿主把刚执行的官方对客文本保存在包外私有文件，用本次 handoffId 执行 record-official。只从“订单号/查询单号/交易号”标签提取标识；拒绝原始 JSON、其他交接或冲突标识。观察分类由宿主依据真实输出选择，不是 helper 验付。
8. 用户表示付好或要求查询时，complete 按已绑定标识查询原单：有效 32 位、11–14 位为 8282 的查询号优先；否则用本次交易号。查询不附加 session-id、账单文件或付款链接。未绑定原单停止，不能猜测。
9. 只交付官方实际返回的非空验付后资源。成功交付、业务失败、资源为空、身份不符或查询失败后停止；仅命令超时/网络失败允许按官方规则重试原命令一次。不能从 success 字样认定收款。

English: Obtain data-transfer and price authorization before probe. Compare the public checkout summary while passing payment material unchanged to the official runtime. A unique amtPaymentLink takes priority over an opaque Payment-Needed file. Actually execute the returned argument array, show all current official media, then bind the current official customer-facing output to its handoff. Query only the bound original order. Deliver only actual nonempty official resources. Offline helper checks and host observations are not proof of payment or settlement.

### 当前会话 / Current session

取首个非空来源，高优先级不能被低优先级覆盖：

| 优先级 | 当前运行时来源 |
|---|---|
| 1 | sessionId / session_id 元数据 |
| 2 | threadId / thread_id / conversationId / conversation_id / agentContextId；Codex 使用 CODEX_THREAD_ID |
| 3 | 前两级都为空才用 AIPAY_SESSION_ID |

不能生成会话 ID，不能用订单号、交易号、用户/钱包 ID、URL、测试名或历史会话代替；陈旧环境变量不能覆盖当前显式会话。官方订单号形状（32 位数字且第 11–14 位为 8282）只用于查询，任何符合该形状的串都不是会话，宿主号码仍按逐级取值。全部为空则停止。The current runtime identity takes precedence over inherited environment values.

### 助手调用 / Helper calls

```text
node scripts/skill-paid.mjs probe --state-dir "<包外私有目录>" --payload-file "<包外私有目录>/payload.json" --confirm-data-transfer
node scripts/skill-paid.mjs pay --state-dir "<同一目录>" --session-id "<当前真实会话>" --intent-summary "原始请求：<本次业务目的摘要>" --confirm-payment
node scripts/skill-paid.mjs record-official --state-dir "<同一目录>" --handoff-id "<刚输出的交接ID>" --official-output-file "<刚执行的官方对客文本文件>" --confirm-current-output --outcome pending
node scripts/skill-paid.mjs complete --state-dir "<同一目录>"
```

链接分支 pay 额外带 `--amt-payment-link "<本次 probe 原样返回的值>"`；不能从扫码图片或用户操作链接取替代值。每次实际官方命令后都记录本次 handoff。官方资源文件只存私有目录；资源已交付时可记录 resource_delivered。ack_failed 还须同次真实输出明确回执失败、非空资源文件和已交付确认。无把握时记录 unknown 并停止。

### 大输入、中断及回执 / Large inputs and recovery

大载荷只走同域 /stage 短引用，失败停止，不把大 JSON 塞回命令行。原文恢复副本存在包外私有目录。只有绑定的本次官方输出明确报告引用过期，用户在后续要求恢复并同意再次传输时，才可 restage --confirm-ref-expired --confirm-data-transfer --confirm-recovery-requested 一次；核对原文 SHA-256，保留原订单和幂等键，之后只恢复原单。

正常官方资源交付会自动处理回执。独立 ACK 只恢复已绑定的同次回执失败，且用户后续要求恢复；不重新请求资源。助手使用单次交接标记和锁拒绝重复/并发 ACK。没有真实证据不填确认标志。

付款启动未知不能删状态、换幂等键或再付一笔。已付款但业务失败保留原单，联系运营者核对恢复或退款；退款没有公开命令时不能自行构造。需要官方反馈时加载 alipay-payment-skill 的 references/feedback.md，先向用户确认脱敏内容后提交，不自动发送。

Windows 的文件 mode 不能保证 ACL；宿主须使用当前用户私有目录并核对访问范围。付款材料、当前官方文本、业务原文、资源文件、Cookie 和钱包凭据都不进入发布包或跨宿主同步。


# 镜界短剧制作台 / Mijing Short Drama Studio

本专家包用于短剧系列框架、角色连续性审查与镜头时间表。包含三个独立模式，单次 ¥0.10。

This expert service provides three rule-based planning/checking modes, billed at CNY 0.10 per call.

## 使用与交付 / Use and delivery

1. 读取 `references/input-contract.md`，用包外 JSON 文件准备真实输入。先明确用户需要的工作模式、题材和画风，展示本次收费与数据范围。
2. 依本包统一支付流程调用已登记的 HTTPS 收费入口。`production-kit` 把多项制作件合为一次服务调用，费用 ¥0.10；若另行调用其他模式，每次分别收费，不能隐瞒累计次数。
3. 最终交付只能采用原订单验付后服务端返回的非空结果。官方助手给出的参数须由宿主实际执行，参数输出不是已付款或已出码的证据。网关失败、凭证失败或未付款时停止，保留原单供恢复。
4. 不通过本地推理、缓存、免费接口、其他端点或另一个服务补做本包收费结果。输出中的规则框架和剪辑建议需要创作者确认；没有提供的事实、台词、身份和素材权利不能自行补造。
5. JSON 制作件、提示词、时间线和 SRT 文本都不代表已生成媒体。只有用户另行提供的媒体文件可以用于后续制作；本服务不负责账号登录、社交平台发布或第三方工具安装。

Use the registered paid endpoint and the original verified order. Never replace failed cloud delivery with local reasoning or another endpoint. One kit invocation costs CNY 0.10; separate module invocations are billed separately. Review all rule-based planning suggestions. Prompts and SRT text are not rendered media.

## 数据与隐私 / Data and privacy

调用前向用户说明：创作梗概、角色锚点、场景、对白及素材描述会发送到 `fwskillpay-api.cn`，用于校验、收费恢复和生成结构化制作件。支付宝接收账单和支付验证所需信息；本执行器不调用外部文本、图像、配音或视频模型。先取得本次数据传输和 ¥0.10 费用授权。

服务端会将不超过 256 Ki 字符的请求 JSON 保存在受限订单账本，执行成功后删除该输入；未付款、执行失败或待恢复的输入当前没有自动清除期限。已履约结果缓存期限为生成后 24 小时，随清理任务清除；尚未履约确认的结果为恢复用途保留。可选大载荷暂存默认 2 小时过期、每 5 分钟清理、24 小时硬上限。订单金额、摘要、状态及必要交易元数据用于幂等、核账和恢复，当前没有自动删除期限。系统没有自助删除接口，需要发布者人工核查处理，具体联系入口以 SkillHub 发布者页面为准；不要公开创作正文、支付凭证或密钥。

The story, character, scene and dialogue data is sent to the named gateway. Small request JSON is persisted until execution succeeds; unpaid/failed recovery inputs have no automatic deletion deadline. Fulfilled result cache expires after 24 hours; unconfirmed delivery results remain for recovery. Optional staging expires in 2 hours with a 5-minute sweep and a 24-hour hard cap. Transaction metadata remains for accounting and idempotency. No external generative model is called by this executor. Obtain consent before transmission and payment.

## 依赖与能力边界 / Dependencies and limits

宿主需 Node.js 20+、可用的官方支付宝买方组件和当前真实会话；业务在已登记网关运行。无业务模型 API 密钥或自媒体账号依赖。输出是 JSON 与可复制字幕文本，不出图、不合成配音、不生成视频、不自动发布；不承诺流量、收益或素材授权。输入过长、重复标识、时长超限或人物不一致会在新增收费前校验失败。保留原 JSON，避免重复新建订单。

The client needs Node.js 20+ and an available official Alipay buyer integration. No business model/API key is requested. This service delivers structured text, not rendered images/audio/video or social posting. It makes no reach, income or rights guarantee.

## 原稿、许可证与验收 / Source, license and validation

包内业务说明与示例为本项目原创，MIT 许可证见 LICENSE.txt；支付助手来自统一支付模板 v1.0.4。业务模式、原始输入不变、字幕时间与支付门禁已在隔离环境验证；生产 HTTPS 402 摘要和实际资源登记已核对。新版本真实买方付款、平台会话效果案例和卖家到账尚未在本批验证，不把模拟结果当成资金证明。来源及复用边界见 SOURCES.md。

Original project documentation/examples are distributed under MIT. The payment helper uses unified template v1.0.4. Isolated business/protocol checks and live unpaid 402 probes passed. Real buyer payment, platform session cases and settlement for this release are separately unverified.

## 触发场景 / When to use

当用户需要把已确认的故事梗概、角色锚点和场景对白整理成可交接的制作件，或核对连续性与镜头时长时使用。 Use for structured production handoff from approved story/scene data, continuity review or shot timing.

## 已核对的输入示例 / Registered input example

```json
{
  "mode": "series-outline",
  "premise": "一名剪辑师发现每次导出的视频都多出一帧陌生画面。",
  "episodeCount": 6,
  "episodeDurationSec": 60,
  "characters": [
    {
      "name": "林夏",
      "appearance": "短发",
      "wardrobe": "蓝色夹克",
      "voice": "克制清晰",
      "motivation": "查明异常帧来源"
    }
  ]
}
```

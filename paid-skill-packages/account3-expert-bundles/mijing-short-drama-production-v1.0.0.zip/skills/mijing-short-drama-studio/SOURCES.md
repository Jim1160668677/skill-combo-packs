# 来源与复用 / Sources and reuse

业务服务为镜界项目原创：可复用组件是输入规范化、题材节奏卡、画风映射、角色锚点、分镜拆分、累计时间线、SRT 导出、连续性审查。专项只固定真实题材/画风与原始示例，不重新打包第三方同名 Skill。服务器核心执行器不依赖外部模型；业务执行代码不在客户端包中分发。

支付宝协议参考：https://aipay.alipay.com/docs/ai-receive/MACHINE_PAY.html
SkillHub 发布参考：https://skillhub.cn/tutorials#alipay-pay
统一支付助手：项目提供的统一支付链改造模板 v1.0.4，保持生成器哈希校验。

Optional media production research: https://github.com/comfyanonymous/ComfyUI and https://ffmpeg.org/documentation.html. Those projects are independent tools, not this paid executor's hidden backend or distributed code. Their own licenses and hardware requirements remain applicable.

The four new specialist artwork files were created with the built-in image generator. The master artwork and short-drama logo are existing original project assets. No third-party logo or branded fictional character is used.

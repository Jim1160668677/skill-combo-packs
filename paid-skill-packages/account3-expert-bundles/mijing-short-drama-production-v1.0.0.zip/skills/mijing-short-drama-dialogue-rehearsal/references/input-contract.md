# 输入契约 / Input contract

提供 projectId 与1–100个 scene；每场含唯一 sceneId、targetDurationMs 和1–100句 lines，整份最多500句。每句包含全局唯一 lineId、speakerId、text，可选 deliveryNote 与 pauseAfterMs。可选 graphemesPerSecond（2–15，默认5）、maxLineMs（1–30秒，默认7秒）、sceneTolerancePct（0–100，默认20%）。时长估算为非空白 Unicode 字素数÷语速，再加停顿。

Provide projectId and 1–100 scenes. Each scene has a unique sceneId, targetDurationMs and 1–100 lines; the full request is capped at 500 lines. Each line needs a globally unique lineId, speakerId and text; deliveryNote and pauseAfterMs are optional. Optional settings are graphemesPerSecond (2–15, default 5), maxLineMs (1–30 s, default 7 s) and sceneTolerancePct (0–100, default 20%). Estimated duration is non-whitespace Unicode graphemes divided by reading rate, plus pauses.

Cross-field dates, unique IDs, scope matching and aggregate limits are validated by the service in addition to JSON Schema.

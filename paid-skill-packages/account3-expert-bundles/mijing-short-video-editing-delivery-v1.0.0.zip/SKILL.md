---
name: mijing-short-video-editing-delivery
description: 开场测试、剪辑时间线、节奏字幕质检与跨平台素材交付。 按需路由到本包的专项技能；付费调用前明确列出服务与费用。
license: MIT
---

# 镜界·短视频剪辑制作与多平台交付包

## 适用任务

开场测试、剪辑时间线、节奏字幕质检与跨平台素材交付。

## 执行方式

1. 先识别用户要完成的具体环节，只加载下方目录中相关的专项 `SKILL.md` 和它引用的资料。
2. 按该专项技能的输入契约收集必需信息；缺少关键输入时先列出缺项，不虚构业务事实或结果。
3. 输出前遵守专项的格式与质量检查要求，并清楚区分已知事实、推断和待确认事项。
4. 仅当用户明确需要且已授权相应服务调用时，才调用对应的付费执行器。专项包的现行支付契约为 ¥0.10/次；一次任务若需多个专项调用，先逐项说明调用对象和费用，获得授权后再执行，不将订阅/买断与按次服务费混为一谈。
5. 不自动发布内容、不替用户付款、不承诺流量或销售结果；需人工确认的平台规则、权利或事实问题应明确标出。

## 专项技能目录

| 专项 | 路径 |
|---|---|
| 钩研·短视频开场对照测试卡 / Short Video Hook Test Planner | `skills/mijing-hook-ab-test-kit/SKILL.md` |
| 守框·多画幅主体构图交接 / Subject Preserving Frame Composition | `skills/mijing-frame-composition-kit/SKILL.md` |
| 切章·长稿拆条与字幕交接 / Transcript Clip Planning with Subtitles | `skills/mijing-transcript-clip-planner/SKILL.md` |
| mijing-short-video-edit-kit | `skills/mijing-short-video-edit-kit/SKILL.md` |
| 节拍·短视频镜头节奏审查 / Short Video Pace and Cut Review | `skills/mijing-short-video-pacing-audit/SKILL.md` |
| 幕检·字幕可读性与修订交接 / Subtitle Readability Review and Reflow | `skills/mijing-subtitle-quality-kit/SKILL.md` |
| mijing-cross-platform-release-kit | `skills/mijing-cross-platform-release-kit/SKILL.md` |

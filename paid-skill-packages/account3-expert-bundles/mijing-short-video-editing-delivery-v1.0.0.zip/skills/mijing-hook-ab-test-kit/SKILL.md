---
name: mijing-hook-ab-test-kit
description: 比较2–12版短视频开场，计算字素数、估算朗读时长、文案相似度与等量测试分配。 自媒体团队已有多个开场文案候选，希望固定行动号召和观察指标，制作可执行的对照测试卡时使用。 Compare 2–12 short-video
  hooks with grapheme counts, estimated read time, copy similarity and balanced test allocations.
license: MIT
metadata:
  display_name: 钩研·短视频开场对照测试卡 / Short Video Hook Test Planner
displayName: 钩研·短视频开场对照测试卡 / Short Video Hook Test Planner
summary: '中文：比较2–12版短视频开场，计算字素数、估算朗读时长、文案相似度与等量测试分配。 / English: Compare 2–12 short-video hooks with grapheme counts, estimated
  read time, copy similarity and balanced test allocations.'
slug: mijing-hook-ab-test-kit
version: 1.0.0
pricing:
  model: per_call
  amount_fen: 10
  currency: CNY
---

<!-- unified-payment-template: 1.0.4 -->
## 支付依赖与恢复 / Payment runtime and recovery

运行时需要 Node.js 20+ 和宿主的支付宝官方 `alipay-payment-skill`、`alipay-bot`。宿主不同不代表钱包授权可以搬运。正常第一条支付宝业务命令是官方 buyer-pay 或原单查询，不能加通用 check-wallet 前检。

只有真实业务命令无法找到/执行 alipay-bot 时，才加载官方技能的 `references/command-recovery.md`：取得外部安装授权，核对指定版本 `@alipay/agent-payment@1.0.23` 的官方完整性后安装，再重试原命令一次。不能每次调用都安装 latest，不能把卖家部署工具当作买方依赖；已启动但业务失败时原样展示并停止。

English: Use the current host's official Alipay buyer runtime. Only an actual command-not-found failure enters the official pinned-version installation recovery. Do not reinstall on every call, precheck wallets generically, or install merchant tooling in the buyer path.

仅在上述恢复条件成立且已获外部安装授权时执行下列两步。先查询完整性，必须逐字符等于下面的指定值；不一致或查不到则停止，不能继续安装：

```text
npm view '@alipay/agent-payment@1.0.23' dist.integrity --registry 'https://registry.npmjs.org'
```

```text
sha512-7OGSHhPnuKsyENpivpY60NgE77ktKtWTP8UBtmizeB1Et44KHFFIjDcSRIFpitEdKAC7uMBx3Mp1Zg/wbYmYCQ==
```

核对一致后才执行安装，并仅重试原先无法执行的命令一次：

```text
npx -y --registry=https://registry.npmjs.org @alipay/agent-payment@1.0.23 install
```

这里的命令是依赖恢复说明，不是正常付款前置；官方技能版本更新时须重新对照其 command-recovery.md，不沿用过期完整性值。

## 本包现行支付流程 / Registered checkout

本包支付配置为 payment-contract.json：资源 `mijing-hook-ab-test-kit`、单价 ¥0.10 / CNY、支付宝服务 ID `API_FC3B91AF109D47C8`、完整服务地址 `https://fwskillpay-api.cn/v1/pay/skills/mijing-hook-ab-test-kit/invoke`。配置与 SKILL/助手哈希不符即停止。平台展示价须在提交后单独回读，不能从本包检查推定平台价已经一致。

1. 调用前披露输入范围、接收方、用途、留存及 ¥0.10，取得本次数据传输和该金额的付款授权。已有授权不再二次询问；价格一致也不能代替授权。
2. 在包外私有目录准备 payload.json，按本 Skill 的输入契约执行 probe。400、503、429、未知网络状态或未付款的 200 都停止，不能本地代做付费结果。
3. 只核对网关公开 JSON 摘要中的金额、币种、商户订单号、资源 ID、服务 ID 和有效期；任一字段缺失、类型错误、过期或与登记不符都停止，不进入 pay。不解码 Payment-Needed 或 amtPaymentLink，不自行验签；公开摘要不能证明签名、实际付款或到账。
4. 本次唯一非空 amtPaymentLink 优先，并原样交给官方 `--amt-payment-link`，不写付款材料文件；链接缺失才使用原值保存的 Payment-Needed 文件。空、多个或歧义链接停止，两种参数互斥，不能补造或从历史输出补齐。
5. 已有该金额授权时立即准备 pay，宿主在返回的 workingDirectory 实际用 executable 与参数数组运行官方 buyer-pay。参数 JSON 不算弹码。会话按下表取值，保持本次原请求与幂等键。
6. 原样输出当前官方对客文本一次，完整展示全部 MEDIA 图片；不复用旧图、不绘制替代二维码。链接生成、success:true、OPEN_LINK_CREATED 不代表付款或交付。
7. 宿主把刚执行的官方对客文本保存在包外私有文件，用本次 handoffId 执行 record-official。只从“订单号/查询单号/交易号”标签提取标识；拒绝原始 JSON、其他交接或冲突标识。观察分类由宿主依据真实输出选择，不是 helper 验付。
8. 用户表示付好或要求查询时，complete 按已绑定标识查询原单：有效 32 位、11–14 位为 8282 的查询号优先；否则用本次交易号。查询不附加 session-id、账单文件或付款链接。未绑定原单停止，不能猜测。
9. 只交付官方实际返回的非空验付后资源。成功交付、业务失败、资源为空、身份不符或查询失败后停止；仅命令超时/网络失败允许按官方规则重试原命令一次。不能从 success 字样认定收款。

English: Obtain data-transfer and price authorization before probe. Compare the public checkout summary while passing payment material unchanged to the official runtime. A unique amtPaymentLink takes priority over an opaque Payment-Needed file. Actually execute the returned argument array, show all current official media, then bind the current official customer-facing output to its handoff. Query only the bound original order. Deliver only actual nonempty official resources. Offline helper checks and host observations are not proof of payment or settlement.

### 当前会话 / Current session

取首个非空来源，高优先级不能被低优先级覆盖：

| 优先级 | 当前运行时来源 |
|---|---|
| 1 | sessionId / session_id 元数据 |
| 2 | threadId / thread_id / conversationId / conversation_id / agentContextId；Codex 使用 CODEX_THREAD_ID |
| 3 | 前两级都为空才用 AIPAY_SESSION_ID |

不能生成会话 ID，不能用订单号、交易号、用户/钱包 ID、URL、测试名或历史会话代替；陈旧环境变量不能覆盖当前显式会话。官方订单号形状（32 位数字且第 11–14 位为 8282）只用于查询，任何符合该形状的串都不是会话，宿主号码仍按逐级取值。全部为空则停止。The current runtime identity takes precedence over inherited environment values.

### 助手调用 / Helper calls

```text
node scripts/skill-paid.mjs probe --state-dir "<包外私有目录>" --payload-file "<包外私有目录>/payload.json" --confirm-data-transfer
node scripts/skill-paid.mjs pay --state-dir "<同一目录>" --session-id "<当前真实会话>" --intent-summary "原始请求：<本次业务目的摘要>" --confirm-payment
node scripts/skill-paid.mjs record-official --state-dir "<同一目录>" --handoff-id "<刚输出的交接ID>" --official-output-file "<刚执行的官方对客文本文件>" --confirm-current-output --outcome pending
node scripts/skill-paid.mjs complete --state-dir "<同一目录>"
```

链接分支 pay 额外带 `--amt-payment-link "<本次 probe 原样返回的值>"`；不能从扫码图片或用户操作链接取替代值。每次实际官方命令后都记录本次 handoff。官方资源文件只存私有目录；资源已交付时可记录 resource_delivered。ack_failed 还须同次真实输出明确回执失败、非空资源文件和已交付确认。无把握时记录 unknown 并停止。

### 大输入、中断及回执 / Large inputs and recovery

大载荷只走同域 /stage 短引用，失败停止，不把大 JSON 塞回命令行。原文恢复副本存在包外私有目录。只有绑定的本次官方输出明确报告引用过期，用户在后续要求恢复并同意再次传输时，才可 restage --confirm-ref-expired --confirm-data-transfer --confirm-recovery-requested 一次；核对原文 SHA-256，保留原订单和幂等键，之后只恢复原单。

正常官方资源交付会自动处理回执。独立 ACK 只恢复已绑定的同次回执失败，且用户后续要求恢复；不重新请求资源。助手使用单次交接标记和锁拒绝重复/并发 ACK。没有真实证据不填确认标志。

付款启动未知不能删状态、换幂等键或再付一笔。已付款但业务失败保留原单，联系运营者核对恢复或退款；退款没有公开命令时不能自行构造。需要官方反馈时加载 alipay-payment-skill 的 references/feedback.md，先向用户确认脱敏内容后提交，不自动发送。

Windows 的文件 mode 不能保证 ACL；宿主须使用当前用户私有目录并核对访问范围。付款材料、当前官方文本、业务原文、资源文件、Cookie 和钱包凭据都不进入发布包或跨宿主同步。


# 钩研·短视频开场对照测试卡 / Short Video Hook Test Planner

## 交付结果 / Deliverable

比较2–12版短视频开场，计算字素数、估算朗读时长、文案相似度与等量测试分配。

Compare 2–12 short-video hooks with grapheme counts, estimated read time, copy similarity and balanced test allocations.

## 适用场景 / When to use

自媒体团队已有多个开场文案候选，希望固定行动号召和观察指标，制作可执行的对照测试卡时使用。

Use when a creator has several opening-copy candidates and needs a test card with a shared call to action and observation metric.

把已有开场文案整理成对照计划，不代写内容；与事后数据复盘分开，不冒充真实投放或胜出结论。

Structures supplied hooks into a comparison plan without writing copy; it is separate from post-campaign analytics and never claims real delivery or a winning result.

## 输入与计算 / Input and processing

提供2–12个variantId唯一的hookText和label，指定controlVariantId、primaryMetric、所有版本共用的sharedCta、总曝光目标exposureGoal（20–10000000）、观察时长6–720小时、创作者填写的maxHookGraphemes（1–300）及可选朗读速度（2–15字素/秒，默认5）。主指标可选3秒播放率、完播率、点击率、关注率或自定义。按Unicode字素估长；相似度使用NFKC小写去标点后的字符三元组Jaccard。

Provide 2–12 unique variantIds with hookText and label; choose controlVariantId and primaryMetric; supply a sharedCta, exposureGoal 20–10,000,000, measurementWindowHours 6–720, creator-supplied maxHookGraphemes 1–300 and optional readingRate 2–15 graphemes/sec (default 5). Metrics: three-second view, completion, click-through, follow or custom. Text length uses Unicode grapheme clusters; similarity is character-trigram Jaccard after NFKC, lowercasing and punctuation removal.

Read [input contract](references/input-contract.md), [JSON Schema](references/input-schema.json), and the [fictional input](references/input-example.json) before preparing creator data. Preserve the creator's IDs and annotations; do not replace missing facts with the demo. A fictional output shape is in [output-example.json](references/output-example.json).

## 输出与验收 / Output and acceptance

返回：`experiment`, `arms`, `similarities`, `findings`, `checklist`, `armsCsv`。合法输入经服务器完成后，结果包含可追溯的输入ID、数量、阈值、发现项和CSV；校验失败返回400且不创建账单。

Returns the fields listed above. A successful server result retains traceable input IDs, counts, thresholds, findings and CSV; invalid input is rejected with 400 before a bill is created.

## 边界 / Limits

曝光目标在各版本等分，余数按输入顺序分配；统一CTA和主指标写入每张卡。相似度≥0.85作为近似文案复核提醒。平台字数限制由用户提供，不读取平台最新规则。此工具不发布内容、不随机分配观众、不读取后台数据，也不计算统计显著性或判定赢家。

The exposure target is divided evenly, with remainder assigned in input order; each card records the shared CTA and primary metric. Similarity ≥ 0.85 is a near-duplicate review flag. The creator supplies character limits; current platform rules are not fetched. This tool does not publish, randomize viewers, ingest analytics, calculate significance or declare a winner.

## 计费与失败 / Billing and failure

每次¥0.10。内部多个输出作为一次服务交付，不串调其他付费产品。拒绝传输、未支付、网关失败、验付失败或状态未知时停止；不在本地代做结果、不换兼容入口、不重建未知订单。按统一支付说明将原请求交给宿主官方买方组件；准备命令参数不表示二维码显示或付款。

CNY 0.10 per server call covers the stated outputs; this package does not call other paid products. If transfer/payment is declined, gateway or verification fails, or order state is unknown, stop without local substitute results, alternate routes or replacement orders. Pass the original request to the host's official buyer component per the payment flow; prepared arguments do not prove QR display or payment.

## 数据与隐私 / Data and privacy

业务 JSON（镜头时间点和拍点、角色画面位置/视线、开场文案候选和测试设置）发送到 fwskillpay-api.cn 用于预检、计算、计费和恢复；在传输前应取得明确同意及本次金额的付款授权。服务不下载原视频、图像或音频，不访问创作者账号，不调用外部生成模型；支付宝接收交易所需信息。

成功执行后服务会删除持久化输入；未付款、失败或待恢复输入没有自动清理期限。已履约结果缓存24小时，未完成履约确认的结果保留用于恢复。可选大载荷暂存默认2小时、每5分钟清理、24小时硬上限。订单和必要交易元数据没有自动删除期限，目前没有自助删除接口，需发布者人工处理。请勿提交真实姓名、联系方式、登录凭据或未公开的敏感剧本。下载的CSV/报告由使用者保存和删除。

The business JSON (shot/beat timestamps, annotated character positions/gaze, hook candidates and test settings) is sent to fwskillpay-api.cn for validation, computation, billing and recovery. Obtain explicit consent for this transfer and authorization for the disclosed charge. The service does not fetch source video/images/audio, access creator accounts or call external generative models; Alipay receives transaction data.

Persisted input is removed after successful execution; unpaid, failed or recovery input has no automatic deletion deadline. Fulfilled results are cached for 24 hours; unconfirmed delivery is retained for recovery. Optional large-payload staging defaults to 2 hours, is swept every 5 minutes and has a 24-hour hard cap. Orders and necessary transaction metadata have no automatic deletion deadline; no self-service deletion API is available and publisher intervention is needed. Avoid real names, contact details, credentials and unpublished sensitive scripts. Users retain/delete downloaded CSV and reports.

## 依赖与版本 / Dependencies and version

版本1.0.0。客户端Node.js20+及宿主官方支付宝买方组件/真实会话；云端业务由已登记自有网关运行，无第三方业务模型密钥依赖。业务在Linux/Node22验证，包构建在Windows/Node24完成；未在macOS实机验收。输出文本与结构化数据，不提供视频/图像/音频渲染、平台发布或自动AB投放。真实买方付款、SkillHub原生二维码和卖家结算未在本批验证。

Version 1.0.0. Client requires Node.js20+ and the host's official Alipay buyer runtime/session. Hosted business runs on the registered gateway and uses no third-party model API key. Business verified on Linux/Node22 and packaging on Windows/Node24; macOS not physically tested. Returns text/structured data, without media rendering, platform posting or automatic experiment delivery. Buyer payment, SkillHub-native QR and seller settlement are not verified in this batch. See [SOURCES.md](SOURCES.md) and [MIT license](LICENSE.txt).

## 已核对的输入示例 / Registered input example

```json
{
  "projectId": "demo-hooks-01",
  "controlVariantId": "a",
  "primaryMetric": "three-second-view-rate",
  "sharedCta": "关注账号，查看下一集。",
  "exposureGoal": 1200,
  "measurementWindowHours": 48,
  "maxHookGraphemes": 36,
  "readingRateGraphemesPerSecond": 5,
  "variants": [
    {
      "variantId": "a",
      "label": "具体收益·对照",
      "hookText": "三分钟看懂一条短视频为什么留不住人"
    },
    {
      "variantId": "b",
      "label": "问题悬念",
      "hookText": "为什么观众总在开头几秒离开？"
    },
    {
      "variantId": "c",
      "label": "反常识",
      "hookText": "视频剪得越快，播放量就越高吗？"
    }
  ]
}
```

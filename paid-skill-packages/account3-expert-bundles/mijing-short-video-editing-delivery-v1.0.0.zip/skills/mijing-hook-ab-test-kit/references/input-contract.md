# 输入契约 / Input contract

提供2–12个variantId唯一的hookText和label，指定controlVariantId、primaryMetric、所有版本共用的sharedCta、总曝光目标exposureGoal（20–10000000）、观察时长6–720小时、创作者填写的maxHookGraphemes（1–300）及可选朗读速度（2–15字素/秒，默认5）。主指标可选3秒播放率、完播率、点击率、关注率或自定义。按Unicode字素估长；相似度使用NFKC小写去标点后的字符三元组Jaccard。

Provide 2–12 unique variantIds with hookText and label; choose controlVariantId and primaryMetric; supply a sharedCta, exposureGoal 20–10,000,000, measurementWindowHours 6–720, creator-supplied maxHookGraphemes 1–300 and optional readingRate 2–15 graphemes/sec (default 5). Metrics: three-second view, completion, click-through, follow or custom. Text length uses Unicode grapheme clusters; similarity is character-trigram Jaccard after NFKC, lowercasing and punctuation removal.

Cross-field ranges and semantic checks are enforced by the service in addition to JSON Schema.

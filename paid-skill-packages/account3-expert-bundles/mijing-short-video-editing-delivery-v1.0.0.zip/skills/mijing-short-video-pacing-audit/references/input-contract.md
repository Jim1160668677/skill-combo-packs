# 输入契约 / Input contract

提供projectId、成片总时长durationMs及1–500个镜头：唯一shotId、sceneId、startMs、endMs，可选scale和incomingTransition。beatMs为严格递增的人工拍点毫秒列表，最多2000条；不提供即跳过拍点比较。thresholds可选windowMs（5–60秒，默认15秒）、maxHoldMs（0.5–30秒，默认3秒）、fastCutMs（0.1–3秒，默认0.4秒）和beatToleranceMs（0–1000毫秒，默认120）。所有镜头须在片长内且结束晚于开始。

Provide a projectId, total durationMs and 1–500 shots with unique shotId, sceneId, startMs and endMs; scale and incomingTransition are optional. beatMs is an optional strictly increasing list of up to 2,000 creator-annotated beat timestamps; without it, beat comparison is skipped. Optional thresholds: windowMs 5–60 s (default 15 s), maxHoldMs 0.5–30 s (default 3 s), fastCutMs 0.1–3 s (default 0.4 s), beatToleranceMs 0–1,000 ms (default 120 ms). Every shot must fit the runtime and end after it starts.

Cross-field ranges and semantic checks are enforced by the service in addition to JSON Schema.

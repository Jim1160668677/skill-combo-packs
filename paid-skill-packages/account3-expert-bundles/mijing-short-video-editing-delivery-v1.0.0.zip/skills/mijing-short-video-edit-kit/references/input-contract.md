# 输入、语义约束与输出

必需 projectId、segments、assets。segments 1–80 项，segmentId 唯一，每项 visual、assetId、durationSec（0.25–600 秒）必需；可选 text（≤1500）、audioAssetId、onScreenText。总时长 ≤600 秒。画面引用必须存在且为 image/video，声音引用必须是 audio。assets 最多 100 项，assetId、kind（image/video/audio）、uri 必需，ID 唯一；rights 缺省 unknown，durationSec 可选。asset URI 仅作元数据交接，不被服务器下载。aspectRatio 支持 9:16/16:9/1:1/4:3/3:4，默认 9:16。targetDurationSec 可选；目标不符、素材短于镜头、音频超槽、字幕读速高或权利线索缺失均输出待审项，不静默裁切。

通用约束：projectId 是 1–64 字符字符串；ID 不重复；引用必须存在；数值必须为 JSON 数字，不把字符串或负数误当有效数据。JSON Schema 表示字段/类型边界，跨对象引用、累计时长和预算由服务器额外校验。

按已有内容做素材绑定和时间计算，保留原稿；不承担未确认口播稿的写作或成片渲染。

返回字段：editPlan, subtitleSrt, editCsv, findings, status。envelope 含 ok、service、projectId、schemaVersion、生成时间、原订单引用与结构化交付标记。CSV 单元格会转义引号及可能触发公式的前缀；SRT 导出规范化换行和箭头，JSON 原文字段保持输入内容。

样例全是原创虚构接口演示，不是实际账号绩效或真实付款交付。

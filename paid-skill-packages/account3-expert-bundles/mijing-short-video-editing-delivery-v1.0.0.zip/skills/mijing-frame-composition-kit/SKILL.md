---
name: mijing-frame-composition-kit
description: '中文：组合图像尺寸、主体保护框和焦点，为横竖及方形画幅计算裁切坐标、可见性审查、SVG构图图和CSV。 自媒体、短剧或漫剧素材需适配多个画幅，必须核对角色或关键物体是否会被裁掉时使用。 / English: Combine
  source dimensions, protected regions and focal points into exact-ratio crop coordinates, visibility checks, SVG geometry
  overlays and CSV.'
license: MIT
metadata:
  display_name: 守框·多画幅主体构图交接 / Subject Preserving Frame Composition
displayName: 守框·多画幅主体构图交接 / Subject Preserving Frame Composition
summary: '中文：组合图像尺寸、主体保护框和焦点，为横竖及方形画幅计算裁切坐标、可见性审查、SVG构图图和CSV。 / English: Combine source dimensions, protected regions and
  focal points into exact-ratio crop coordinates, visibility checks, SVG geometry overlays and CSV.'
slug: mijing-frame-composition-kit
version: 1.0.0
pricing:
  model: per_call
  amount_fen: 10
  currency: CNY
---

<!-- unified-payment-template: 1.0.4 -->
## 支付依赖与恢复 / Payment runtime and recovery

运行时需要 Node.js 20+ 和宿主的支付宝官方 `alipay-payment-skill`、`alipay-bot`。宿主不同不代表钱包授权可以搬运。正常第一条支付宝业务命令是官方 buyer-pay 或原单查询，不能加通用 check-wallet 前检。

只有真实业务命令无法找到/执行 alipay-bot 时，才加载官方技能的 `references/command-recovery.md`：取得外部安装授权，核对指定版本 `@alipay/agent-payment@1.0.23` 的官方完整性后安装，再重试原命令一次。不能每次调用都安装 latest，不能把卖家部署工具当作买方依赖；已启动但业务失败时原样展示并停止。

English: Use the current host's official Alipay buyer runtime. Only an actual command-not-found failure enters the official pinned-version installation recovery. Do not reinstall on every call, precheck wallets generically, or install merchant tooling in the buyer path.

仅在上述恢复条件成立且已获外部安装授权时执行下列两步。先查询完整性，必须逐字符等于下面的指定值；不一致或查不到则停止，不能继续安装：

```text
npm view '@alipay/agent-payment@1.0.23' dist.integrity --registry 'https://registry.npmjs.org'
```

```text
sha512-7OGSHhPnuKsyENpivpY60NgE77ktKtWTP8UBtmizeB1Et44KHFFIjDcSRIFpitEdKAC7uMBx3Mp1Zg/wbYmYCQ==
```

核对一致后才执行安装，并仅重试原先无法执行的命令一次：

```text
npx -y --registry=https://registry.npmjs.org @alipay/agent-payment@1.0.23 install
```

这里的命令是依赖恢复说明，不是正常付款前置；官方技能版本更新时须重新对照其 command-recovery.md，不沿用过期完整性值。

## 本包现行支付流程 / Registered checkout

本包支付配置为 payment-contract.json：资源 `mijing-frame-composition-kit`、单价 ¥0.10 / CNY、支付宝服务 ID `API_FC3B91AF109D47C8`、完整服务地址 `https://fwskillpay-api.cn/v1/pay/skills/mijing-frame-composition-kit/invoke`。配置与 SKILL/助手哈希不符即停止。平台展示价须在提交后单独回读，不能从本包检查推定平台价已经一致。

1. 调用前披露输入范围、接收方、用途、留存及 ¥0.10，取得本次数据传输和该金额的付款授权。已有授权不再二次询问；价格一致也不能代替授权。
2. 在包外私有目录准备 payload.json，按本 Skill 的输入契约执行 probe。400、503、429、未知网络状态或未付款的 200 都停止，不能本地代做付费结果。
3. 只核对网关公开 JSON 摘要中的金额、币种、商户订单号、资源 ID、服务 ID 和有效期；任一字段缺失、类型错误、过期或与登记不符都停止，不进入 pay。不解码 Payment-Needed 或 amtPaymentLink，不自行验签；公开摘要不能证明签名、实际付款或到账。
4. 本次唯一非空 amtPaymentLink 优先，并原样交给官方 `--amt-payment-link`，不写付款材料文件；链接缺失才使用原值保存的 Payment-Needed 文件。空、多个或歧义链接停止，两种参数互斥，不能补造或从历史输出补齐。
5. 已有该金额授权时立即准备 pay，宿主在返回的 workingDirectory 实际用 executable 与参数数组运行官方 buyer-pay。参数 JSON 不算弹码。会话按下表取值，保持本次原请求与幂等键。
6. 原样输出当前官方对客文本一次，完整展示全部 MEDIA 图片；不复用旧图、不绘制替代二维码。链接生成、success:true、OPEN_LINK_CREATED 不代表付款或交付。
7. 宿主把刚执行的官方对客文本保存在包外私有文件，用本次 handoffId 执行 record-official。只从“订单号/查询单号/交易号”标签提取标识；拒绝原始 JSON、其他交接或冲突标识。观察分类由宿主依据真实输出选择，不是 helper 验付。
8. 用户表示付好或要求查询时，complete 按已绑定标识查询原单：有效 32 位、11–14 位为 8282 的查询号优先；否则用本次交易号。查询不附加 session-id、账单文件或付款链接。未绑定原单停止，不能猜测。
9. 只交付官方实际返回的非空验付后资源。成功交付、业务失败、资源为空、身份不符或查询失败后停止；仅命令超时/网络失败允许按官方规则重试原命令一次。不能从 success 字样认定收款。

English: Obtain data-transfer and price authorization before probe. Compare the public checkout summary while passing payment material unchanged to the official runtime. A unique amtPaymentLink takes priority over an opaque Payment-Needed file. Actually execute the returned argument array, show all current official media, then bind the current official customer-facing output to its handoff. Query only the bound original order. Deliver only actual nonempty official resources. Offline helper checks and host observations are not proof of payment or settlement.

### 当前会话 / Current session

取首个非空来源，高优先级不能被低优先级覆盖：

| 优先级 | 当前运行时来源 |
|---|---|
| 1 | sessionId / session_id 元数据 |
| 2 | threadId / thread_id / conversationId / conversation_id / agentContextId；Codex 使用 CODEX_THREAD_ID |
| 3 | 前两级都为空才用 AIPAY_SESSION_ID |

不能生成会话 ID，不能用订单号、交易号、用户/钱包 ID、URL、测试名或历史会话代替；陈旧环境变量不能覆盖当前显式会话。官方订单号形状（32 位数字且第 11–14 位为 8282）只用于查询，任何符合该形状的串都不是会话，宿主号码仍按逐级取值。全部为空则停止。The current runtime identity takes precedence over inherited environment values.

### 助手调用 / Helper calls

```text
node scripts/skill-paid.mjs probe --state-dir "<包外私有目录>" --payload-file "<包外私有目录>/payload.json" --confirm-data-transfer
node scripts/skill-paid.mjs pay --state-dir "<同一目录>" --session-id "<当前真实会话>" --intent-summary "原始请求：<本次业务目的摘要>" --confirm-payment
node scripts/skill-paid.mjs record-official --state-dir "<同一目录>" --handoff-id "<刚输出的交接ID>" --official-output-file "<刚执行的官方对客文本文件>" --confirm-current-output --outcome pending
node scripts/skill-paid.mjs complete --state-dir "<同一目录>"
```

链接分支 pay 额外带 `--amt-payment-link "<本次 probe 原样返回的值>"`；不能从扫码图片或用户操作链接取替代值。每次实际官方命令后都记录本次 handoff。官方资源文件只存私有目录；资源已交付时可记录 resource_delivered。ack_failed 还须同次真实输出明确回执失败、非空资源文件和已交付确认。无把握时记录 unknown 并停止。

### 大输入、中断及回执 / Large inputs and recovery

大载荷只走同域 /stage 短引用，失败停止，不把大 JSON 塞回命令行。原文恢复副本存在包外私有目录。只有绑定的本次官方输出明确报告引用过期，用户在后续要求恢复并同意再次传输时，才可 restage --confirm-ref-expired --confirm-data-transfer --confirm-recovery-requested 一次；核对原文 SHA-256，保留原订单和幂等键，之后只恢复原单。

正常官方资源交付会自动处理回执。独立 ACK 只恢复已绑定的同次回执失败，且用户后续要求恢复；不重新请求资源。助手使用单次交接标记和锁拒绝重复/并发 ACK。没有真实证据不填确认标志。

付款启动未知不能删状态、换幂等键或再付一笔。已付款但业务失败保留原单，联系运营者核对恢复或退款；退款没有公开命令时不能自行构造。需要官方反馈时加载 alipay-payment-skill 的 references/feedback.md，先向用户确认脱敏内容后提交，不自动发送。

Windows 的文件 mode 不能保证 ACL；宿主须使用当前用户私有目录并核对访问范围。付款材料、当前官方文本、业务原文、资源文件、Cookie 和钱包凭据都不进入发布包或跨宿主同步。


# 守框·多画幅主体构图交接 / Subject Preserving Frame Composition

## 本次交付 / Delivery

组合图像尺寸、主体保护框和焦点，为横竖及方形画幅计算裁切坐标、可见性审查、SVG构图图和CSV。

Combine source dimensions, protected regions and focal points into exact-ratio crop coordinates, visibility checks, SVG geometry overlays and CSV.

## 触发场景 / When to use

自媒体、短剧或漫剧素材需适配多个画幅，必须核对角色或关键物体是否会被裁掉时使用。

几何求解并检查标注的主体区域；不只是建议平台比例，不编辑或上传原图，不调用图像模型。

## 输入与处理 / Input and processing

projectId 必需；source.width/height 是1–16384整数，label可选≤160。focus 可选默认中心，x/y为0–1。protectedRegions 最多30项，唯一regionId≤64，x/y是0–1的源图归一化坐标，width/height>0且框不得超出源图。targets 1–8项，唯一targetId≤64、aspectRatio 必需支持9:16/16:9/1:1/4:3/3:4；outputWidth64–4096整数默认1080，计算后高度≤8192；safeInsetRatio0–0.4默认0.05。取最大面积的精确比例裁切框；保护框可同时保留时选距焦点最近的可行位置，不能全部保留时按焦点定位并逐区域标出可见比例，不隐藏问题。不填补边缘、不进行图像编辑；SVG只是几何图。裁切保留全精度，输出整数高度最多舍入0.5像素。safeInset由用户定义，不表示平台最新界面安全区。

Provide integer source dimensions (1–16384), optional normalized focal point, up to 30 normalized protected rectangles, and 1–8 target IDs/ratios. Target width is 64–4096 (default 1080), height must not exceed 8192, and user-defined safe inset is 0–0.4. The maximum-area exact-ratio crop preserves all annotated regions when feasible, choosing the feasible position nearest the focal point. Impossible preservation is reported per region. Outputs are geometry, transforms and SVG overlays only; no source image loading/editing/padding. Integer target height rounds by at most half a pixel. Insets do not assert current platform UI rules.

读取 [输入契约](references/input-contract.md)、[JSON Schema](references/input-schema.json) 以及 [虚构输入样例](references/input-example.json)。保留projectId与来源ID；补齐真正缺失的字段，不把演示数字或占位素材当真实业务事实。输出形状见 [虚构结果示例](references/output-example.json)。

Read the contract/schema and fictional example before preparing creator-supplied data. Preserve project/source IDs; do not substitute fictional examples for real inputs.

## 输出与验收 / Outputs and acceptance

交付字段：`variants`, `compositionCsv`, `findings`。仅交付原订单验付后服务器返回的非空结果，保留findings和未选/未绑定项。CSV/SRT/SVG/HTML字符串按需另存为UTF-8文件，HTML无外部依赖且没有自动付款；交付文件另存不代表可免费重新计算本产品。

Return only the nonempty server result for the original verified order, including unresolved findings. Save returned CSV/SRT/SVG/HTML strings as UTF-8 files when requested. Opening an already delivered HTML preview needs no new charge; recomputing a new server request is a separate call.

## 计费与失败 / Billing and failure

每次¥0.10，本产品内部交付组合只收一次；不同SKU串联按实际调用次数分别收费，本包不自动调用其他收费服务。非法输入返回400且不创建订单；没有可行拆条应先调整约束。拒绝传输、未支付、网关失败或凭证未知时停止，不能本地代做、换兼容入口或重建未知订单。按统一支付说明由宿主实际执行官方买方命令，准备参数不表示出码或付款。

CNY0.10 per server call covers the stated composite outputs. Separate products are separately billed. Invalid input is rejected with400 before any bill. If transfer/payment is declined or verification fails, stop without local substitute results. Preserve the original order when its state is unknown. Host execution of the official buyer command is required; generated arguments alone prove neither a QR nor payment.

## 数据与隐私 / Data and privacy

业务 JSON（原稿时间、原文、用户优先级、图像尺寸/标注、漫画格和可选内嵌缩略图）发送到 fwskillpay-api.cn 用于预检、计算、计费和恢复。取得本次传输的明确同意与该金额付款授权；已有对应授权不重复询问。本业务不下载素材、不访问创作者账号、不调用外部文本/图像/视频模型；支付宝接收交易所需信息。

请求 JSON 不超过256 Ki字符时进入受限订单账本，成功执行后删除输入；未付款、失败或待恢复输入没有自动清理期限。已履约结果缓存24小时，未完成履约确认结果保留用于恢复。可选暂存默认2小时、每5分钟清理、24小时硬上限。订单和必要交易元数据无自动删除期限；无自助删除接口，需发布者人工处理。HTML预演含所提供缩略图，下载文件由使用者保存和删除；匿名演示数据与私密素材分别处理，不传登录凭据。

The gateway receives transcript text/timestamps, creator priorities, geometry annotations, panels and optional embedded thumbnails for validation, computation, billing and recovery. Obtain explicit consent for this transfer and authorization for the disclosed price. The business does not fetch media, access creator accounts or call external models. Successful execution removes persisted input; unpaid/failed recovery input and transaction metadata have no automatic deletion deadline. Fulfilled result cache expires after 24 hours; unconfirmed delivery remains for recovery. Optional staging expires after 2 hours, swept every 5 minutes with a 24-hour hard cap. No self-service deletion API exists. Downloaded HTML contains supplied thumbnails and is retained/deleted by its user.

## 依赖与版本 / Dependencies and version

版本1.0.0。客户端Node.js20+及宿主官方支付宝买方组件/真实会话；业务使用已登记自有网关，无业务模型密钥依赖。预演需支持Canvas与requestAnimationFrame的浏览器，本批在当前内置浏览器验证；未在所有操作系统实机验收。独立HTML提供图像运动预演，无配音、口型、成片渲染或自动发布。

Version1.0.0. Client requires Node.js20+ and the host official Alipay buyer runtime/session. Hosted business requires no external-model API keys. HTML preview requires Canvas/requestAnimationFrame; tested in the current in-app browser, not every OS. It does not synthesize artwork/audio or export rendered video. Actual buyer payment, market-path QR and seller settlement remain unverified in this batch. See [SOURCES.md](SOURCES.md) and [MIT license](LICENSE.txt).

## 执行登记与结果边界 / Execution registration and result boundary

| 字段 / Field | 当前值 / Registered value |
|---|---|
| **单次价格 / Unit price** | ¥0.10 |
| Resource | `mijing-frame-composition-kit` |
| Service ID | `API_FC3B91AF109D47C8` |
| Service URL | `https://fwskillpay-api.cn/v1/pay/skills/mijing-frame-composition-kit/invoke` |

服务端对有效未付请求返回HTTP 402与Payment-Needed，先验Payment-Proof，再以Payment-Validation标识同单结果；Idempotency-Key绑定同一意图。公开六字段摘要校验与真实验付分开。仅交付原订单验付后的远端结果，拒绝或失败不本地代做。

For valid unpaid requests the server returns HTTP 402 and Payment-Needed. It verifies Payment-Proof before execution and returns Payment-Validation with the original order result. Idempotency-Key binds the same intent. Public-summary checking does not replace actual verification. Use only registered verified-order delivery; never substitute local results.

## 已核对的输入示例 / Registered input example

```json
{
  "projectId": "demo-frame-01",
  "source": {
    "label": "虚构原图尺寸，不提供图像",
    "width": 1920,
    "height": 1080
  },
  "focus": {
    "x": 0.55,
    "y": 0.45
  },
  "protectedRegions": [
    {
      "regionId": "main-character",
      "x": 0.42,
      "y": 0.15,
      "width": 0.16,
      "height": 0.65
    }
  ],
  "targets": [
    {
      "targetId": "portrait",
      "aspectRatio": "9:16",
      "outputWidth": 1080,
      "safeInsetRatio": 0.06
    },
    {
      "targetId": "landscape",
      "aspectRatio": "16:9",
      "outputWidth": 1920,
      "safeInsetRatio": 0.05
    },
    {
      "targetId": "square",
      "aspectRatio": "1:1",
      "outputWidth": 1080,
      "safeInsetRatio": 0.05
    }
  ]
}
```

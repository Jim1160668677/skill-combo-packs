# 输入契约 / Input contract

projectId 必需；source.width/height 是1–16384整数，label可选≤160。focus 可选默认中心，x/y为0–1。protectedRegions 最多30项，唯一regionId≤64，x/y是0–1的源图归一化坐标，width/height>0且框不得超出源图。targets 1–8项，唯一targetId≤64、aspectRatio 必需支持9:16/16:9/1:1/4:3/3:4；outputWidth64–4096整数默认1080，计算后高度≤8192；safeInsetRatio0–0.4默认0.05。取最大面积的精确比例裁切框；保护框可同时保留时选距焦点最近的可行位置，不能全部保留时按焦点定位并逐区域标出可见比例，不隐藏问题。不填补边缘、不进行图像编辑；SVG只是几何图。裁切保留全精度，输出整数高度最多舍入0.5像素。safeInset由用户定义，不表示平台最新界面安全区。

Provide integer source dimensions (1–16384), optional normalized focal point, up to 30 normalized protected rectangles, and 1–8 target IDs/ratios. Target width is 64–4096 (default 1080), height must not exceed 8192, and user-defined safe inset is 0–0.4. The maximum-area exact-ratio crop preserves all annotated regions when feasible, choosing the feasible position nearest the focal point. Impossible preservation is reported per region. Outputs are geometry, transforms and SVG overlays only; no source image loading/editing/padding. Integer target height rounds by at most half a pixel. Insets do not assert current platform UI rules.

Cross-object references, total limits, ordering and interval feasibility are enforced by the server in addition to JSON Schema.

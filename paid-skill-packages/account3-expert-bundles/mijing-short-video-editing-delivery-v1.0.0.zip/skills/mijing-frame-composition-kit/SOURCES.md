# 来源 / Sources

业务、文档、例子均为镜界原创MIT组件。复用项目的ID/数值约束、CSV/SRT序列化和前序animatic.clips交接合同；没有复制另两个账号的泛用video-edit或image-to-video提示流程。作者技能与平台发布元数据分开构建；正式云端付费包不分发本地完整业务执行器。

Original MIT business/components and fictional examples. The client payment helper comes from the canonical unified payment-chain template1.0.4. No third-party Skill source or proprietary artwork is redistributed. Icons are original built-in imagegen assets.

Browser timing reference: https://developer.mozilla.org/en-US/docs/Web/API/Window/requestAnimationFrame
CSP reference: https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Content-Security-Policy/script-src
Payment reference: https://aipay.alipay.com/docs/ai-receive/MACHINE_PAY.html

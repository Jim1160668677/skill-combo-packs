# 输入、语义约束与输出

projectId/title/approvalNote/paragraphs/profiles 必需。paragraphs 1–40 项，paragraphId 唯一，text 1–2000，可附布尔 mustKeep。profiles 1–8 项，profileId 唯一、platformLabel、maxCharacters（20–20000）必需；variantTitle 可选，hashtags 最多 10；includeParagraphIds 可选且必须引用实际段落。字符数按 Unicode 字符计，包含标题、空行及标签；预算是用户自定值，不冒充平台最新规则。整段保持原文和顺序。必需内容超限时完整展示并标出，留待创作者修改。approvalNote 是输入提供的批准记录，服务器不会据此声称已完成事实核查。

通用约束：projectId 是 1–64 字符字符串；ID 不重复；引用必须存在；数值必须为 JSON 数字，不把字符串或负数误当有效数据。JSON Schema 表示字段/类型边界，跨对象引用、累计时长和预算由服务器额外校验。

按整段选择而非自动重写；mustKeep 段落不能为了字符预算被删掉，也不会代发平台。

返回字段：sourceApproval, sourceParagraphs, drafts, releaseCsv。envelope 含 ok、service、projectId、schemaVersion、生成时间、原订单引用与结构化交付标记。CSV 单元格会转义引号及可能触发公式的前缀；SRT 导出规范化换行和箭头，JSON 原文字段保持输入内容。

样例全是原创虚构接口演示，不是实际账号绩效或真实付款交付。

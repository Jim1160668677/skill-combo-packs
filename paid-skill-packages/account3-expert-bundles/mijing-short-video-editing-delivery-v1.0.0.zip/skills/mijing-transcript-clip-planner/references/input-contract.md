# 输入契约 / Input contract

必需 projectId（1–64）、sourceLabel（1–160）、sourceDurationSec（5–14400）、units（1–240）。每单元需唯一 unitId（1–64）、startSec/endSec（源时长内，正时长≥0.001秒）、text（1–2000），可附 label（≤120）、priority（整数0–10，默认1）。单元按输入顺序递增、不重叠，不自动重排。minClipSec 默认15、maxClipSec默认60，范围5–180且前者≤后者；maxClips 1–12默认5；maxGapSec 0–30默认2。候选片段必须保持整单元、连续区间、合乎时长和相邻间隙；没有合法候选时返回400且不创建订单。动态规划优先最大化输入优先级之和，同分依次选覆盖单元时长更多、条数更少、开始更早的方案。结果保留源区间与所有未选ID，不转写、不改稿、不剪视频；每条SRT转换为片内相对时间。

Provide a project/source label, source duration (5–14400 seconds), and 1–240 ordered non-overlapping transcript units with unique IDs, source timestamps and supplied text. Priority is an integer 0–10 (default 1). Clip duration limits are 5–180 seconds, maxClips 1–12, and maxGapSec 0–30. Whole units remain atomic. Requests without a feasible candidate are rejected before billing. Weighted interval dynamic programming maximizes supplied priorities, then coverage, fewer clips and earlier starts. Outputs preserve source offsets, unused IDs and per-clip relative SRT; no recognition, rewriting or media cutting.

Cross-object references, total limits, ordering and interval feasibility are enforced by the server in addition to JSON Schema.

# 输入契约 / Input contract

提供 projectId、projectDurationMs 与1–250格 panels。每格含唯一 panelId、sceneId、绝对 startMs/endMs，可附最多50条 voiceLines 和50条 soundCues；相对时间 offsetMs 与 durationMs 必须落在本格时长内。音效 kind 为 sfx、ambience 或 music。整份最多1500条 cue。

Provide projectId, projectDurationMs and 1–250 panels. Each panel has unique panelId, sceneId and absolute startMs/endMs; it may include up to 50 voiceLines and 50 soundCues. Relative offsetMs and durationMs must fit inside the panel. Sound kinds are sfx, ambience or music; the request is capped at 1,500 cues.

The service also validates unique identifiers, cross-field timing constraints, and aggregate limits.

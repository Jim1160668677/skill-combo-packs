---
name: mijing-comic-audio-cue-board
description: 按已确认的漫剧时间线整理配音、音效、环境声和音乐 cue，标记越界与配音重叠复核项。 适用场景：漫剧画面或 animatic 时间线已确认，需要向配音、音效和混音团队交接结构化提示单时使用。 / Arrange creator-timed
  voice, effects, ambience and music cues on a comic timeline; flag boundary and voice-overlap checks. Use after comic panels
  or an animatic timeline is set, when preparing a structured handoff for voice and sound editing.
license: MIT
metadata:
  display_name: 声格·漫剧配音与音效提示单 / Comic Voice and Sound Cue Board
displayName: 声格·漫剧配音与音效提示单 / Comic Voice and Sound Cue Board
summary: '中文：按已确认的漫剧时间线整理配音、音效、环境声和音乐 cue，标记越界与配音重叠复核项。 / English: Arrange creator-timed voice, effects, ambience and music
  cues on a comic timeline; flag boundary and voice-overlap checks.'
slug: mijing-comic-audio-cue-board
version: 1.0.0
pricing:
  model: per_call
  amount_fen: 10
  currency: CNY
---

<!-- unified-payment-template: 1.0.4 -->
## 支付依赖与恢复 / Payment runtime and recovery

运行时需要 Node.js 20+ 和宿主的支付宝官方 `alipay-payment-skill`、`alipay-bot`。宿主不同不代表钱包授权可以搬运。正常第一条支付宝业务命令是官方 buyer-pay 或原单查询，不能加通用 check-wallet 前检。

只有真实业务命令无法找到/执行 alipay-bot 时，才加载官方技能的 `references/command-recovery.md`：取得外部安装授权，核对指定版本 `@alipay/agent-payment@1.0.23` 的官方完整性后安装，再重试原命令一次。不能每次调用都安装 latest，不能把卖家部署工具当作买方依赖；已启动但业务失败时原样展示并停止。

English: Use the current host's official Alipay buyer runtime. Only an actual command-not-found failure enters the official pinned-version installation recovery. Do not reinstall on every call, precheck wallets generically, or install merchant tooling in the buyer path.

仅在上述恢复条件成立且已获外部安装授权时执行下列两步。先查询完整性，必须逐字符等于下面的指定值；不一致或查不到则停止，不能继续安装：

```text
npm view '@alipay/agent-payment@1.0.23' dist.integrity --registry 'https://registry.npmjs.org'
```

```text
sha512-7OGSHhPnuKsyENpivpY60NgE77ktKtWTP8UBtmizeB1Et44KHFFIjDcSRIFpitEdKAC7uMBx3Mp1Zg/wbYmYCQ==
```

核对一致后才执行安装，并仅重试原先无法执行的命令一次：

```text
npx -y --registry=https://registry.npmjs.org @alipay/agent-payment@1.0.23 install
```

这里的命令是依赖恢复说明，不是正常付款前置；官方技能版本更新时须重新对照其 command-recovery.md，不沿用过期完整性值。

## 本包现行支付流程 / Registered checkout

本包支付配置为 payment-contract.json：资源 `mijing-comic-audio-cue-board`、单价 ¥0.10 / CNY、支付宝服务 ID `API_FC3B91AF109D47C8`、完整服务地址 `https://fwskillpay-api.cn/v1/pay/skills/mijing-comic-audio-cue-board/invoke`。配置与 SKILL/助手哈希不符即停止。平台展示价须在提交后单独回读，不能从本包检查推定平台价已经一致。

1. 调用前披露输入范围、接收方、用途、留存及 ¥0.10，取得本次数据传输和该金额的付款授权。已有授权不再二次询问；价格一致也不能代替授权。
2. 在包外私有目录准备 payload.json，按本 Skill 的输入契约执行 probe。400、503、429、未知网络状态或未付款的 200 都停止，不能本地代做付费结果。
3. 只核对网关公开 JSON 摘要中的金额、币种、商户订单号、资源 ID、服务 ID 和有效期；任一字段缺失、类型错误、过期或与登记不符都停止，不进入 pay。不解码 Payment-Needed 或 amtPaymentLink，不自行验签；公开摘要不能证明签名、实际付款或到账。
4. 本次唯一非空 amtPaymentLink 优先，并原样交给官方 `--amt-payment-link`，不写付款材料文件；链接缺失才使用原值保存的 Payment-Needed 文件。空、多个或歧义链接停止，两种参数互斥，不能补造或从历史输出补齐。
5. 已有该金额授权时立即准备 pay，宿主在返回的 workingDirectory 实际用 executable 与参数数组运行官方 buyer-pay。参数 JSON 不算弹码。会话按下表取值，保持本次原请求与幂等键。
6. 原样输出当前官方对客文本一次，完整展示全部 MEDIA 图片；不复用旧图、不绘制替代二维码。链接生成、success:true、OPEN_LINK_CREATED 不代表付款或交付。
7. 宿主把刚执行的官方对客文本保存在包外私有文件，用本次 handoffId 执行 record-official。只从“订单号/查询单号/交易号”标签提取标识；拒绝原始 JSON、其他交接或冲突标识。观察分类由宿主依据真实输出选择，不是 helper 验付。
8. 用户表示付好或要求查询时，complete 按已绑定标识查询原单：有效 32 位、11–14 位为 8282 的查询号优先；否则用本次交易号。查询不附加 session-id、账单文件或付款链接。未绑定原单停止，不能猜测。
9. 只交付官方实际返回的非空验付后资源。成功交付、业务失败、资源为空、身份不符或查询失败后停止；仅命令超时/网络失败允许按官方规则重试原命令一次。不能从 success 字样认定收款。

English: Obtain data-transfer and price authorization before probe. Compare the public checkout summary while passing payment material unchanged to the official runtime. A unique amtPaymentLink takes priority over an opaque Payment-Needed file. Actually execute the returned argument array, show all current official media, then bind the current official customer-facing output to its handoff. Query only the bound original order. Deliver only actual nonempty official resources. Offline helper checks and host observations are not proof of payment or settlement.

### 当前会话 / Current session

取首个非空来源，高优先级不能被低优先级覆盖：

| 优先级 | 当前运行时来源 |
|---|---|
| 1 | sessionId / session_id 元数据 |
| 2 | threadId / thread_id / conversationId / conversation_id / agentContextId；Codex 使用 CODEX_THREAD_ID |
| 3 | 前两级都为空才用 AIPAY_SESSION_ID |

不能生成会话 ID，不能用订单号、交易号、用户/钱包 ID、URL、测试名或历史会话代替；陈旧环境变量不能覆盖当前显式会话。官方订单号形状（32 位数字且第 11–14 位为 8282）只用于查询，任何符合该形状的串都不是会话，宿主号码仍按逐级取值。全部为空则停止。The current runtime identity takes precedence over inherited environment values.

### 助手调用 / Helper calls

```text
node scripts/skill-paid.mjs probe --state-dir "<包外私有目录>" --payload-file "<包外私有目录>/payload.json" --confirm-data-transfer
node scripts/skill-paid.mjs pay --state-dir "<同一目录>" --session-id "<当前真实会话>" --intent-summary "原始请求：<本次业务目的摘要>" --confirm-payment
node scripts/skill-paid.mjs record-official --state-dir "<同一目录>" --handoff-id "<刚输出的交接ID>" --official-output-file "<刚执行的官方对客文本文件>" --confirm-current-output --outcome pending
node scripts/skill-paid.mjs complete --state-dir "<同一目录>"
```

链接分支 pay 额外带 `--amt-payment-link "<本次 probe 原样返回的值>"`；不能从扫码图片或用户操作链接取替代值。每次实际官方命令后都记录本次 handoff。官方资源文件只存私有目录；资源已交付时可记录 resource_delivered。ack_failed 还须同次真实输出明确回执失败、非空资源文件和已交付确认。无把握时记录 unknown 并停止。

### 大输入、中断及回执 / Large inputs and recovery

大载荷只走同域 /stage 短引用，失败停止，不把大 JSON 塞回命令行。原文恢复副本存在包外私有目录。只有绑定的本次官方输出明确报告引用过期，用户在后续要求恢复并同意再次传输时，才可 restage --confirm-ref-expired --confirm-data-transfer --confirm-recovery-requested 一次；核对原文 SHA-256，保留原订单和幂等键，之后只恢复原单。

正常官方资源交付会自动处理回执。独立 ACK 只恢复已绑定的同次回执失败，且用户后续要求恢复；不重新请求资源。助手使用单次交接标记和锁拒绝重复/并发 ACK。没有真实证据不填确认标志。

付款启动未知不能删状态、换幂等键或再付一笔。已付款但业务失败保留原单，联系运营者核对恢复或退款；退款没有公开命令时不能自行构造。需要官方反馈时加载 alipay-payment-skill 的 references/feedback.md，先向用户确认脱敏内容后提交，不自动发送。

Windows 的文件 mode 不能保证 ACL；宿主须使用当前用户私有目录并核对访问范围。付款材料、当前官方文本、业务原文、资源文件、Cookie 和钱包凭据都不进入发布包或跨宿主同步。


# 声格·漫剧配音与音效提示单 / Comic Voice and Sound Cue Board

## 交付范围 / Deliverable

按已确认的漫剧时间线整理配音、音效、环境声和音乐 cue，标记越界与配音重叠复核项。

Arrange creator-timed voice, effects, ambience and music cues on a comic timeline; flag boundary and voice-overlap checks.

## 适用场景 / When to use

漫剧画面或 animatic 时间线已确认，需要向配音、音效和混音团队交接结构化提示单时使用。

Use after comic panels or an animatic timeline is set, when preparing a structured handoff for voice and sound editing.

## 输入与处理 / Input and processing

提供 projectId、projectDurationMs 与1–250格 panels。每格含唯一 panelId、sceneId、绝对 startMs/endMs，可附最多50条 voiceLines 和50条 soundCues；相对时间 offsetMs 与 durationMs 必须落在本格时长内。音效 kind 为 sfx、ambience 或 music。整份最多1500条 cue。

Provide projectId, projectDurationMs and 1–250 panels. Each panel has unique panelId, sceneId and absolute startMs/endMs; it may include up to 50 voiceLines and 50 soundCues. Relative offsetMs and durationMs must fit inside the panel. Sound kinds are sfx, ambience or music; the request is capped at 1,500 cues.

Read [input contract](references/input-contract.md), [JSON Schema](references/input-schema.json), and the [fictional input](references/input-example.json) before preparing a request. A sample result is in [output-example.json](references/output-example.json). Preserve user IDs and supplied facts.

## 输出 / Outputs

返回：`summary`, `cueRows`, `findings`, `cueCsv`。合法输入交付结构化检查表和 CSV；校验失败返回400且不生成计费交付。

## 边界 / Limits

只整理用户提供的标签和时间，不读取、生成、合成或混音音频。配音时间重叠仅作人工复核提示，可能是有意设计。

Uses supplied cue labels and timings only; it does not read, generate, synthesize or mix audio. Voice overlaps are review prompts and may be intentional.

## 数据与隐私 / Data and privacy

业务只接收本技能契约所需的结构化文本，不调用第三方生成模型，也不发布内容。执行后输入载荷按网关规则处理；订单及必要交易元数据依据网关保留策略保存。请勿提交未获授权的敏感内容。评论队列请使用本地非身份引用 ID。

## 依赖与版本 / Dependencies and version

版本1.0.0。业务运行于登记网关，调用统一支付模板 v1.0.4，客户端使用官方 SkillHub Pay Skill 付款组件；不需要第三方模型 API key。服务返回结构化文本，不执行图像或音频渲染、平台发布或真实内容投放。真实买家付款和卖家结算不在本批验证范围。详见 [SOURCES.md](SOURCES.md) 与 [MIT License](LICENSE.txt)。

## 已核对的输入示例 / Registered input example

```json
{
  "projectId": "demo-comic-audio-01",
  "projectDurationMs": 12000,
  "panels": [
    {
      "panelId": "p01",
      "sceneId": "station",
      "startMs": 0,
      "endMs": 6000,
      "voiceLines": [
        {
          "lineId": "v01",
          "speakerId": "mei",
          "offsetMs": 800,
          "durationMs": 1800,
          "deliveryNote": "低声、克制"
        }
      ],
      "soundCues": [
        {
          "cueId": "s01",
          "kind": "ambience",
          "label": "雨夜车站底噪",
          "offsetMs": 0,
          "durationMs": 6000,
          "assetRef": "sound:rain-01"
        }
      ]
    },
    {
      "panelId": "p02",
      "sceneId": "station",
      "startMs": 6000,
      "endMs": 12000,
      "voiceLines": [
        {
          "lineId": "v02",
          "speakerId": "zhou",
          "offsetMs": 300,
          "durationMs": 1300
        }
      ],
      "soundCues": []
    }
  ]
}
```

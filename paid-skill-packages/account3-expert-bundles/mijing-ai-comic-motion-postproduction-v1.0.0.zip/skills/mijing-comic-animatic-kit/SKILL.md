---
name: mijing-comic-animatic-kit
description: 直接接收镜界漫剧制作套件或漫画格，组合媒体绑定、排剪时间线、SRT 字幕和缺项审查。 漫画分镜已经确认，需要绑定画面/声音并交接动态漫排剪时使用。 Accept Mijing comic production kit
  panels and combine media bindings, animatic timing, SRT and missing-media checks.
license: MIT
metadata:
  display_name: 帧叙·动态漫排剪专家 / Comic Animatic Edit Studio
slug: mijing-comic-animatic-kit
version: 1.0.0
pricing:
  model: per_call
  amount_fen: 10
  currency: CNY
---

<!-- unified-payment-template: 1.0.4 -->
## 支付依赖与恢复 / Payment runtime and recovery

运行时需要 Node.js 20+ 和宿主的支付宝官方 `alipay-payment-skill`、`alipay-bot`。宿主不同不代表钱包授权可以搬运。正常第一条支付宝业务命令是官方 buyer-pay 或原单查询，不能加通用 check-wallet 前检。

只有真实业务命令无法找到/执行 alipay-bot 时，才加载官方技能的 `references/command-recovery.md`：取得外部安装授权，核对指定版本 `@alipay/agent-payment@1.0.23` 的官方完整性后安装，再重试原命令一次。不能每次调用都安装 latest，不能把卖家部署工具当作买方依赖；已启动但业务失败时原样展示并停止。

English: Use the current host's official Alipay buyer runtime. Only an actual command-not-found failure enters the official pinned-version installation recovery. Do not reinstall on every call, precheck wallets generically, or install merchant tooling in the buyer path.

仅在上述恢复条件成立且已获外部安装授权时执行下列两步。先查询完整性，必须逐字符等于下面的指定值；不一致或查不到则停止，不能继续安装：

```text
npm view '@alipay/agent-payment@1.0.23' dist.integrity --registry 'https://registry.npmjs.org'
```

```text
sha512-7OGSHhPnuKsyENpivpY60NgE77ktKtWTP8UBtmizeB1Et44KHFFIjDcSRIFpitEdKAC7uMBx3Mp1Zg/wbYmYCQ==
```

核对一致后才执行安装，并仅重试原先无法执行的命令一次：

```text
npx -y --registry=https://registry.npmjs.org @alipay/agent-payment@1.0.23 install
```

这里的命令是依赖恢复说明，不是正常付款前置；官方技能版本更新时须重新对照其 command-recovery.md，不沿用过期完整性值。

## 本包现行支付流程 / Registered checkout

本包支付配置为 payment-contract.json：资源 `mijing-comic-animatic-kit`、单价 ¥0.10 / CNY、支付宝服务 ID `API_FC3B91AF109D47C8`、完整服务地址 `https://fwskillpay-api.cn/v1/pay/skills/mijing-comic-animatic-kit/invoke`。配置与 SKILL/助手哈希不符即停止。平台展示价须在提交后单独回读，不能从本包检查推定平台价已经一致。

1. 调用前披露输入范围、接收方、用途、留存及 ¥0.10，取得本次数据传输和该金额的付款授权。已有授权不再二次询问；价格一致也不能代替授权。
2. 在包外私有目录准备 payload.json，按本 Skill 的输入契约执行 probe。400、503、429、未知网络状态或未付款的 200 都停止，不能本地代做付费结果。
3. 只核对网关公开 JSON 摘要中的金额、币种、商户订单号、资源 ID、服务 ID 和有效期；任一字段缺失、类型错误、过期或与登记不符都停止，不进入 pay。不解码 Payment-Needed 或 amtPaymentLink，不自行验签；公开摘要不能证明签名、实际付款或到账。
4. 本次唯一非空 amtPaymentLink 优先，并原样交给官方 `--amt-payment-link`，不写付款材料文件；链接缺失才使用原值保存的 Payment-Needed 文件。空、多个或歧义链接停止，两种参数互斥，不能补造或从历史输出补齐。
5. 已有该金额授权时立即准备 pay，宿主在返回的 workingDirectory 实际用 executable 与参数数组运行官方 buyer-pay。参数 JSON 不算弹码。会话按下表取值，保持本次原请求与幂等键。
6. 原样输出当前官方对客文本一次，完整展示全部 MEDIA 图片；不复用旧图、不绘制替代二维码。链接生成、success:true、OPEN_LINK_CREATED 不代表付款或交付。
7. 宿主把刚执行的官方对客文本保存在包外私有文件，用本次 handoffId 执行 record-official。只从“订单号/查询单号/交易号”标签提取标识；拒绝原始 JSON、其他交接或冲突标识。观察分类由宿主依据真实输出选择，不是 helper 验付。
8. 用户表示付好或要求查询时，complete 按已绑定标识查询原单：有效 32 位、11–14 位为 8282 的查询号优先；否则用本次交易号。查询不附加 session-id、账单文件或付款链接。未绑定原单停止，不能猜测。
9. 只交付官方实际返回的非空验付后资源。成功交付、业务失败、资源为空、身份不符或查询失败后停止；仅命令超时/网络失败允许按官方规则重试原命令一次。不能从 success 字样认定收款。

English: Obtain data-transfer and price authorization before probe. Compare the public checkout summary while passing payment material unchanged to the official runtime. A unique amtPaymentLink takes priority over an opaque Payment-Needed file. Actually execute the returned argument array, show all current official media, then bind the current official customer-facing output to its handoff. Query only the bound original order. Deliver only actual nonempty official resources. Offline helper checks and host observations are not proof of payment or settlement.

### 当前会话 / Current session

取首个非空来源，高优先级不能被低优先级覆盖：

| 优先级 | 当前运行时来源 |
|---|---|
| 1 | sessionId / session_id 元数据 |
| 2 | threadId / thread_id / conversationId / conversation_id / agentContextId；Codex 使用 CODEX_THREAD_ID |
| 3 | 前两级都为空才用 AIPAY_SESSION_ID |

不能生成会话 ID，不能用订单号、交易号、用户/钱包 ID、URL、测试名或历史会话代替；陈旧环境变量不能覆盖当前显式会话。官方订单号形状（32 位数字且第 11–14 位为 8282）只用于查询，任何符合该形状的串都不是会话，宿主号码仍按逐级取值。全部为空则停止。The current runtime identity takes precedence over inherited environment values.

### 助手调用 / Helper calls

```text
node scripts/skill-paid.mjs probe --state-dir "<包外私有目录>" --payload-file "<包外私有目录>/payload.json" --confirm-data-transfer
node scripts/skill-paid.mjs pay --state-dir "<同一目录>" --session-id "<当前真实会话>" --intent-summary "原始请求：<本次业务目的摘要>" --confirm-payment
node scripts/skill-paid.mjs record-official --state-dir "<同一目录>" --handoff-id "<刚输出的交接ID>" --official-output-file "<刚执行的官方对客文本文件>" --confirm-current-output --outcome pending
node scripts/skill-paid.mjs complete --state-dir "<同一目录>"
```

链接分支 pay 额外带 `--amt-payment-link "<本次 probe 原样返回的值>"`；不能从扫码图片或用户操作链接取替代值。每次实际官方命令后都记录本次 handoff。官方资源文件只存私有目录；资源已交付时可记录 resource_delivered。ack_failed 还须同次真实输出明确回执失败、非空资源文件和已交付确认。无把握时记录 unknown 并停止。

### 大输入、中断及回执 / Large inputs and recovery

大载荷只走同域 /stage 短引用，失败停止，不把大 JSON 塞回命令行。原文恢复副本存在包外私有目录。只有绑定的本次官方输出明确报告引用过期，用户在后续要求恢复并同意再次传输时，才可 restage --confirm-ref-expired --confirm-data-transfer --confirm-recovery-requested 一次；核对原文 SHA-256，保留原订单和幂等键，之后只恢复原单。

正常官方资源交付会自动处理回执。独立 ACK 只恢复已绑定的同次回执失败，且用户后续要求恢复；不重新请求资源。助手使用单次交接标记和锁拒绝重复/并发 ACK。没有真实证据不填确认标志。

付款启动未知不能删状态、换幂等键或再付一笔。已付款但业务失败保留原单，联系运营者核对恢复或退款；退款没有公开命令时不能自行构造。需要官方反馈时加载 alipay-payment-skill 的 references/feedback.md，先向用户确认脱敏内容后提交，不自动发送。

Windows 的文件 mode 不能保证 ACL；宿主须使用当前用户私有目录并核对访问范围。付款材料、当前官方文本、业务原文、资源文件、Cookie 和钱包凭据都不进入发布包或跨宿主同步。


# 帧叙·动态漫排剪专家 / Comic Animatic Edit Studio

## 触发场景 / When to use

漫画分镜已经确认，需要绑定画面/声音并交接动态漫排剪时使用。 Accept Mijing comic production kit panels and combine media bindings, animatic timing, SRT and missing-media checks.

## 本次交付 / Delivery

直接接收镜界漫剧制作套件或漫画格，组合媒体绑定、排剪时间线、SRT 字幕和缺项审查。

接受上一批制作套件的真实 timeline.panels，追加图像/音频资产绑定；不是另一个漫剧设定或画风包。

## 输入与交接 / Input and handoff

读取 [输入契约](references/input-contract.md) 和 [JSON Schema](references/input-schema.json)。使用用户提供或已确认的业务数据，缺关键字段时补齐；不得把虚构样例当真实指标、剧情事实或已生成素材。保留 projectId 与跨阶段对象 ID，来自前序结果的结构必须按实际字段映射。参考 [输入样例](references/input-example.json) 和 [隔离执行样例](references/output-example.json)。

## 调用与结果 / Execution

单次调用 ¥0.10，本产品内部组合上述交付项。多个独立产品串联时各自按次计费，调用前说明本次与累计次数；本产品不自动创建其他产品的付费调用。

按正式包的统一支付说明使用登记云端入口。只有原订单验付后返回的非空服务端结果可作为交付。付款准备参数必须由宿主实际执行，不能据参数输出宣称付款或已出码；不得从支付材料自行判断成交。失败、取消或凭证未知时保留原单，不能用本地推理、缓存或另一个入口补做本包收费结果。

交付字段：`animatic`, `subtitleSrt`, `timelineCsv`, `findings`, `mediaBindingComplete`。把 JSON 中的 CSV/SRT 文本按需另存为用户文件；不要声称媒体已渲染或内容已发布。保留待审项及未排入/省略记录，不能为“成功”隐藏缺项。

Use only verified cloud delivery for the original order. This product combines its stated outputs in one CNY 0.10 call. Separate products remain separately billed. Export embedded CSV/SRT text when requested and retain review findings. No local replacement, automatic posting or rendered-media claim.

## 数据与隐私 / Data and privacy

调用前说明：业务 JSON（选题、工时、原稿、角色、场景、资产 URI 元数据或导出指标）将发送至 fwskillpay-api.cn，供预检、结构计算、收费和恢复使用；取得本次传输与 ¥0.10 费用授权。资产 URI 不会由服务器下载，本业务不访问自媒体账户、不调用外部文本/图像/视频模型。支付宝接收交易所需账单与验证信息。

请求 JSON 不超过 256 Ki 字符时进入受限订单账本，成功执行后删除输入；未付款、失败或待恢复输入目前没有自动清理期限。已履约结果缓存期限为生成后 24 小时，随清理任务清除；未完成履约确认的结果为恢复用途保留。可选大载荷暂存默认 2 小时过期、每 5 分钟清理、24 小时硬上限。订单摘要、金额、状态及必要交易元数据目前没有自动删除期限。无自助删除接口，需要发布者人工核查，联系入口以 SkillHub 发布者页为准。使用匿名指标，不传登录凭据或与任务无关的个人信息。

The gateway receives the business JSON and asset identifiers only. It does not fetch assets or access creator accounts. Successful execution removes the persisted input; unpaid/failed recovery input and transaction metadata have no automatic deletion deadline. Fulfilled results expire after 24 hours; unconfirmed delivery data remains for recovery. Optional staging expires after 2 hours with a 5-minute sweep and 24-hour hard cap. Obtain consent before transmission and payment.

## 依赖与验收 / Dependencies and verification

客户端需要 Node.js 20+、可用的官方支付宝买方组件及当前真实会话。业务执行于登记网关，无业务模型 API Key 依赖。业务不生成图像、配音或视频文件。脚本、排期、指标准则和剪辑建议仍需创作者确认。

业务数据不变、有效分母、容量/时间边界及前序套件衔接已在隔离环境验收；未支付门禁、模拟验付后非空交付、原单幂等回放、改请求冲突及兼容入口拒绝交付已测试。生产 HTTPS 402、金额/资源/服务 ID 已核对。本批真实买方付款、SkillHub 真实会话案例和到账未验证，不把模拟结果或上传回执当资金证明。来源与复用范围见 [SOURCES.md](SOURCES.md)，许可证见 [LICENSE.txt](LICENSE.txt)。

## 已核对的输入示例 / Registered input example

```json
{
  "projectId": "demo-comic-01",
  "aspectRatio": "9:16",
  "panels": [
    {
      "panelId": "p1",
      "visual": "桌面上的小灯照亮纸张边缘",
      "dialogue": "先把这一页留在灯下。",
      "durationSec": 4,
      "motion": "slow-push-in"
    },
    {
      "panelId": "p2",
      "visual": "角色把带标记的纸张整齐收好",
      "dialogue": "明天再继续核对。",
      "durationSec": 6,
      "motion": "gentle-pan-left"
    }
  ],
  "assets": [
    {
      "assetId": "panel1",
      "kind": "image",
      "uri": "assets/lamp-panel.png",
      "rights": "创作者原创"
    },
    {
      "assetId": "panel2",
      "kind": "image",
      "uri": "assets/paper-panel.png",
      "rights": "创作者原创"
    }
  ],
  "bindings": [
    {
      "panelId": "p1",
      "imageAssetId": "panel1"
    },
    {
      "panelId": "p2",
      "imageAssetId": "panel2"
    }
  ]
}
```

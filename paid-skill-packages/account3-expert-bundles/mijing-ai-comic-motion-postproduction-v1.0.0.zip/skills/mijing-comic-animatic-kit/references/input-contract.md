# 输入、语义约束与输出

projectId 必需。panels 与 productionKit 只提供一种；productionKit 接收前序专家结果中的 productionKit 对象，并读取 timeline.panels。格数 1–80，总时长 ≤600；panelId 唯一，visual 与 durationSec（0.25–600）必需，可附 dialogue/motion/transition。assets 最多 100 项，资产结构与短视频剪辑包相同。bindings 最多 80 项，以唯一 panelId 指向可选 imageAssetId/audioAssetId；引用必须存在且类型匹配。未提供图像绑定可输出缺项清单，不虚构素材完成。aspectRatio 支持五种常见比例，显式值优先于前序套件比例，缺省 9:16。无自动调用前序收费接口。

通用约束：projectId 是 1–64 字符字符串；ID 不重复；引用必须存在；数值必须为 JSON 数字，不把字符串或负数误当有效数据。JSON Schema 表示字段/类型边界，跨对象引用、累计时长和预算由服务器额外校验。

接受上一批制作套件的真实 timeline.panels，追加图像/音频资产绑定；不是另一个漫剧设定或画风包。

返回字段：animatic, subtitleSrt, timelineCsv, findings, mediaBindingComplete。envelope 含 ok、service、projectId、schemaVersion、生成时间、原订单引用与结构化交付标记。CSV 单元格会转义引号及可能触发公式的前缀；SRT 导出规范化换行和箭头，JSON 原文字段保持输入内容。

样例全是原创虚构接口演示，不是实际账号绩效或真实付款交付。

# 输入契约 / Input contract

- 根对象严格符合 `input-schema.json`，拒绝额外字段。
- 样例是虚构数据；不可当作真实事实、客户记录或平台规则。
- `mijing-comic-localization-review-desk` 输出字段：`localizedLines / glossaryChecks / layoutChecks / reviewQueue / summary / reviewCsv`。
- CSV 使用 UTF-8 和固定列顺序；公式字符经过转义。
- 有效输入才生成业务交付；错误输入不得当作成功结果。
- 只处理用户提供的信息，不请求外部平台或调用模型。

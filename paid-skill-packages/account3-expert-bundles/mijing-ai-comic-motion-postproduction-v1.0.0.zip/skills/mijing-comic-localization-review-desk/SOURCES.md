# 来源与改造说明

suphotP/manga-translation-studio (MIT; pinned commit e98bbaf0c4974ff5ae11d34f473c24210ef2c41e), workflow reference only; repository author labels it as-is and not actively maintained. No code or image assets copied.

本产品仅参考公开工作流；未复制上游代码、图片、示例或账号私有资料。原创说明、数据契约、示例与执行器按本目录 `LICENSE.txt` 许可。
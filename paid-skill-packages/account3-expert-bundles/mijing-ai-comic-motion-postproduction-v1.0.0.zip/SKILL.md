---
name: mijing-ai-comic-motion-postproduction
description: 动态漫时间线、镜头预演、声音制作与多语审校协作。 按需路由到本包的专项技能；付费调用前明确列出服务与费用。
license: MIT
---

# 镜界·AI漫剧动态预演与后期协作包

## 适用任务

动态漫时间线、镜头预演、声音制作与多语审校协作。

## 执行方式

1. 先识别用户要完成的具体环节，只加载下方目录中相关的专项 `SKILL.md` 和它引用的资料。
2. 按该专项技能的输入契约收集必需信息；缺少关键输入时先列出缺项，不虚构业务事实或结果。
3. 输出前遵守专项的格式与质量检查要求，并清楚区分已知事实、推断和待确认事项。
4. 仅当用户明确需要且已授权相应服务调用时，才调用对应的付费执行器。专项包的现行支付契约为 ¥0.10/次；一次任务若需多个专项调用，先逐项说明调用对象和费用，获得授权后再执行，不将订阅/买断与按次服务费混为一谈。
5. 不自动发布内容、不替用户付款、不承诺流量或销售结果；需人工确认的平台规则、权利或事实问题应明确标出。

## 专项技能目录

| 专项 | 路径 |
|---|---|
| mijing-comic-animatic-kit | `skills/mijing-comic-animatic-kit/SKILL.md` |
| 绘动·动态漫交互预演 / Interactive Comic Motion Preview | `skills/mijing-comic-motion-preview/SKILL.md` |
| 声格·漫剧配音与音效提示单 / Comic Voice and Sound Cue Board | `skills/mijing-comic-audio-cue-board/SKILL.md` |
| 漫译·AI漫剧多语本地化审校台 / Comic Localization Review Desk | `skills/mijing-comic-localization-review-desk/SKILL.md` |
| 声轨·AI漫剧配音录制与补录台 / Comic Voice Recording Board | `skills/mijing-comic-voice-recording-board/SKILL.md` |

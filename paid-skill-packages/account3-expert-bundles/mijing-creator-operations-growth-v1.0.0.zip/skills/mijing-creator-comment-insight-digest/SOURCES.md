# 来源 / Sources

本批业务执行器、说明、虚构样例和图标为原创 MIT 组件；仅复用本项目 CSV 安全转义与通用 SkillHub Pay Skill 交接 helper。没有复制其他账号的技能或图标。

Original MIT business executors, documentation, fictional samples and icons. Shared code is limited to CSV formula-safe escaping and the canonical SkillHub Pay Skill handoff. No packages or icons from other accounts are redistributed.

SkillHub publication guide: https://skillhub.cn/tutorials#alipay-pay . Package contract follows the supplied unified payment template v1.0.4. Alipay Machine Pay reference: https://aipay.alipay.com/docs/ai-receive/MACHINE_PAY.html . This does not assert that Machine Pay and SkillHub Pay Skill are the same protocol.

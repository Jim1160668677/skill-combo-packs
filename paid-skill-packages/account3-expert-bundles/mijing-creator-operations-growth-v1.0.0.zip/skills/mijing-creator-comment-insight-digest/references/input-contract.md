# 输入契约 / Input contract

提供 projectId 与1–10000条 comments。每条只含本地 refId、0–8个 topicTags，以及 isQuestion、needsReply、needsHumanReview 布尔标记；可选 priority 为 normal 或 high。不要提交评论正文、昵称、账号、联系方式或用户画像。标签和标记由创作者提供，服务不推断情绪。

Provide projectId and 1–10,000 comments. Each row contains only a local refId, 0–8 topicTags, and isQuestion, needsReply and needsHumanReview booleans; optional priority is normal or high. Do not submit comment text, handles, accounts, contact details or profiles. Tags and flags are creator-assigned; the service does not infer sentiment.

The service also validates unique identifiers, cross-field timing constraints, and aggregate limits.

# 输入契约 / Input contract

提供 projectId、拟发布日期 publishDate、目标 targetChannels 和 targetTerritories，以及1–200项 assets。每项含唯一 assetId、kind、sourceType；可补 evidenceRef、scopeUnrestricted、permittedChannels、permittedTerritories、validFrom、validUntil、attributionRequired、attributionText、consentEvidenceRef、aiTermsChecked。scopeUnrestricted=true 表示创作者声明范围不受限制；否则许可渠道和地区必须覆盖目标。voice/likeness 必须提供 consentEvidenceRef。日期为 YYYY-MM-DD。

Provide projectId, publishDate, targetChannels, targetTerritories and 1–200 assets. Each asset needs a unique assetId, kind and sourceType; optional fields record evidenceRef, scopeUnrestricted, permittedChannels, permittedTerritories, validFrom, validUntil, attributionRequired, attributionText, consentEvidenceRef and aiTermsChecked. scopeUnrestricted=true is a creator declaration; otherwise declared channel and territory scopes must cover the targets. Voice/likeness entries require consentEvidenceRef. Dates use YYYY-MM-DD.

Cross-field dates, unique IDs, scope matching and aggregate limits are validated by the service in addition to JSON Schema.

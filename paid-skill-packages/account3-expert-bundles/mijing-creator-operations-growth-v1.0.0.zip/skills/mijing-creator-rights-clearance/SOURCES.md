# 来源 / Sources

业务执行器、双语说明、虚构样例及本批图标为本项目原创 MIT 组件；仅复用本项目通用 CSV 安全转义和统一支付交接。没有复制账号一/二的技能包或图标。

Original MIT business executors, bilingual docs, fictional samples and icons. Only shared CSV escaping and the canonical payment handoff are reused. No skill packages or icons from accounts one/two are redistributed.

SkillHub Pay Skill publication guide: https://skillhub.cn/tutorials#alipay-pay . Package contract uses the supplied unified template v1.0.4.

Alipay AI pay 402 protocol reference: https://aipay.alipay.com/docs/ai-receive/MACHINE_PAY.html . This link is used for the HTTP 402/payment-proof protocol reference; it does not imply a claim that SkillHub Pay Skill and Machine Pay are the same product.

# 输入、语义约束与输出

必需 projectId、startDate、audience、goal、availableMinutesPerWeek、pillars、topics。startDate 是真实 YYYY-MM-DD；工时 15–10080 分钟/周。pillars 1–8 项，topic 1–60 项，每条需要 topicId、pillarId、title、opening、value、effortMinutes（5–1200 的整数）；priority 0–100，默认 50。ID 不重复且支柱引用必须存在。publishingWeekdays 为不重复的 1–7（周一到周日），默认工作日；maxPostsPerWeek 1–7，默认 3；reviewReserveRatio 0–0.5，默认 0.2。每个可用日最多排一条；按优先级、工时和 ID 稳定排序，最多 14 日。

通用约束：projectId 是 1–64 字符字符串；ID 不重复；引用必须存在；数值必须为 JSON 数字，不把字符串或负数误当有效数据。JSON Schema 表示字段/类型边界，跨对象引用、累计时长和预算由服务器额外校验。

从真实工时和指定星期计算安排，保留未排入的选题及原因；不是热点搜索或流量预测。

返回字段：operatingBrief, calendar, capacity, unscheduled, calendarCsv, measurementPlan。envelope 含 ok、service、projectId、schemaVersion、生成时间、原订单引用与结构化交付标记。CSV 单元格会转义引号及可能触发公式的前缀；SRT 导出规范化换行和箭头，JSON 原文字段保持输入内容。

样例全是原创虚构接口演示，不是实际账号绩效或真实付款交付。

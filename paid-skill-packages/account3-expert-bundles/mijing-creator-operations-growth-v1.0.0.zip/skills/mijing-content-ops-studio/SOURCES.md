# 来源和组件复用

本产品业务逻辑、文档、示例为镜界项目原创。复用统一的 ID/数值校验、CSV 与 SRT 导出、角色锚点和制作交接合同。连载统筹复用既有短剧连续性实现；动态漫排剪兼容既有漫剧制作套件的 timeline.panels 数据，不会自动调用其收费入口。没有分发第三方同名 Skill、外部模型或图像生成工具的代码。

客户端支付助手来自统一支付链模板 v1.0.4。协议依据：https://aipay.alipay.com/docs/ai-receive/MACHINE_PAY.html 。平台发布参考：https://skillhub.cn/tutorials#alipay-pay 。指标模型区间采用常见 Wilson 二项区间，仅按标注假设作描述，不用于因果结论。

方形图标由内置 imagegen 原创生成，无第三方平台标识。MIT 许可证覆盖本项目原稿和示例，服务调用价格与源码许可证分开。

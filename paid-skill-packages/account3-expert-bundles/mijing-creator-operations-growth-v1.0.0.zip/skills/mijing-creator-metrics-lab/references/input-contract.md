# 输入、语义约束与输出

projectId/metricDefinition/posts 必需。posts 1–300 条，postId 唯一；platform、format、真实 publishedDate、observationDays（1–365 的整数）、views（0–1e10 的整数）必需。clicks/conversions 可缺省但如给出必须为非负整数；缺省在规范化结果中为 null。按 platform+format+observationDays 分组。比率是有效记录计数之和除以相应有效记录的 views 之和，不是平均单条百分比；分母为零返回 null。点击数超 views 或零 views 有正事件会标待核对。Wilson 描述区间只在数值满足二项范围时计算，标记独立性未验证；没有显著性、因果或收益结论。例子为虚构演示数据，禁止用于真实运营判断。

通用约束：projectId 是 1–64 字符字符串；ID 不重复；引用必须存在；数值必须为 JSON 数字，不把字符串或负数误当有效数据。JSON Schema 表示字段/类型边界，跨对象引用、累计时长和预算由服务器额外校验。

以用户导出记录计算真实分母，缺失值不充作零；与泛用分析提示词和流量预测产品不同。

返回字段：metricDefinition, normalizedPosts, dataQuality, comparisons, comparisonCsv, nextExperiment。envelope 含 ok、service、projectId、schemaVersion、生成时间、原订单引用与结构化交付标记。CSV 单元格会转义引号及可能触发公式的前缀；SRT 导出规范化换行和箭头，JSON 原文字段保持输入内容。

样例全是原创虚构接口演示，不是实际账号绩效或真实付款交付。

# 漫剧输入契约 / Comic input contract

`mode` 支持 production-kit、series-bible、episode-outline、style-guide、character-sheet、panel-storyboard、continuity-audit、asset-prompt-pack、motion-timeline。题材 genre：xianxia、urban_romance、suspense、scifi_cyberpunk、history_myth、comedy_healing、youth_growth、family_fable。画风 visualStyle：guofeng_ink、modern_webtoon、cinematic_2d、warm_watercolor、retro_print、paper_cut、cyberpunk_neon、mythic_ornate。

除 motion-timeline 外均需 genre；除 continuity-audit 和 motion-timeline 外均需 visualStyle。专项包会补齐它固定的 genre/visualStyle，并拒绝冲突值，缺省 mode 为 production-kit。默认完整制作路径的 JSON Schema 见 default-kit.schema.json；高级模式按以下契约由服务端逐项校验。

- production-kit：premise 字符串 10–1200 字符；characters 1–12 个；scenes 1–20 个；panelsPerScene 1–6，默认 3。总格数 ≤80、时长合计 ≤600 秒、每格 ≥0.25 秒；去重角色/地点/场景道具合计 ≤80；场景中的角色必须已登记。
- series-bible：premise 10–1200；episodeCount 1–30，默认 8；episodeDurationSec 15–600，默认 90；可选 audience 2–160、characters 0–12。
- episode-outline：premise 10–1200；episodeNumber 1–300，默认 1；episodeGoal 5–500；可选 characters 0–12。
- style-guide：可选 characters 0–12、aspectRatio 字符串 3–16，默认 9:16。
- character-sheet：characters 1–12。
- panel-storyboard：scenes 1–30；panelsPerScene 1–6，默认 3；可选 characters 和 aspectRatio。
- continuity-audit：characters 1–12、scenes 1–60。只比较已提供锚点，备注不能自动证明变化合理。
- asset-prompt-pack：assets 1–30；每项 kind 为 character/location/prop，name 1–80，description 5–500；可选 anchor。
- motion-timeline：panels 1–80；panelId 字符串 1–64，visual 5–500，durationSec 0.25–600；总时长 ≤600。可选 dialogue、motion、transition；这里只生成剪辑建议。

characters：name 字符串 1–48（不重复），appearance 与 wardrobe 字符串 1–240；可选 role、voice、motivation、signatureProps。scenes：sceneId 1–64（不重复）、location 1–160、action 5–600；durationSec 为 1–600 整数（默认 6）；可选 time、dialogue、props、continuityNote、characters。场景 characters 项必须为含 name 的对象，可附 appearance/wardrobe/voice/props。名称不能用字符串数组代替对象数组。

Dialogue is carried from the supplied scenes, not invented. Unique IDs and known character anchors are enforced. Panel durations are split to hundredths of a second while preserving each scene total. SRT newlines and arrows are sanitized only for export; other output retains source dialogue. Caption speed flags are advisory.

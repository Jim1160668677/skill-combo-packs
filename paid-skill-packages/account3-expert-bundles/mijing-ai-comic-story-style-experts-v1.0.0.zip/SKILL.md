---
name: mijing-ai-comic-story-style-experts
description: 多题材漫剧故事与风格制作工作流，含全案导演和四类风格专家。 按需路由到本包的专项技能；付费调用前明确列出服务与费用。
license: MIT
---

# 镜界·AI漫剧多题材风格创作专家包

## 适用任务

多题材漫剧故事与风格制作工作流，含全案导演和四类风格专家。

## 执行方式

1. 先识别用户要完成的具体环节，只加载下方目录中相关的专项 `SKILL.md` 和它引用的资料。
2. 按该专项技能的输入契约收集必需信息；缺少关键输入时先列出缺项，不虚构业务事实或结果。
3. 输出前遵守专项的格式与质量检查要求，并清楚区分已知事实、推断和待确认事项。
4. 仅当用户明确需要且已授权相应服务调用时，才调用对应的付费执行器。专项包的现行支付契约为 ¥0.10/次；一次任务若需多个专项调用，先逐项说明调用对象和费用，获得授权后再执行，不将订阅/买断与按次服务费混为一谈。
5. 不自动发布内容、不替用户付款、不承诺流量或销售结果；需人工确认的平台规则、权利或事实问题应明确标出。

## 专项技能目录

| 专项 | 路径 |
|---|---|
| 镜界 AI 漫剧全案导演 / Mijing AI Comic Drama Expert | `skills/mijing-ai-comic-drama-expert/SKILL.md` |
| 暖光小巷·治愈漫剧制作专家 / Watercolor Healing Comic Studio | `skills/mijing-healing-watercolor-comic-expert/SKILL.md` |
| 霓城回声·赛博漫剧制作专家 / Neon Cyberpunk Comic Studio | `skills/mijing-cyberpunk-neon-comic-expert/SKILL.md` |
| 暗线追踪·悬疑漫剧制作专家 / Cinematic Mystery Comic Studio | `skills/mijing-suspense-cinematic-comic-expert/SKILL.md` |
| 灵境水墨·仙侠漫剧制作专家 / Ink Xianxia Comic Studio | `skills/mijing-xianxia-ink-comic-expert/SKILL.md` |

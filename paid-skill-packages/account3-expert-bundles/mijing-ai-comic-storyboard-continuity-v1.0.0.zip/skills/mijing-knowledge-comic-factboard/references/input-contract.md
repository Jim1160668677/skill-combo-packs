# 输入契约 / Input contract

- 根对象必须符合 `input-schema.json`，拒绝额外字段。
- 只提交本产品当前阶段所需的信息，不上传账号凭据、个人身份或未授权素材。
- `input-example.json` 是完全虚构的示例，不可当作真实商品/达人/社群或事实证据。
- `mijing-knowledge-comic-factboard` 输出字段：`summary / panelEvidenceRows / unmappedClaims / findings / panelCsv`。
- CSV 使用 UTF-8、逗号分隔、双引号包裹，并对以 `=`, `+`, `-`, `@` 开头的单元格执行公式注入防护。
- 输出记录创建时间和订单引用；订单字段由服务运行上下文提供。有效输入才生成业务交付。
- 数据处理不请求外部平台，不调用第三方模型或自动发布；知识与业务事实的准确性仍由提交者和人工审查负责。

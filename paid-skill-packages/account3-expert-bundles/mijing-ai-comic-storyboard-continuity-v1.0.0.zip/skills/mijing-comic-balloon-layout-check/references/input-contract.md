# 输入契约 / Input contract

提供 projectId、1–120个 panels；每格提供 panelId、widthPx、heightPx 和1–40个 balloons。每个气泡含唯一 balloonId 与 text，可指定 speakerId、maxGraphemesPerLine、maxLines、maxGraphemes、safeWidthRatio 与 safeHeightRatio。全局默认值分别为14字素/行、4行、80字素；断行仅作估算。

Provide projectId and 1–120 panels, each with panelId, widthPx, heightPx and 1–40 balloons. Each balloon needs a unique balloonId and text; optional fields set speakerId, maxGraphemesPerLine, maxLines, maxGraphemes, safeWidthRatio and safeHeightRatio. Defaults are 14 graphemes per line, 4 lines and 80 graphemes per balloon. Line breaks are estimates.

The service also validates unique identifiers, cross-field timing constraints, and aggregate limits.

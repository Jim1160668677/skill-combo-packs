# 来源 / Sources

业务、文档、例子均为镜界原创MIT组件。复用项目的字段约束和CSV/时间序列化；现有秒构SRT可进入幕检。没有复制另一账号的泛用视频提示流程，或把角色连续性/按地点分组包装成素材依赖图或时间窗口计算。作者技能与平台发布元数据分开构建；正式云端付费包不分发本地完整业务执行器。

Original MIT business/components and fictional examples. The client payment helper comes from the canonical unified payment-chain template1.0.4. No third-party Skill source or proprietary artwork is redistributed. Icons are original built-in imagegen assets.

Unicode segmentation reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/Segmenter
WebVTT reference: https://developer.mozilla.org/en-US/docs/Web/API/WebVTT_API/Web_Video_Text_Tracks_Format
Filename rules: https://learn.microsoft.com/en-us/windows/win32/fileio/naming-a-file
Payment reference: https://aipay.alipay.com/docs/ai-receive/MACHINE_PAY.html

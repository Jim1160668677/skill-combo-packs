# 输入契约 / Input contract

提供projectId及1–300格，panelId唯一、sceneId必需；axisSide可选A/B/neutral，axisCrossingShown可标明本格已交代越轴或重新建立轴线。characters可含0–20个角色标注，每个characterId唯一，x/y为0–1画面归一化坐标，lookDirection可选left/right/up/down/camera/unknown，visible默认true。facingPairs可声明本格正在对话的一对角色。maxPositionJump阈值为0.1–1，默认0.45欧氏归一化距离。重复panel/角色ID、未知视线值、超界坐标和不存在的配对角色在收费前拒绝。

Provide a projectId and 1–300 ordered panels with unique panelId and sceneId. axisSide may be A/B/neutral; axisCrossingShown can mark a declared crossing or re-establishing shot. Each panel may include 0–20 unique character annotations with normalized x/y in [0,1], optional lookDirection left/right/up/down/camera/unknown and visible (default true). facingPairs declare two characters facing each other in that panel. maxPositionJump is a 0.1–1 normalized Euclidean distance (default 0.45). Duplicate IDs, invalid gaze labels, out-of-range positions and pairs with missing characters are rejected before billing.

Cross-field ranges and semantic checks are enforced by the service in addition to JSON Schema.

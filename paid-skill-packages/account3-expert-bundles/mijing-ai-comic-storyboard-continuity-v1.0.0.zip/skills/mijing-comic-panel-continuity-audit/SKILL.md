---
name: mijing-comic-panel-continuity-audit
description: 按创作者标注的轴线、角色画面位置与视线，交付漫剧分镜跳位、轴线和对视方向复核清单。 AI漫剧或动画分镜已排好，需要在绘制或生成画面前检查相邻镜头的空间方向和人物连续性时使用。 Review annotated storyboard
  axis sides, character positions and gaze directions; deliver panel jump, axis and eyeline findings.
license: MIT
metadata:
  display_name: 格序·漫剧分镜连续性核对 / Comic Storyboard Continuity Review
displayName: 格序·漫剧分镜连续性核对 / Comic Storyboard Continuity Review
summary: '中文：按创作者标注的轴线、角色画面位置与视线，交付漫剧分镜跳位、轴线和对视方向复核清单。 / English: Review annotated storyboard axis sides, character positions
  and gaze directions; deliver panel jump, axis and eyeline findings.'
slug: mijing-comic-panel-continuity-audit
version: 1.0.0
pricing:
  model: per_call
  amount_fen: 10
  currency: CNY
---

<!-- unified-payment-template: 1.0.4 -->
## 支付依赖与恢复 / Payment runtime and recovery

运行时需要 Node.js 20+ 和宿主的支付宝官方 `alipay-payment-skill`、`alipay-bot`。宿主不同不代表钱包授权可以搬运。正常第一条支付宝业务命令是官方 buyer-pay 或原单查询，不能加通用 check-wallet 前检。

只有真实业务命令无法找到/执行 alipay-bot 时，才加载官方技能的 `references/command-recovery.md`：取得外部安装授权，核对指定版本 `@alipay/agent-payment@1.0.23` 的官方完整性后安装，再重试原命令一次。不能每次调用都安装 latest，不能把卖家部署工具当作买方依赖；已启动但业务失败时原样展示并停止。

English: Use the current host's official Alipay buyer runtime. Only an actual command-not-found failure enters the official pinned-version installation recovery. Do not reinstall on every call, precheck wallets generically, or install merchant tooling in the buyer path.

仅在上述恢复条件成立且已获外部安装授权时执行下列两步。先查询完整性，必须逐字符等于下面的指定值；不一致或查不到则停止，不能继续安装：

```text
npm view '@alipay/agent-payment@1.0.23' dist.integrity --registry 'https://registry.npmjs.org'
```

```text
sha512-7OGSHhPnuKsyENpivpY60NgE77ktKtWTP8UBtmizeB1Et44KHFFIjDcSRIFpitEdKAC7uMBx3Mp1Zg/wbYmYCQ==
```

核对一致后才执行安装，并仅重试原先无法执行的命令一次：

```text
npx -y --registry=https://registry.npmjs.org @alipay/agent-payment@1.0.23 install
```

这里的命令是依赖恢复说明，不是正常付款前置；官方技能版本更新时须重新对照其 command-recovery.md，不沿用过期完整性值。

## 本包现行支付流程 / Registered checkout

本包支付配置为 payment-contract.json：资源 `mijing-comic-panel-continuity-audit`、单价 ¥0.10 / CNY、支付宝服务 ID `API_FC3B91AF109D47C8`、完整服务地址 `https://fwskillpay-api.cn/v1/pay/skills/mijing-comic-panel-continuity-audit/invoke`。配置与 SKILL/助手哈希不符即停止。平台展示价须在提交后单独回读，不能从本包检查推定平台价已经一致。

1. 调用前披露输入范围、接收方、用途、留存及 ¥0.10，取得本次数据传输和该金额的付款授权。已有授权不再二次询问；价格一致也不能代替授权。
2. 在包外私有目录准备 payload.json，按本 Skill 的输入契约执行 probe。400、503、429、未知网络状态或未付款的 200 都停止，不能本地代做付费结果。
3. 只核对网关公开 JSON 摘要中的金额、币种、商户订单号、资源 ID、服务 ID 和有效期；任一字段缺失、类型错误、过期或与登记不符都停止，不进入 pay。不解码 Payment-Needed 或 amtPaymentLink，不自行验签；公开摘要不能证明签名、实际付款或到账。
4. 本次唯一非空 amtPaymentLink 优先，并原样交给官方 `--amt-payment-link`，不写付款材料文件；链接缺失才使用原值保存的 Payment-Needed 文件。空、多个或歧义链接停止，两种参数互斥，不能补造或从历史输出补齐。
5. 已有该金额授权时立即准备 pay，宿主在返回的 workingDirectory 实际用 executable 与参数数组运行官方 buyer-pay。参数 JSON 不算弹码。会话按下表取值，保持本次原请求与幂等键。
6. 原样输出当前官方对客文本一次，完整展示全部 MEDIA 图片；不复用旧图、不绘制替代二维码。链接生成、success:true、OPEN_LINK_CREATED 不代表付款或交付。
7. 宿主把刚执行的官方对客文本保存在包外私有文件，用本次 handoffId 执行 record-official。只从“订单号/查询单号/交易号”标签提取标识；拒绝原始 JSON、其他交接或冲突标识。观察分类由宿主依据真实输出选择，不是 helper 验付。
8. 用户表示付好或要求查询时，complete 按已绑定标识查询原单：有效 32 位、11–14 位为 8282 的查询号优先；否则用本次交易号。查询不附加 session-id、账单文件或付款链接。未绑定原单停止，不能猜测。
9. 只交付官方实际返回的非空验付后资源。成功交付、业务失败、资源为空、身份不符或查询失败后停止；仅命令超时/网络失败允许按官方规则重试原命令一次。不能从 success 字样认定收款。

English: Obtain data-transfer and price authorization before probe. Compare the public checkout summary while passing payment material unchanged to the official runtime. A unique amtPaymentLink takes priority over an opaque Payment-Needed file. Actually execute the returned argument array, show all current official media, then bind the current official customer-facing output to its handoff. Query only the bound original order. Deliver only actual nonempty official resources. Offline helper checks and host observations are not proof of payment or settlement.

### 当前会话 / Current session

取首个非空来源，高优先级不能被低优先级覆盖：

| 优先级 | 当前运行时来源 |
|---|---|
| 1 | sessionId / session_id 元数据 |
| 2 | threadId / thread_id / conversationId / conversation_id / agentContextId；Codex 使用 CODEX_THREAD_ID |
| 3 | 前两级都为空才用 AIPAY_SESSION_ID |

不能生成会话 ID，不能用订单号、交易号、用户/钱包 ID、URL、测试名或历史会话代替；陈旧环境变量不能覆盖当前显式会话。官方订单号形状（32 位数字且第 11–14 位为 8282）只用于查询，任何符合该形状的串都不是会话，宿主号码仍按逐级取值。全部为空则停止。The current runtime identity takes precedence over inherited environment values.

### 助手调用 / Helper calls

```text
node scripts/skill-paid.mjs probe --state-dir "<包外私有目录>" --payload-file "<包外私有目录>/payload.json" --confirm-data-transfer
node scripts/skill-paid.mjs pay --state-dir "<同一目录>" --session-id "<当前真实会话>" --intent-summary "原始请求：<本次业务目的摘要>" --confirm-payment
node scripts/skill-paid.mjs record-official --state-dir "<同一目录>" --handoff-id "<刚输出的交接ID>" --official-output-file "<刚执行的官方对客文本文件>" --confirm-current-output --outcome pending
node scripts/skill-paid.mjs complete --state-dir "<同一目录>"
```

链接分支 pay 额外带 `--amt-payment-link "<本次 probe 原样返回的值>"`；不能从扫码图片或用户操作链接取替代值。每次实际官方命令后都记录本次 handoff。官方资源文件只存私有目录；资源已交付时可记录 resource_delivered。ack_failed 还须同次真实输出明确回执失败、非空资源文件和已交付确认。无把握时记录 unknown 并停止。

### 大输入、中断及回执 / Large inputs and recovery

大载荷只走同域 /stage 短引用，失败停止，不把大 JSON 塞回命令行。原文恢复副本存在包外私有目录。只有绑定的本次官方输出明确报告引用过期，用户在后续要求恢复并同意再次传输时，才可 restage --confirm-ref-expired --confirm-data-transfer --confirm-recovery-requested 一次；核对原文 SHA-256，保留原订单和幂等键，之后只恢复原单。

正常官方资源交付会自动处理回执。独立 ACK 只恢复已绑定的同次回执失败，且用户后续要求恢复；不重新请求资源。助手使用单次交接标记和锁拒绝重复/并发 ACK。没有真实证据不填确认标志。

付款启动未知不能删状态、换幂等键或再付一笔。已付款但业务失败保留原单，联系运营者核对恢复或退款；退款没有公开命令时不能自行构造。需要官方反馈时加载 alipay-payment-skill 的 references/feedback.md，先向用户确认脱敏内容后提交，不自动发送。

Windows 的文件 mode 不能保证 ACL；宿主须使用当前用户私有目录并核对访问范围。付款材料、当前官方文本、业务原文、资源文件、Cookie 和钱包凭据都不进入发布包或跨宿主同步。


# 格序·漫剧分镜连续性核对 / Comic Storyboard Continuity Review

## 交付结果 / Deliverable

按创作者标注的轴线、角色画面位置与视线，交付漫剧分镜跳位、轴线和对视方向复核清单。

Review annotated storyboard axis sides, character positions and gaze directions; deliver panel jump, axis and eyeline findings.

## 适用场景 / When to use

AI漫剧或动画分镜已排好，需要在绘制或生成画面前检查相邻镜头的空间方向和人物连续性时使用。

Use after an AI comic or animation storyboard is ordered to review screen direction and character continuity before artwork production.

逐格比较创作者提供的画面坐标、轴线侧和视线标注；不读图像，也不等同于单张画幅裁切或人物设定提示。

Compares creator-supplied per-panel coordinates, axis side and gaze annotations; it does not inspect images or perform frame cropping or character prompt design.

## 输入与计算 / Input and processing

提供projectId及1–300格，panelId唯一、sceneId必需；axisSide可选A/B/neutral，axisCrossingShown可标明本格已交代越轴或重新建立轴线。characters可含0–20个角色标注，每个characterId唯一，x/y为0–1画面归一化坐标，lookDirection可选left/right/up/down/camera/unknown，visible默认true。facingPairs可声明本格正在对话的一对角色。maxPositionJump阈值为0.1–1，默认0.45欧氏归一化距离。重复panel/角色ID、未知视线值、超界坐标和不存在的配对角色在收费前拒绝。

Provide a projectId and 1–300 ordered panels with unique panelId and sceneId. axisSide may be A/B/neutral; axisCrossingShown can mark a declared crossing or re-establishing shot. Each panel may include 0–20 unique character annotations with normalized x/y in [0,1], optional lookDirection left/right/up/down/camera/unknown and visible (default true). facingPairs declare two characters facing each other in that panel. maxPositionJump is a 0.1–1 normalized Euclidean distance (default 0.45). Duplicate IDs, invalid gaze labels, out-of-range positions and pairs with missing characters are rejected before billing.

Read [input contract](references/input-contract.md), [JSON Schema](references/input-schema.json), and the [fictional input](references/input-example.json) before preparing creator data. Preserve the creator's IDs and annotations; do not replace missing facts with the demo. A fictional output shape is in [output-example.json](references/output-example.json).

## 输出与验收 / Output and acceptance

返回：`summary`, `panelRows`, `transitionRows`, `findings`, `panelCsv`。合法输入经服务器完成后，结果包含可追溯的输入ID、数量、阈值、发现项和CSV；校验失败返回400且不创建账单。

Returns the fields listed above. A successful server result retains traceable input IDs, counts, thresholds, findings and CSV; invalid input is rejected with 400 before a bill is created.

## 边界 / Limits

在同一sceneId的相邻格间检查非中性轴线翻转、可见同角色的大坐标跳变和已声明对话角色的视线方向。场景切换会重置比较；人工标注越轴不报为问题。未标注位置只提示缺数据。系统不识别真实画面；标记是人工复核提示，蒙太奇、透视变化或有意调度可能合理。

Within adjacent panels of the same sceneId, checks non-neutral axis flips, large coordinate jumps for visible recurring characters and gaze direction for declared facing pairs. Scene changes reset comparison; an explicitly marked axis crossing is not flagged. Missing annotations remain visible. No image recognition is performed; findings are review prompts and intentional montage, perspective or blocking changes may be valid.

## 计费与失败 / Billing and failure

每次¥0.10。内部多个输出作为一次服务交付，不串调其他付费产品。拒绝传输、未支付、网关失败、验付失败或状态未知时停止；不在本地代做结果、不换兼容入口、不重建未知订单。按统一支付说明将原请求交给宿主官方买方组件；准备命令参数不表示二维码显示或付款。

CNY 0.10 per server call covers the stated outputs; this package does not call other paid products. If transfer/payment is declined, gateway or verification fails, or order state is unknown, stop without local substitute results, alternate routes or replacement orders. Pass the original request to the host's official buyer component per the payment flow; prepared arguments do not prove QR display or payment.

## 数据与隐私 / Data and privacy

业务 JSON（镜头时间点和拍点、角色画面位置/视线、开场文案候选和测试设置）发送到 fwskillpay-api.cn 用于预检、计算、计费和恢复；在传输前应取得明确同意及本次金额的付款授权。服务不下载原视频、图像或音频，不访问创作者账号，不调用外部生成模型；支付宝接收交易所需信息。

成功执行后服务会删除持久化输入；未付款、失败或待恢复输入没有自动清理期限。已履约结果缓存24小时，未完成履约确认的结果保留用于恢复。可选大载荷暂存默认2小时、每5分钟清理、24小时硬上限。订单和必要交易元数据没有自动删除期限，目前没有自助删除接口，需发布者人工处理。请勿提交真实姓名、联系方式、登录凭据或未公开的敏感剧本。下载的CSV/报告由使用者保存和删除。

The business JSON (shot/beat timestamps, annotated character positions/gaze, hook candidates and test settings) is sent to fwskillpay-api.cn for validation, computation, billing and recovery. Obtain explicit consent for this transfer and authorization for the disclosed charge. The service does not fetch source video/images/audio, access creator accounts or call external generative models; Alipay receives transaction data.

Persisted input is removed after successful execution; unpaid, failed or recovery input has no automatic deletion deadline. Fulfilled results are cached for 24 hours; unconfirmed delivery is retained for recovery. Optional large-payload staging defaults to 2 hours, is swept every 5 minutes and has a 24-hour hard cap. Orders and necessary transaction metadata have no automatic deletion deadline; no self-service deletion API is available and publisher intervention is needed. Avoid real names, contact details, credentials and unpublished sensitive scripts. Users retain/delete downloaded CSV and reports.

## 依赖与版本 / Dependencies and version

版本1.0.0。客户端Node.js20+及宿主官方支付宝买方组件/真实会话；云端业务由已登记自有网关运行，无第三方业务模型密钥依赖。业务在Linux/Node22验证，包构建在Windows/Node24完成；未在macOS实机验收。输出文本与结构化数据，不提供视频/图像/音频渲染、平台发布或自动AB投放。真实买方付款、SkillHub原生二维码和卖家结算未在本批验证。

Version 1.0.0. Client requires Node.js20+ and the host's official Alipay buyer runtime/session. Hosted business runs on the registered gateway and uses no third-party model API key. Business verified on Linux/Node22 and packaging on Windows/Node24; macOS not physically tested. Returns text/structured data, without media rendering, platform posting or automatic experiment delivery. Buyer payment, SkillHub-native QR and seller settlement are not verified in this batch. See [SOURCES.md](SOURCES.md) and [MIT license](LICENSE.txt).

## 已核对的输入示例 / Registered input example

```json
{
  "projectId": "demo-panels-01",
  "panels": [
    {
      "panelId": "p1",
      "sceneId": "dialogue",
      "axisSide": "A",
      "characters": [
        {
          "characterId": "hero",
          "x": 0.3,
          "y": 0.6,
          "lookDirection": "right"
        },
        {
          "characterId": "friend",
          "x": 0.7,
          "y": 0.6,
          "lookDirection": "left"
        }
      ],
      "facingPairs": [
        {
          "a": "hero",
          "b": "friend"
        }
      ]
    },
    {
      "panelId": "p2",
      "sceneId": "dialogue",
      "axisSide": "A",
      "characters": [
        {
          "characterId": "hero",
          "x": 0.35,
          "y": 0.6,
          "lookDirection": "right"
        },
        {
          "characterId": "friend",
          "x": 0.68,
          "y": 0.6,
          "lookDirection": "left"
        }
      ],
      "facingPairs": [
        {
          "a": "hero",
          "b": "friend"
        }
      ]
    },
    {
      "panelId": "p3",
      "sceneId": "dialogue",
      "axisSide": "B",
      "characters": [
        {
          "characterId": "hero",
          "x": 0.8,
          "y": 0.6,
          "lookDirection": "left"
        },
        {
          "characterId": "friend",
          "x": 0.2,
          "y": 0.6,
          "lookDirection": "right"
        }
      ]
    }
  ],
  "thresholds": {
    "maxPositionJump": 0.45
  }
}
```

# 来源 / Sources

业务执行器、文档、样例与图标为本项目原创 MIT 组件。通用 CSV 安全转义和支付交接采用本项目统一组件；本批未复制账号一/二的技能包或其图标。

Original MIT business logic, documentation, fictional examples and icons. Shared CSV escaping and payment handoff are project components. No Skill packages or icons from accounts one/two are redistributed. The payment client helper is generated from canonical payment-chain template1.0.4.

Payment protocol: https://aipay.alipay.com/docs/ai-receive/MACHINE_PAY.html
Unicode segmentation reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/Segmenter

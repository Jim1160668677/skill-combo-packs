# 输入契约 / Input contract

提供 styleBible（styleId、必需 requiredStyleAnchors、paletteTokens、characterId 与 requiredAnchors；可提供 locationId 与 requiredAnchors），以及1–300格 panels。每格含唯一 panelId、sceneId、styleId、styleAnchors、paletteTokens、characters；每格最多20个角色，可选 locationId/locationAnchors。标签经 NFKC、小写归一后精确比较，不推断同义词。

Provide a styleBible with styleId, requiredStyleAnchors, paletteTokens, character IDs and requiredAnchors; optional locations can define their own required anchors. Supply 1–300 panels, each with a unique panelId, sceneId, styleId, styleAnchors, paletteTokens and up to 20 character entries; locationId/locationAnchors are optional. Tokens are compared exactly after NFKC and lowercase normalization; synonyms are not inferred.

Cross-field dates, unique IDs, scope matching and aggregate limits are validated by the service in addition to JSON Schema.

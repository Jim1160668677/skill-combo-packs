---
name: mijing-ai-comic-storyboard-continuity
description: 漫剧视觉一致性、分镜空间逻辑、对白排版、素材引用与事实依据审校。 按需路由到本包的专项技能；付费调用前明确列出服务与费用。
license: MIT
---

# 镜界·AI漫剧分镜连续性与素材审校包

## 适用任务

漫剧视觉一致性、分镜空间逻辑、对白排版、素材引用与事实依据审校。

## 执行方式

1. 先识别用户要完成的具体环节，只加载下方目录中相关的专项 `SKILL.md` 和它引用的资料。
2. 按该专项技能的输入契约收集必需信息；缺少关键输入时先列出缺项，不虚构业务事实或结果。
3. 输出前遵守专项的格式与质量检查要求，并清楚区分已知事实、推断和待确认事项。
4. 仅当用户明确需要且已授权相应服务调用时，才调用对应的付费执行器。专项包的现行支付契约为 ¥0.10/次；一次任务若需多个专项调用，先逐项说明调用对象和费用，获得授权后再执行，不将订阅/买断与按次服务费混为一谈。
5. 不自动发布内容、不替用户付款、不承诺流量或销售结果；需人工确认的平台规则、权利或事实问题应明确标出。

## 专项技能目录

| 专项 | 路径 |
|---|---|
| 漫格·漫剧画风锚点巡检 / Comic Prompt Continuity Audit | `skills/mijing-comic-prompt-continuity-audit/SKILL.md` |
| 格序·漫剧分镜连续性核对 / Comic Storyboard Continuity Review | `skills/mijing-comic-panel-continuity-audit/SKILL.md` |
| 留白·漫画对白气泡排版检查 / Comic Speech Balloon Layout Check | `skills/mijing-comic-balloon-layout-check/SKILL.md` |
| 迹库·跨集素材版本与引用核对 / Production Asset Versions and Reference Review | `skills/mijing-production-asset-ledger/SKILL.md` |
| 知漫·科普漫剧事实溯源分镜台 / Knowledge Comic Factboard | `skills/mijing-knowledge-comic-factboard/SKILL.md` |

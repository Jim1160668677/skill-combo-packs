# 来源 / Sources

本包业务流程、结构化契约、示例和图标由 Mijing Creator Studio 重新编写；上游公开 Skill 仅作为模块/流程参考。适配说明、来源提交号和许可证如下。

- nexscope-ai/eCommerce-Skills: tiktok-influencer-marketing, tiktok-shop-affiliate-program (MIT; commit ee0fb29433d02ccc22e3e6cea9ab4586d49fd42e).
- coreyhaines31/marketingskills: influencer-marketing (MIT; commit 1efedbc5148b54b2f0f6c6c9fe0be62e151c7fff).

上游仓库许可为 MIT。适用的原始许可文本保存在 `LICENSES/`；本包原创部分采用根目录 `LICENSE.txt` 中的 MIT 许可。没有将未经许可的代码、样例或账号私有数据纳入包内。

SkillHub 支付执行遵循所提供的统一支付模板 v1.0.4；包内不保存用户支付凭证。

# 来源 / Sources

本包业务流程、结构化契约、示例和图标由 Mijing Creator Studio 重新编写；上游公开 Skill 仅作为模块/流程参考。适配说明、来源提交号和许可证如下。

- nexscope-ai/eCommerce-Skills: ecommerce-content-marketing, tiktok-shop-content-strategy (MIT; commit ee0fb29433d02ccc22e3e6cea9ab4586d49fd42e).
- 内部原创：账号三已发布短剧制作、漫剧创作与素材权利工作流。

上游仓库许可为 MIT。适用的原始许可文本保存在 `LICENSES/`；本包原创部分采用根目录 `LICENSE.txt` 中的 MIT 许可。没有将未经许可的代码、样例或账号私有数据纳入包内。

SkillHub 支付执行遵循所提供的统一支付模板 v1.0.4；包内不保存用户支付凭证。

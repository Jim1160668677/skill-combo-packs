# 来源与改造说明

social-media-skills/skills — livestream-and-realtime (MIT; pinned commit 6e30eeb2f6736bda8683b6bbaa674af3641d7945). Adapted as a manual planning workflow; no upstream code copied.

本产品仅参考公开工作流；未复制上游代码、图片、示例或账号私有资料。原创说明、数据契约、示例与执行器按本目录 `LICENSE.txt` 许可。
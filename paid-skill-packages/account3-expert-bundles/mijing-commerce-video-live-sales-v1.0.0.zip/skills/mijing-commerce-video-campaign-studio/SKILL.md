---
name: mijing-commerce-video-campaign-studio
description: 把用户提供的商品事实、证据与目标渠道整理成卖点映射、商品页结构、短视频脚本提纲和剪辑交接表；标记缺证与待人工复核项，不读取店铺后台。 适用场景：商品信息已由商家确认，需要把商品页卖点和短视频制作交接对齐时使用。 / 把用户提供的商品事实、证据与目标渠道整理成卖点映射、商品页结构、短视频脚本提纲和剪辑交接表；标记缺证与待人工复核项，不读取店铺后台。
license: MIT
metadata:
  display_name: 货镜·电商商品页与短视频策划台 / Commerce Product-to-Video Campaign Studio
displayName: 货镜·电商商品页与短视频策划台 / Commerce Product-to-Video Campaign Studio
summary: '中文：把用户提供的商品事实、证据与目标渠道整理成卖点映射、商品页结构、短视频脚本提纲和剪辑交接表；标记缺证与待人工复核项，不读取店铺后台。 / English: 把用户提供的商品事实、证据与目标渠道整理成卖点映射、商品页结构、短视频脚本提纲和剪辑交接表；标记缺证与待人工复核项，不读取店铺后台。'
slug: mijing-commerce-video-campaign-studio
version: 1.0.0
pricing:
  model: per_call
  amount_fen: 10
  currency: CNY
---

<!-- unified-payment-template: 1.0.4 -->
## 支付依赖与恢复 / Payment runtime and recovery

运行时需要 Node.js 20+ 和宿主的支付宝官方 `alipay-payment-skill`、`alipay-bot`。宿主不同不代表钱包授权可以搬运。正常第一条支付宝业务命令是官方 buyer-pay 或原单查询，不能加通用 check-wallet 前检。

只有真实业务命令无法找到/执行 alipay-bot 时，才加载官方技能的 `references/command-recovery.md`：取得外部安装授权，核对指定版本 `@alipay/agent-payment@1.0.23` 的官方完整性后安装，再重试原命令一次。不能每次调用都安装 latest，不能把卖家部署工具当作买方依赖；已启动但业务失败时原样展示并停止。

English: Use the current host's official Alipay buyer runtime. Only an actual command-not-found failure enters the official pinned-version installation recovery. Do not reinstall on every call, precheck wallets generically, or install merchant tooling in the buyer path.

仅在上述恢复条件成立且已获外部安装授权时执行下列两步。先查询完整性，必须逐字符等于下面的指定值；不一致或查不到则停止，不能继续安装：

```text
npm view '@alipay/agent-payment@1.0.23' dist.integrity --registry 'https://registry.npmjs.org'
```

```text
sha512-7OGSHhPnuKsyENpivpY60NgE77ktKtWTP8UBtmizeB1Et44KHFFIjDcSRIFpitEdKAC7uMBx3Mp1Zg/wbYmYCQ==
```

核对一致后才执行安装，并仅重试原先无法执行的命令一次：

```text
npx -y --registry=https://registry.npmjs.org @alipay/agent-payment@1.0.23 install
```

这里的命令是依赖恢复说明，不是正常付款前置；官方技能版本更新时须重新对照其 command-recovery.md，不沿用过期完整性值。

## 本包现行支付流程 / Registered checkout

本包支付配置为 payment-contract.json：资源 `mijing-commerce-video-campaign-studio`、单价 ¥0.10 / CNY、支付宝服务 ID `API_FC3B91AF109D47C8`、完整服务地址 `https://fwskillpay-api.cn/v1/pay/skills/mijing-commerce-video-campaign-studio/invoke`。配置与 SKILL/助手哈希不符即停止。平台展示价须在提交后单独回读，不能从本包检查推定平台价已经一致。

1. 调用前披露输入范围、接收方、用途、留存及 ¥0.10，取得本次数据传输和该金额的付款授权。已有授权不再二次询问；价格一致也不能代替授权。
2. 在包外私有目录准备 payload.json，按本 Skill 的输入契约执行 probe。400、503、429、未知网络状态或未付款的 200 都停止，不能本地代做付费结果。
3. 只核对网关公开 JSON 摘要中的金额、币种、商户订单号、资源 ID、服务 ID 和有效期；任一字段缺失、类型错误、过期或与登记不符都停止，不进入 pay。不解码 Payment-Needed 或 amtPaymentLink，不自行验签；公开摘要不能证明签名、实际付款或到账。
4. 本次唯一非空 amtPaymentLink 优先，并原样交给官方 `--amt-payment-link`，不写付款材料文件；链接缺失才使用原值保存的 Payment-Needed 文件。空、多个或歧义链接停止，两种参数互斥，不能补造或从历史输出补齐。
5. 已有该金额授权时立即准备 pay，宿主在返回的 workingDirectory 实际用 executable 与参数数组运行官方 buyer-pay。参数 JSON 不算弹码。会话按下表取值，保持本次原请求与幂等键。
6. 原样输出当前官方对客文本一次，完整展示全部 MEDIA 图片；不复用旧图、不绘制替代二维码。链接生成、success:true、OPEN_LINK_CREATED 不代表付款或交付。
7. 宿主把刚执行的官方对客文本保存在包外私有文件，用本次 handoffId 执行 record-official。只从“订单号/查询单号/交易号”标签提取标识；拒绝原始 JSON、其他交接或冲突标识。观察分类由宿主依据真实输出选择，不是 helper 验付。
8. 用户表示付好或要求查询时，complete 按已绑定标识查询原单：有效 32 位、11–14 位为 8282 的查询号优先；否则用本次交易号。查询不附加 session-id、账单文件或付款链接。未绑定原单停止，不能猜测。
9. 只交付官方实际返回的非空验付后资源。成功交付、业务失败、资源为空、身份不符或查询失败后停止；仅命令超时/网络失败允许按官方规则重试原命令一次。不能从 success 字样认定收款。

English: Obtain data-transfer and price authorization before probe. Compare the public checkout summary while passing payment material unchanged to the official runtime. A unique amtPaymentLink takes priority over an opaque Payment-Needed file. Actually execute the returned argument array, show all current official media, then bind the current official customer-facing output to its handoff. Query only the bound original order. Deliver only actual nonempty official resources. Offline helper checks and host observations are not proof of payment or settlement.

### 当前会话 / Current session

取首个非空来源，高优先级不能被低优先级覆盖：

| 优先级 | 当前运行时来源 |
|---|---|
| 1 | sessionId / session_id 元数据 |
| 2 | threadId / thread_id / conversationId / conversation_id / agentContextId；Codex 使用 CODEX_THREAD_ID |
| 3 | 前两级都为空才用 AIPAY_SESSION_ID |

不能生成会话 ID，不能用订单号、交易号、用户/钱包 ID、URL、测试名或历史会话代替；陈旧环境变量不能覆盖当前显式会话。官方订单号形状（32 位数字且第 11–14 位为 8282）只用于查询，任何符合该形状的串都不是会话，宿主号码仍按逐级取值。全部为空则停止。The current runtime identity takes precedence over inherited environment values.

### 助手调用 / Helper calls

```text
node scripts/skill-paid.mjs probe --state-dir "<包外私有目录>" --payload-file "<包外私有目录>/payload.json" --confirm-data-transfer
node scripts/skill-paid.mjs pay --state-dir "<同一目录>" --session-id "<当前真实会话>" --intent-summary "原始请求：<本次业务目的摘要>" --confirm-payment
node scripts/skill-paid.mjs record-official --state-dir "<同一目录>" --handoff-id "<刚输出的交接ID>" --official-output-file "<刚执行的官方对客文本文件>" --confirm-current-output --outcome pending
node scripts/skill-paid.mjs complete --state-dir "<同一目录>"
```

链接分支 pay 额外带 `--amt-payment-link "<本次 probe 原样返回的值>"`；不能从扫码图片或用户操作链接取替代值。每次实际官方命令后都记录本次 handoff。官方资源文件只存私有目录；资源已交付时可记录 resource_delivered。ack_failed 还须同次真实输出明确回执失败、非空资源文件和已交付确认。无把握时记录 unknown 并停止。

### 大输入、中断及回执 / Large inputs and recovery

大载荷只走同域 /stage 短引用，失败停止，不把大 JSON 塞回命令行。原文恢复副本存在包外私有目录。只有绑定的本次官方输出明确报告引用过期，用户在后续要求恢复并同意再次传输时，才可 restage --confirm-ref-expired --confirm-data-transfer --confirm-recovery-requested 一次；核对原文 SHA-256，保留原订单和幂等键，之后只恢复原单。

正常官方资源交付会自动处理回执。独立 ACK 只恢复已绑定的同次回执失败，且用户后续要求恢复；不重新请求资源。助手使用单次交接标记和锁拒绝重复/并发 ACK。没有真实证据不填确认标志。

付款启动未知不能删状态、换幂等键或再付一笔。已付款但业务失败保留原单，联系运营者核对恢复或退款；退款没有公开命令时不能自行构造。需要官方反馈时加载 alipay-payment-skill 的 references/feedback.md，先向用户确认脱敏内容后提交，不自动发送。

Windows 的文件 mode 不能保证 ACL；宿主须使用当前用户私有目录并核对访问范围。付款材料、当前官方文本、业务原文、资源文件、Cookie 和钱包凭据都不进入发布包或跨宿主同步。


# 货镜·电商商品页与短视频策划台 / Commerce Product-to-Video Campaign Studio

## 交付范围 / Deliverable

把用户提供的商品事实、证据与目标渠道整理成卖点映射、商品页结构、短视频脚本提纲和剪辑交接表；标记缺证与待人工复核项，不读取店铺后台。

## 适用场景 / When to use

商品信息已由商家确认，需要把商品页卖点和短视频制作交接对齐时使用。

## 工作流程 / Workflow

把证据充分的商品事实拆成页面卖点与短视频角度；让每个创意关联 factId；为剪辑交接输出节拍、画面素材位、字幕提示与 CTA 空位；对缺证、禁用表述和用户指定平台规则只作标记，不自动判定法规或平台政策。

先读取 [输入契约](references/input-contract.md)、[JSON Schema](references/input-schema.json) 和[虚构输入样例](references/input-example.json)。输出结构参考 [output-example.json](references/output-example.json)。只接收契约列出的字段；发现必填数据不足、ID 重复或事实引用缺失时先列出问题，不得补造来源、商品功效、达人数据或平台规则。

Before drafting natural-language copy, preserve the supplied facts and label assumptions. Ask for missing evidence when a claim cannot be supported. Keep user-provided identifiers stable and use only anonymized IDs where the input contract requires them.

## 输出 / Outputs

返回：`claimMatrix / listingOutline / videoCards / editHandoff / riskFlags / handoffCsv`。有效输入返回结构化审查/规划表及 CSV；不合法输入应停止并说明缺失或冲突字段，不把错误数据当成计费交付。CSV 文本以安全转义输出。

## 边界 / Limits

不抓取商品页、评价、广告或店铺报表；不验证用户上传的证据真假；不承诺销量。平台字符限制和广告规则须由用户提供当前版本并人工复核。

The service does not fetch live platform or marketplace data, call a third-party model, publish content, or render media. Output is a planning and review aid, not proof of compliance or business performance.

## 数据与隐私 / Data and privacy

只提交本技能契约所需的结构化业务数据；不得提交密码、Cookie、钱包信息、未授权的个人信息或完整私信/评论正文。根据输入契约匿名化引用 ID。当前调用会把必要字段传至登记服务并按网关保留规则处理；调用前确认数据传输用途。

## 依赖与许可 / Dependencies and license

本技能的结构化审查服务不需要外部模型 API key，也不访问平台账号。自然语言内容生成由使用者当前配置的 AI 运行时完成，模型可能有独立费用。二次改造依据 `SOURCES.md` 和 `LICENSES/` 中列出的上游 MIT 许可，并保留原作者版权声明；技能调用单价以 SkillHub 当前商品页为准。

## 已核对的输入示例 / Registered input example

```json
{
  "projectId": "demo-lamp-01",
  "product": {
    "productId": "lamp-01",
    "category": "桌面照明",
    "audience": "夜间阅读与居家办公用户",
    "priceLabel": "按店铺实际标价",
    "facts": [
      {
        "factId": "f1",
        "statement": "支持三档色温",
        "evidenceRef": "manual:p3",
        "status": "verified",
        "factType": "specification"
      },
      {
        "factId": "f2",
        "statement": "灯头可调角度",
        "evidenceRef": "demo:clip-a",
        "status": "verified",
        "factType": "demonstration"
      }
    ],
    "prohibitedClaims": [
      "治疗眼部疾病"
    ]
  },
  "channels": [
    "短视频平台A",
    "店铺商品页"
  ],
  "contentAngles": [
    {
      "angleId": "a1",
      "factId": "f1",
      "channel": "短视频平台A",
      "format": "demo"
    },
    {
      "angleId": "a2",
      "factId": "f2",
      "channel": "短视频平台A",
      "format": "tutorial"
    }
  ],
  "videoDurationSec": 30
}
```

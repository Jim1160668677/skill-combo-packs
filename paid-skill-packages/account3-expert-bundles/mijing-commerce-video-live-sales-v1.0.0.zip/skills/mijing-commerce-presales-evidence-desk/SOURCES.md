# 来源与改造说明

nexscope-ai/eCommerce-Skills — product-description-generator and ecommerce-content-marketing (MIT; pinned commit ee0fb29433d02ccc22e3e6cea9ab4586d49fd42e), used as product-fact-first content workflow reference; no code copied.

本产品仅参考公开工作流；未复制上游代码、图片、示例或账号私有资料。原创说明、数据契约、示例与执行器按本目录 `LICENSE.txt` 许可。
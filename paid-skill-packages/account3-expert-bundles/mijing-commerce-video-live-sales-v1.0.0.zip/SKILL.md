---
name: mijing-commerce-video-live-sales
description: 电商商品内容、售前证据、达人合作、直播控场与剧情植入审片。 按需路由到本包的专项技能；付费调用前明确列出服务与费用。
license: MIT
---

# 镜界·电商短视频与直播转化专家包

## 适用任务

电商商品内容、售前证据、达人合作、直播控场与剧情植入审片。

## 执行方式

1. 先识别用户要完成的具体环节，只加载下方目录中相关的专项 `SKILL.md` 和它引用的资料。
2. 按该专项技能的输入契约收集必需信息；缺少关键输入时先列出缺项，不虚构业务事实或结果。
3. 输出前遵守专项的格式与质量检查要求，并清楚区分已知事实、推断和待确认事项。
4. 仅当用户明确需要且已授权相应服务调用时，才调用对应的付费执行器。专项包的现行支付契约为 ¥0.10/次；一次任务若需多个专项调用，先逐项说明调用对象和费用，获得授权后再执行，不将订阅/买断与按次服务费混为一谈。
5. 不自动发布内容、不替用户付款、不承诺流量或销售结果；需人工确认的平台规则、权利或事实问题应明确标出。

## 专项技能目录

| 专项 | 路径 |
|---|---|
| 货镜·电商商品页与短视频策划台 / Commerce Product-to-Video Campaign Studio | `skills/mijing-commerce-video-campaign-studio/SKILL.md` |
| 问证·电商售前问答证据台 / Commerce Pre-sales Evidence Desk | `skills/mijing-commerce-presales-evidence-desk/SKILL.md` |
| 合拍·达人联盟合作排期与测算 / Creator Affiliate Campaign Planner | `skills/mijing-affiliate-creator-campaign-planner/SKILL.md` |
| 播场·电商直播排演与控场台 / Livestream Run-of-Show Studio | `skills/mijing-livestream-runofshow-studio/SKILL.md` |
| 剧植·短剧漫剧商品植入审片台 / Drama Commerce Placement Desk | `skills/mijing-drama-commerce-placement-desk/SKILL.md` |
